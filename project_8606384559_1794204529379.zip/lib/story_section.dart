import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ─── WARNA NEOBRUTALISM ──────────────────────────────────────────
const Color _kCyan   = Color(0xFFFFDE59); // Kuning neobrutalism
const Color _kPink   = Color(0xFFFF6B6B); // Merah coral
const Color _kPurple = Color(0xFF4D96FF); // Biru terang
const Color _kCard   = Color(0xFFFFFDF5); // Cream kartu

// Warna tambahan neobrutalism
const Color _kBg     = Color(0xFFFFFDF5); // Background cream
const Color _kBlack  = Color(0xFF000000); // Hitam pekat
const Color _kWhite  = Color(0xFFFFFFFF); // Putih
const Color _kGreen  = Color(0xFF6BCB77); // Hijau
const Color _kOrange = Color(0xFFFF9F45); // Orange

// ─── MODEL ───────────────────────────────────────────────────────
class StoryItem {
  final String id;
  final String ownerUsername;
  final String type; // 'text' | 'image' | 'video'
  final String content;
  final String bgColor;
  final String txtColor;
  final String thumbnailUrl;
  final DateTime createdAt;
  final List<String> viewers;

  const StoryItem({
    required this.id,
    required this.ownerUsername,
    required this.type,
    required this.content,
    required this.bgColor,
    required this.txtColor,
    required this.thumbnailUrl,
    required this.createdAt,
    required this.viewers,
  });

  factory StoryItem.fromJson(Map<String, dynamic> j) => StoryItem(
        id: j['id']?.toString() ?? '',
        ownerUsername: j['username'] ?? '',
        type: j['type'] ?? 'text',
        content: j['content'] ?? '',
        bgColor: j['bg_color'] ?? '#FFFDF5',
        txtColor: j['txt_color'] ?? '#000000',
        thumbnailUrl: j['thumbnail'] ?? '',
        createdAt: DateTime.tryParse(j['created_at'] ?? '') ?? DateTime.now(),
        viewers: List<String>.from(j['viewers'] ?? []),
      );
}

class UserStoryGroup {
  final String username;
  final List<StoryItem> stories;
  final bool isMe;

  const UserStoryGroup({
    required this.username,
    required this.stories,
    required this.isMe,
  });
}

// ─── SERVICE ─────────────────────────────────────────────────────
class StoryService {
  final String baseUrl;
  final String sessionKey;
  final String username;

  StoryService({
    required this.baseUrl,
    required this.sessionKey,
    required this.username,
  });

  // Auth via query param sesuai pattern server
  String _url(String endpoint) => '$baseUrl$endpoint?key=$sessionKey';

  Future<List<StoryItem>> fetchAll() async {
    try {
      final res = await http
          .get(Uri.parse(_url('/api/stories')))
          .timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as List;
        return data.map((e) => StoryItem.fromJson(e)).toList();
      }
    } catch (_) {}
    return [];
  }

  Future<bool> postTextStory({
    required String text,
    required String bgColor,
    required String txtColor,
  }) async {
    try {
      final res = await http
          .post(
            Uri.parse(_url('/api/stories')),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'type': 'text',
              'content': text,
              'bg_color': bgColor,
              'txt_color': txtColor,
            }),
          )
          .timeout(const Duration(seconds: 10));
      return res.statusCode == 200 || res.statusCode == 201;
    } catch (_) { return false; }
  }

  Future<bool> postImageStory(File imageFile) async {
    try {
      final req = http.MultipartRequest('POST', Uri.parse(_url('/api/stories/upload')))
        ..fields['type'] = 'image'
        ..files.add(await http.MultipartFile.fromPath('file', imageFile.path));
      final res = await req.send().timeout(const Duration(seconds: 30));
      return res.statusCode == 200 || res.statusCode == 201;
    } catch (_) { return false; }
  }

  Future<bool> postVideoStory(File videoFile) async {
    try {
      final req = http.MultipartRequest('POST', Uri.parse(_url('/api/stories/upload')))
        ..fields['type'] = 'video'
        ..files.add(await http.MultipartFile.fromPath('file', videoFile.path));
      final res = await req.send().timeout(const Duration(seconds: 60));
      return res.statusCode == 200 || res.statusCode == 201;
    } catch (_) { return false; }
  }

  Future<void> markViewed(String storyId) async {
    try {
      await http
          .post(Uri.parse(_url('/api/stories/$storyId/view')))
          .timeout(const Duration(seconds: 5));
    } catch (_) {}
  }

  Future<bool> deleteStory(String storyId) async {
    try {
      final res = await http
          .delete(Uri.parse(_url('/api/stories/$storyId')))
          .timeout(const Duration(seconds: 8));
      return res.statusCode == 200;
    } catch (_) { return false; }
  }
}

// ─── MAIN SECTION WIDGET ─────────────────────────────────────────
class StorySection extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String serverUrl;

  const StorySection({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.serverUrl,
  });

  @override
  State<StorySection> createState() => _StorySectionState();
}

class _StorySectionState extends State<StorySection> {
  late StoryService _svc;
  List<UserStoryGroup> _groups = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _svc = StoryService(
      baseUrl: widget.serverUrl,
      sessionKey: widget.sessionKey,
      username: widget.username,
    );
    _load();
  }

  Future<void> _load() async {
    if (!mounted) return;
    setState(() => _loading = true);
    final stories = await _svc.fetchAll();

    // Filter expired (24 jam)
    final now = DateTime.now();
    final active = stories
        .where((s) => now.difference(s.createdAt).inHours < 24)
        .toList();

    // Group by username
    final Map<String, List<StoryItem>> map = {};
    for (final s in active) {
      map.putIfAbsent(s.ownerUsername, () => []).add(s);
    }

    final groups = map.entries.map((e) {
      return UserStoryGroup(
        username: e.key,
        stories: e.value..sort((a, b) => a.createdAt.compareTo(b.createdAt)),
        isMe: e.key == widget.username,
      );
    }).toList();

    // User sendiri di depan
    groups.sort((a, b) {
      if (a.isMe) return -1;
      if (b.isMe) return 1;
      return 0;
    });

    // Kalau user sendiri belum ada story, tambahin slot kosong
    if (!groups.any((g) => g.isMe)) {
      groups.insert(
        0,
        UserStoryGroup(username: widget.username, stories: [], isMe: true),
      );
    }

    if (mounted) setState(() { _groups = groups; _loading = false; });
  }

  void _openViewer(int groupIndex) {
    final realGroups = _groups.where((g) => g.stories.isNotEmpty).toList();
    if (realGroups.isEmpty) return;
    final realIndex = realGroups.indexWhere(
      (g) => g.username == _groups[groupIndex].username,
    );
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => _StoryViewerPage(
          groups: realGroups,
          initialIndex: realIndex < 0 ? 0 : realIndex,
          service: _svc,
          currentUsername: widget.username,
        ),
        transitionsBuilder: (_, anim, __, child) =>
            FadeTransition(opacity: anim, child: child),
      ),
    ).then((_) => _load());
  }

  void _openCreate() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => _CreateStoryPage(
          service: _svc,
          username: widget.username,
        ),
      ),
    );
    _load();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const SizedBox(
        height: 104,
        child: Center(child: CircularProgressIndicator(color: _kBlack, strokeWidth: 2)),
      );
    }

    return Container(
      color: _kBg,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Row(
              children: [
                const Icon(Icons.auto_stories_rounded, color: _kBlack, size: 16),
                const SizedBox(width: 6),
                const Text(
                  'QUEENGRAM',
                  style: TextStyle(
                    color: _kBlack,
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.2,
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: _load,
                  child: Icon(Icons.refresh_rounded, color: _kBlack.withOpacity(0.5), size: 16),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: 100,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 14),
              physics: const BouncingScrollPhysics(),
              itemCount: _groups.length,
              separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemBuilder: (_, i) {
                final g = _groups[i];
                final bool hasUnviewed = g.stories.any(
                  (s) => !s.viewers.contains(widget.username),
                );
                return _StoryRing(
                  group: g,
                  hasUnviewed: hasUnviewed,
                  onTap: () {
                    if (g.stories.isEmpty) {
                      _openCreate();
                    } else {
                      _openViewer(i);
                    }
                  },
                  onAddTap: g.isMe ? _openCreate : null,
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ─── RING WIDGET ─────────────────────────────────────────────────
class _StoryRing extends StatelessWidget {
  final UserStoryGroup group;
  final bool hasUnviewed;
  final VoidCallback onTap;
  final VoidCallback? onAddTap;

  const _StoryRing({
    required this.group,
    required this.hasUnviewed,
    required this.onTap,
    this.onAddTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: SizedBox(
        width: 68,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                // Ring gradient
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: hasUnviewed
                        ? const LinearGradient(
                            colors: [_kCyan, _kOrange, _kPink],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          )
                        : LinearGradient(
                            colors: [
                              Colors.black.withOpacity(0.15),
                              Colors.black.withOpacity(0.05),
                            ],
                          ),
                  ),
                ),
                // Avatar
                Container(
                  width: 58,
                  height: 58,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _kWhite,
                    border: Border.all(
                      color: _kBlack,
                      width: 2,
                    ),
                  ),
                  child: ClipOval(
                    child: group.stories.isNotEmpty &&
                            group.stories.first.type == 'image'
                        ? Image.network(
                            group.stories.first.content,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => _initial(),
                          )
                        : _initial(),
                  ),
                ),
                // Tombol +
                if (group.isMe)
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: GestureDetector(
                      onTap: onAddTap,
                      child: Container(
                        width: 20,
                        height: 20,
                        decoration: BoxDecoration(
                          color: _kCyan,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: _kBlack,
                            width: 1.5,
                          ),
                        ),
                        child: const Icon(Icons.add, size: 13, color: _kBlack),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              group.isMe ? 'My Story' : group.username,
              style: const TextStyle(
                color: _kBlack,
                fontSize: 10,
                fontFamily: 'ShareTechMono',
                fontWeight: FontWeight.bold,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _initial() => Container(
        color: _kCyan,
        alignment: Alignment.center,
        child: Text(
          group.username.isNotEmpty ? group.username[0].toUpperCase() : '?',
          style: const TextStyle(
            color: _kBlack,
            fontSize: 22,
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
          ),
        ),
      );
}

// ─── VIEWER PAGE ─────────────────────────────────────────────────
class _StoryViewerPage extends StatefulWidget {
  final List<UserStoryGroup> groups;
  final int initialIndex;
  final StoryService service;
  final String currentUsername;

  const _StoryViewerPage({
    required this.groups,
    required this.initialIndex,
    required this.service,
    required this.currentUsername,
  });

  @override
  State<_StoryViewerPage> createState() => _StoryViewerPageState();
}

class _StoryViewerPageState extends State<_StoryViewerPage>
    with TickerProviderStateMixin {
  late int _gi, _si;
  late AnimationController _prog;
  VideoPlayerController? _vid;

  @override
  void initState() {
    super.initState();
    _gi = widget.initialIndex;
    _si = 0;
    _prog = AnimationController(vsync: this);
    _load();
  }

  UserStoryGroup get _cg => widget.groups[_gi];
  StoryItem get _cs => _cg.stories[_si];

  Future<void> _load() async {
    _prog.reset();
    await _vid?.dispose();
    _vid = null;

    await widget.service.markViewed(_cs.id);

    if (_cs.type == 'video') {
      _vid = VideoPlayerController.networkUrl(Uri.parse(_cs.content));
      await _vid!.initialize();
      if (mounted) {
        setState(() {});
        _vid!.play();
        _start(_vid!.value.duration);
      }
    } else {
      if (mounted) setState(() {});
      _start(const Duration(seconds: 5));
    }
  }

  void _start(Duration d) {
    _prog.duration = d;
    _prog.forward().then((_) { if (mounted) _next(); });
  }

  void _next() {
    if (_si < _cg.stories.length - 1) {
      setState(() => _si++);
    } else if (_gi < widget.groups.length - 1) {
      setState(() { _gi++; _si = 0; });
    } else {
      Navigator.pop(context);
      return;
    }
    _load();
  }

  void _prev() {
    if (_si > 0) {
      setState(() => _si--);
    } else if (_gi > 0) {
      setState(() { _gi--; _si = _cg.stories.length - 1; });
    }
    _load();
  }

  @override
  void dispose() {
    _prog.dispose();
    _vid?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = _cs;
    return Scaffold(
      backgroundColor: _kBg,
      body: GestureDetector(
        onTapUp: (d) {
          final w = MediaQuery.of(context).size.width;
          if (d.globalPosition.dx < w / 2) _prev(); else _next();
        },
        child: Stack(
          fit: StackFit.expand,
          children: [
            // ─ Content ─
            if (s.type == 'text')
              _textContent(s)
            else if (s.type == 'image')
              Image.network(s.content, fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => _textContent(s))
            else if (_vid != null && _vid!.value.isInitialized)
              Center(child: AspectRatio(
                aspectRatio: _vid!.value.aspectRatio,
                child: VideoPlayer(_vid!),
              ))
            else
              const Center(child: CircularProgressIndicator(color: _kBlack)),

            // ─ Top gradient ─
            Positioned(
              top: 0, left: 0, right: 0, height: 140,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.black.withOpacity(0.5), Colors.transparent],
                  ),
                ),
              ),
            ),

            // ─ Progress bars ─
            Positioned(
              top: MediaQuery.of(context).padding.top + 6,
              left: 8, right: 8,
              child: Row(
                children: List.generate(_cg.stories.length, (i) => Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 2),
                    child: AnimatedBuilder(
                      animation: _prog,
                      builder: (_, __) => LinearProgressIndicator(
                        value: i < _si ? 1.0 : i == _si ? _prog.value : 0.0,
                        backgroundColor: Colors.black12,
                        valueColor: const AlwaysStoppedAnimation(_kBlack),
                        minHeight: 2.5,
                      ),
                    ),
                  ),
                )),
              ),
            ),

            // ─ Header ─
            Positioned(
              top: MediaQuery.of(context).padding.top + 18,
              left: 12, right: 12,
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 16,
                    backgroundColor: _kCyan,
                    child: Text(
                      _cg.username[0].toUpperCase(),
                      style: const TextStyle(color: _kBlack, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(_cg.username,
                      style: const TextStyle(color: _kBlack, fontWeight: FontWeight.w600, fontSize: 13)),
                  const SizedBox(width: 6),
                  Text(_ago(s.createdAt),
                      style: const TextStyle(color: Colors.black54, fontSize: 11)),
                  const Spacer(),
                  // Hapus kalau story sendiri
                  if (_cg.username == widget.currentUsername)
                    IconButton(
                      icon: const Icon(Icons.delete_outline_rounded, color: _kBlack, size: 20),
                      onPressed: () async {
                        await widget.service.deleteStory(s.id);
                        Navigator.pop(context);
                      },
                    ),
                  IconButton(
                    icon: const Icon(Icons.close_rounded, color: _kBlack, size: 22),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _textContent(StoryItem s) {
    Color bg = _kWhite;
    try {
      bg = Color(int.parse('FF${s.bgColor.replaceAll('#', '')}', radix: 16));
    } catch (_) {}
    Color txt = _kBlack;
    try {
      txt = Color(int.parse('FF${s.txtColor.replaceAll('#', '')}', radix: 16));
    } catch (_) {}
    return Container(
      color: bg,
      alignment: Alignment.center,
      padding: const EdgeInsets.all(32),
      child: Text(s.content,
          style: TextStyle(color: txt, fontSize: 26, fontWeight: FontWeight.bold, height: 1.4),
          textAlign: TextAlign.center),
    );
  }

  String _ago(DateTime dt) {
    final d = DateTime.now().difference(dt);
    if (d.inMinutes < 60) return '${d.inMinutes}m';
    return '${d.inHours}h';
  }
}

// ─── CREATE PAGE ──────────────────────────────────────────────────
class _CreateStoryPage extends StatefulWidget {
  final StoryService service;
  final String username;

  const _CreateStoryPage({required this.service, required this.username});

  @override
  State<_CreateStoryPage> createState() => _CreateStoryPageState();
}

class _CreateStoryPageState extends State<_CreateStoryPage>
    with SingleTickerProviderStateMixin {
  late TabController _tab;
  final _ctrl = TextEditingController();
  bool _loading = false;
  String _bg = '#FFFDF5';
  String _txt = '#000000';
  File? _img, _vid;

  static const _bgOpts = [
    '#FFFDF5', '#FFDE59', '#4D96FF', '#6BCB77',
    '#FF6B6B', '#FF9F45', '#B983FF', '#000000',
  ];

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tab.dispose();
    _ctrl.dispose();
    super.dispose();
  }

  Color _hex(String h) {
    try { return Color(int.parse('FF${h.replaceAll('#', '')}', radix: 16)); }
    catch (_) { return _kWhite; }
  }

  Future<void> _submit() async {
    setState(() => _loading = true);
    bool ok = false;
    switch (_tab.index) {
      case 0:
        if (_ctrl.text.trim().isEmpty) { setState(() => _loading = false); return; }
        ok = await widget.service.postTextStory(
          text: _ctrl.text.trim(), bgColor: _bg, txtColor: _txt);
      case 1:
        if (_img == null) { setState(() => _loading = false); return; }
        ok = await widget.service.postImageStory(_img!);
      case 2:
        if (_vid == null) { setState(() => _loading = false); return; }
        ok = await widget.service.postVideoStory(_vid!);
    }
    if (!mounted) return;
    setState(() => _loading = false);
    if (ok) {
      Navigator.pop(context);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Gagal upload. Coba lagi.'),
          backgroundColor: _kPink,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: const BorderSide(color: _kBlack, width: 2),
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text('Buat Story',
            style: TextStyle(color: _kBlack, fontFamily: 'Orbitron',
                fontSize: 14, letterSpacing: 1)),
        iconTheme: const IconThemeData(color: _kBlack),
        actions: [
          _loading
              ? const Padding(padding: EdgeInsets.all(16),
                  child: SizedBox(width: 20, height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2, color: _kBlack)))
              : TextButton(
                  onPressed: _submit,
                  child: const Text('Bagikan',
                      style: TextStyle(color: _kBlack, fontWeight: FontWeight.bold, fontSize: 15)),
                ),
        ],
        bottom: TabBar(
          controller: _tab,
          indicatorColor: _kBlack,
          labelColor: _kBlack,
          unselectedLabelColor: Colors.black38,
          labelStyle: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 12),
          tabs: const [Tab(text: 'TEKS'), Tab(text: 'FOTO'), Tab(text: 'VIDEO')],
        ),
      ),
      body: TabBarView(
        controller: _tab,
        children: [_textTab(), _imgTab(), _vidTab()],
      ),
    );
  }

  Widget _textTab() => SingleChildScrollView(
    padding: const EdgeInsets.all(20),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // Preview
      Container(
        width: double.infinity, height: 220,
        decoration: BoxDecoration(color: _hex(_bg), borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _kBlack, width: 2)),
        alignment: Alignment.center,
        padding: const EdgeInsets.all(24),
        child: Text(
          _ctrl.text.isEmpty ? 'Preview...' : _ctrl.text,
          style: TextStyle(color: _hex(_txt), fontSize: 22, fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
      ),
      const SizedBox(height: 16),
      TextField(
        controller: _ctrl,
        maxLines: 4, maxLength: 200,
        style: const TextStyle(color: _kBlack),
        decoration: InputDecoration(
          hintText: 'Tulis sesuatu...',
          hintStyle: const TextStyle(color: Colors.black38),
          filled: true, fillColor: _kWhite,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: _kBlack, width: 2),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: _kBlack, width: 2),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: _kBlack, width: 2),
          ),
          counterStyle: const TextStyle(color: Colors.black38),
        ),
        onChanged: (_) => setState(() {}),
      ),
      const SizedBox(height: 16),
      const Text('Background', style: TextStyle(color: Colors.black87, fontWeight: FontWeight.w600)),
      const SizedBox(height: 8),
      Wrap(spacing: 10, children: _bgOpts.map((h) {
        final sel = _bg == h;
        return GestureDetector(
          onTap: () => setState(() => _bg = h),
          child: Container(
            width: 34, height: 34,
            decoration: BoxDecoration(
              color: _hex(h), shape: BoxShape.circle,
              border: Border.all(color: sel ? _kBlack : Colors.black26, width: 2.5),
              boxShadow: sel ? [BoxShadow(color: _kBlack.withOpacity(0.3), blurRadius: 6, offset: const Offset(2, 2))] : [],
            ),
          ),
        );
      }).toList()),
      const SizedBox(height: 16),
      const Text('Warna Teks', style: TextStyle(color: Colors.black87, fontWeight: FontWeight.w600)),
      const SizedBox(height: 8),
      Row(children: [
        _txtBtn('#000000', 'Hitam'),
        const SizedBox(width: 8),
        _txtBtn('#ffffff', 'Putih'),
        const SizedBox(width: 8),
        _txtBtn('#FF6B6B', 'Coral'),
        const SizedBox(width: 8),
        _txtBtn('#4D96FF', 'Biru'),
      ]),
    ]),
  );

  Widget _txtBtn(String h, String label) => GestureDetector(
    onTap: () => setState(() => _txt = h),
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: _hex(h).withOpacity(0.2),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _txt == h ? _kBlack : Colors.black26, width: 2),
      ),
      child: Text(label, style: TextStyle(color: _kBlack, fontSize: 11, fontWeight: FontWeight.bold)),
    ),
  );

  Widget _imgTab() => Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    if (_img != null) ...[
      ClipRRect(borderRadius: BorderRadius.circular(16),
          child: Image.file(_img!, height: 280, width: double.infinity, fit: BoxFit.cover)),
      const SizedBox(height: 16),
      TextButton.icon(
        onPressed: _pickImg,
        icon: const Icon(Icons.refresh, color: Colors.black54),
        label: const Text('Ganti Foto', style: TextStyle(color: Colors.black54)),
      ),
    ] else ...[
      Icon(Icons.photo_library_rounded, size: 64, color: _kBlack.withOpacity(0.3)),
      const SizedBox(height: 16),
      ElevatedButton.icon(
        onPressed: _pickImg,
        icon: const Icon(Icons.photo),
        label: const Text('Pilih Foto'),
        style: ElevatedButton.styleFrom(
          backgroundColor: _kCyan, foregroundColor: _kBlack,
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),
            side: const BorderSide(color: _kBlack, width: 2),
          ),
          elevation: 4,
          shadowColor: _kBlack,
        ),
      ),
    ],
  ]));

  Widget _vidTab() => Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    Icon(Icons.videocam_rounded, size: 64, color: _kBlack.withOpacity(0.3)),
    const SizedBox(height: 16),
    if (_vid != null) ...[
      Text(_vid!.path.split('/').last,
          style: const TextStyle(color: Colors.black87), textAlign: TextAlign.center),
      const SizedBox(height: 8),
      const Icon(Icons.check_circle_rounded, color: _kGreen, size: 28),
      const SizedBox(height: 12),
      TextButton.icon(
        onPressed: _pickVid,
        icon: const Icon(Icons.refresh, color: Colors.black54),
        label: const Text('Ganti Video', style: TextStyle(color: Colors.black54)),
      ),
    ] else
      ElevatedButton.icon(
        onPressed: _pickVid,
        icon: const Icon(Icons.video_library),
        label: const Text('Pilih Video (max 30 detik)'),
        style: ElevatedButton.styleFrom(
          backgroundColor: _kCyan, foregroundColor: _kBlack,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),
            side: const BorderSide(color: _kBlack, width: 2),
          ),
          elevation: 4,
          shadowColor: _kBlack,
        ),
      ),
  ]));

  Future<void> _pickImg() async {
    final p = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (p != null && mounted) setState(() => _img = File(p.path));
  }

  Future<void> _pickVid() async {
    final p = await ImagePicker().pickVideo(
        source: ImageSource.gallery, maxDuration: const Duration(seconds: 30));
    if (p != null && mounted) setState(() => _vid = File(p.path));
  }
}