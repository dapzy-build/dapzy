import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

const String baseUrl = "http://szmarket.id:2244";

class ChangePasswordPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const ChangePasswordPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<ChangePasswordPage> createState() => _ChangePasswordPageState();
}

class _ChangePasswordPageState extends State<ChangePasswordPage> {
  final oldPassCtrl = TextEditingController();
  final newPassCtrl = TextEditingController();
  final confirmPassCtrl = TextEditingController();

  bool isLoading = false;
  bool _obscurePassword = true;

  // ─── TEMA NEOBRUTALISM ───────────────────────────────────────
  final Color bgDark = const Color(0xFFFFFDF5);
  final Color bgSecondary = const Color(0xFFFFFFFF);
  final Color accentColor = const Color(0xFFFFDE59);
  final Color primaryWhite = const Color(0xFF000000);
  final Color textGrey = const Color(0xFF333333);

  final Color _kBlack = const Color(0xFF000000);
  final Color _kWhite = const Color(0xFFFFFFFF);
  final Color _kCyan = const Color(0xFF4D96FF);
  final Color _kPink = const Color(0xFFFF6B6B);
  final Color _kGreen = const Color(0xFF6BCB77);
  final Color _kOrange = const Color(0xFFFF9F45);
  final Color _kYellow = const Color(0xFFFFDE59);

  Future<void> _changePassword() async {
    final oldPass = oldPassCtrl.text.trim();
    final newPass = newPassCtrl.text.trim();
    final confirmPass = confirmPassCtrl.text.trim();

    if (oldPass.isEmpty || newPass.isEmpty || confirmPass.isEmpty) {
      _showMessage("Semua field harus diisi.");
      return;
    }

    if (newPass != confirmPass) {
      _showMessage("Password baru tidak cocok dengan konfirmasi.");
      return;
    }

    setState(() => isLoading = true);

    try {
      final res = await http.post(
        Uri.parse("$baseUrl/changepass"),
        body: {
          "username": widget.username,
          "oldPass": oldPass,
          "newPass": newPass,
          "sessionKey": widget.sessionKey,
        },
      );

      final data = jsonDecode(res.body);

      if (data['success'] == true) {
        _showMessage("Password berhasil diubah!", isSuccess: true);
        oldPassCtrl.clear();
        newPassCtrl.clear();
        confirmPassCtrl.clear();
      } else {
        _showMessage(data['message'] ?? "Gagal mengubah password");
      }
    } catch (e) {
      _showMessage("Koneksi error: $e");
    }

    setState(() => isLoading = false);
  }

  void _showMessage(String msg, {bool isSuccess = false}) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _kWhite,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: BorderSide(color: _kBlack, width: 3),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: isSuccess ? _kGreen : _kCyan,
                shape: BoxShape.circle,
                border: Border.all(color: _kBlack, width: 2),
              ),
              child: Icon(
                isSuccess ? Icons.check_circle_outline : Icons.info_outline,
                color: _kBlack,
                size: 28,
              ),
            ),
            const SizedBox(width: 12),
            Text(
              isSuccess ? "Sukses" : "Peringatan",
              style: TextStyle(
                color: primaryWhite,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                fontSize: 18,
              ),
            ),
          ],
        ),
        content: Text(msg, style: TextStyle(color: textGrey, fontSize: 14)),
        actions: [
          Center(
            child: SizedBox(
              width: double.infinity,
              height: 45,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: accentColor,
                  foregroundColor: _kBlack,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: BorderSide(color: _kBlack, width: 2),
                  ),
                  elevation: 4,
                  shadowColor: _kBlack,
                ),
                child: Text(
                  "OK",
                  style: TextStyle(
                    color: _kBlack,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // --- WIDGET INPUT ---
  Widget _buildInput(TextEditingController controller, String label, IconData icon, [bool isPassword = false]) {
    return Container(
      height: 60,
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
        color: _kWhite,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _kBlack, width: 2),
        boxShadow: [
          BoxShadow(
            color: _kBlack,
            blurRadius: 0,
            offset: const Offset(3, 3),
          ),
        ],
      ),
      child: Center(
        child: TextFormField(
          controller: controller,
          obscureText: isPassword ? _obscurePassword : false,
          style: TextStyle(color: _kBlack, fontSize: 15, fontWeight: FontWeight.bold, fontFamily: 'ShareTechMono'),
          decoration: InputDecoration(
            labelText: label,
            labelStyle: TextStyle(color: _kBlack, fontSize: 13, fontWeight: FontWeight.normal, fontFamily: 'sans-serif'),
            prefixIcon: Icon(icon, color: _kBlack, size: 22),
            filled: false,
            fillColor: Colors.transparent,
            suffixIcon: isPassword
                ? IconButton(
              icon: Icon(
                _obscurePassword ? Icons.visibility_off : Icons.visibility,
                color: _kBlack,
                size: 20,
              ),
              onPressed: () {
                setState(() {
                  _obscurePassword = !_obscurePassword;
                });
              },
            )
                : null,
            border: InputBorder.none,
            contentPadding: EdgeInsets.zero,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: _kBlack),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: Text(
          "CHANGE PASSWORD",
          style: TextStyle(
            color: primaryWhite,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 20),

            // Header Icon
            Center(
              child: Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _kYellow,
                  border: Border.all(color: _kBlack, width: 3),
                  boxShadow: [
                    BoxShadow(
                      color: _kBlack,
                      blurRadius: 0,
                      offset: const Offset(5, 5),
                    )
                  ],
                ),
                child: Icon(Icons.lock_reset, color: _kBlack, size: 50),
              ),
            ),
            const SizedBox(height: 20),

            Center(
              child: Text(
                "SECURITY UPDATE",
                style: TextStyle(
                  color: primaryWhite,
                  fontSize: 22,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 8),
            Center(
              child: Text(
                "Masukkan password lama dan baru.",
                style: TextStyle(
                  color: textGrey,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ),

            const SizedBox(height: 30),

            // Form Inputs Container
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: bgSecondary,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: _kBlack, width: 3),
                boxShadow: [
                  BoxShadow(
                    color: _kBlack,
                    blurRadius: 0,
                    offset: const Offset(6, 6),
                  )
                ],
              ),
              child: Column(
                children: [
                  _buildInput(oldPassCtrl, "Old Password", Icons.lock_outline, true),
                  _buildInput(newPassCtrl, "New Password", Icons.vpn_key, true),
                  _buildInput(confirmPassCtrl, "Confirm Password", Icons.enhanced_encryption, true),
                  const SizedBox(height: 24),
                  
                  // Button
                  Container(
                    width: double.infinity,
                    height: 55,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: _kBlack,
                          blurRadius: 0,
                          offset: const Offset(4, 4),
                        ),
                      ],
                    ),
                    child: ElevatedButton(
                      onPressed: isLoading ? null : _changePassword,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: accentColor,
                        foregroundColor: _kBlack,
                        shadowColor: Colors.transparent,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                          side: BorderSide(color: _kBlack, width: 2),
                        ),
                      ),
                      child: isLoading
                          ? SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: _kBlack,
                        ),
                      )
                          : Text(
                        "UPDATE PASSWORD",
                        style: TextStyle(
                          color: _kBlack,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}