import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'widgets/custom_popup.dart';

class RiwayatPage extends StatefulWidget {
  final String sessionKey;
  final String role;

  const RiwayatPage({
    super.key,
    required this.sessionKey,
    required this.role,
  });

  @override
  State<RiwayatPage> createState() => _RiwayatPageState();
}

class _RiwayatPageState extends State<RiwayatPage> {
  // ─── TEMA NEOBRUTALISM ───────────────────────────────────────
  final Color bgDark = const Color(0xFFFFFDF5);
  final Color primaryPurple = const Color(0xFFFFDE59);
  final Color accentPurple = const Color(0xFFFFDE59);
  final Color lightPurple = const Color(0xFF333333);
  final Color primaryWhite = const Color(0xFF000000);
  final Color accentGrey = const Color(0xFF333333);
  final Color cardGlass = const Color(0xFFFFFFFF);
  final Color borderGlass = const Color(0xFF000000);

  final Color _kBlack = const Color(0xFF000000);
  final Color _kWhite = const Color(0xFFFFFFFF);
  final Color _kCyan = const Color(0xFF4D96FF);
  final Color _kPink = const Color(0xFFFF6B6B);
  final Color _kGreen = const Color(0xFF6BCB77);
  final Color _kOrange = const Color(0xFFFF9F45);
  final Color _kYellow = const Color(0xFFFFDE59);

  List<ActivityModel> activities = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadActivities();
  }

  Future<void> _loadActivities() async {
    const baseUrl = "http://szmarket.id:2244";

    try {
      final response = await http.get(
        Uri.parse('$baseUrl/getMyActivity?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid']) {
          List<dynamic> rawList = data['activities'];

          setState(() {
            activities = rawList.map((item) {
              return ActivityModel(
                type: item['type'] ?? 'system',
                title: item['title'] ?? 'Aktivitas',
                description: item['description'] ?? '-',
                timestamp: DateTime.fromMillisecondsSinceEpoch(
                    item['timestamp'] ?? DateTime.now().millisecondsSinceEpoch
                ),
              );
            }).toList();
            isLoading = false;
          });
        } else {
          setState(() => isLoading = false);
        }
      } else {
        print("Server Error: ${response.statusCode}");
        setState(() => isLoading = false);
        if (mounted) {
          CustomPopup.display(
            context,
            title: "Server Error",
            message: "Failed to fetch activities.",
            icon: Icons.error_outline,
            iconColor: _kPink,
          );
        }
      }
    } catch (e) {
      print("Error fetching history: $e");
      setState(() => isLoading = false);
      if (mounted) {
        CustomPopup.display(
          context,
          title: "Connection Error",
          message: "Gagal terhubung ke server.",
          icon: Icons.error_outline,
          iconColor: _kPink,
        );
      }
    }
  }

  String _formatDate(DateTime date) {
    return DateFormat('dd MMM yyyy, HH:mm').format(date);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        title: Text(
          "Riwayat Aktivitas",
          style: TextStyle(
            color: primaryWhite,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: _kYellow,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _kBlack, width: 2),
              boxShadow: [
                BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(2, 2)),
              ],
            ),
            child: Icon(Icons.arrow_back_ios, color: _kBlack, size: 16),
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Container(
        color: bgDark,
        child: isLoading
            ? Center(
          child: CircularProgressIndicator(
            color: _kBlack,
          ),
        )
            : activities.isEmpty
            ? Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: _kYellow,
                  shape: BoxShape.circle,
                  border: Border.all(color: _kBlack, width: 3),
                  boxShadow: [
                    BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(5, 5)),
                  ],
                ),
                child: Icon(Icons.history_toggle_off, size: 40, color: _kBlack),
              ),
              const SizedBox(height: 20),
              Text(
                "Belum ada aktivitas",
                style: TextStyle(color: _kBlack, fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              Text(
                "Pastikan server aktif",
                style: TextStyle(color: accentGrey, fontSize: 12),
              ),
            ],
          ),
        )
            : RefreshIndicator(
          onRefresh: _loadActivities,
          color: _kBlack,
          backgroundColor: _kYellow,
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: activities.length,
            itemBuilder: (context, index) {
              final activity = activities[index];
              return _buildActivityCard(activity);
            },
          ),
        ),
      ),
    );
  }

  Widget _buildActivityCard(ActivityModel activity) {
    Color iconColor;
    IconData iconData;
    String typeLabel;

    switch (activity.type) {
      case 'login':
        iconColor = _kCyan;
        iconData = Icons.login_rounded;
        typeLabel = "LOGIN";
        break;
      case 'bug':
        iconColor = _kPink;
        iconData = Icons.bug_report_outlined;
        typeLabel = "ATTACK";
        break;
      case 'create':
        iconColor = _kGreen;
        iconData = Icons.person_add_alt_1_rounded;
        typeLabel = "ACCOUNT";
        break;
      default:
        iconColor = _kYellow;
        iconData = Icons.info_outline;
        typeLabel = "SYSTEM";
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _kBlack, width: 2),
        boxShadow: [
          BoxShadow(
            color: _kBlack,
            blurRadius: 0,
            offset: const Offset(3, 3),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: iconColor,
              shape: BoxShape.circle,
              border: Border.all(color: _kBlack, width: 2),
              boxShadow: [
                BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(2, 2)),
              ],
            ),
            child: Icon(iconData, color: _kBlack, size: 24),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        activity.title,
                        style: TextStyle(
                          color: primaryWhite,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: _kYellow,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: _kBlack, width: 1.5),
                      ),
                      child: Text(
                        typeLabel,
                        style: TextStyle(
                          color: _kBlack,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  activity.description,
                  style: TextStyle(
                    color: accentGrey,
                    fontSize: 13,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Icon(Icons.access_time, size: 12, color: _kBlack.withOpacity(0.6)),
                    const SizedBox(width: 4),
                    Text(
                      _formatDate(activity.timestamp),
                      style: TextStyle(
                        color: accentGrey,
                        fontSize: 11,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class ActivityModel {
  final String type;
  final String title;
  final String description;
  final DateTime timestamp;

  ActivityModel({
    required this.type,
    required this.title,
    required this.description,
    required this.timestamp,
  });
}