import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'widgets/custom_popup.dart';
import 'package:image_picker/image_picker.dart';

class AdminPage extends StatefulWidget {
  final String sessionKey;

  const AdminPage({
    super.key,
    required this.sessionKey,
  });

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = ['reseller', 'member'];
  String selectedRole = 'member'; 

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  String newUserRole = 'member';
  bool isLoading = false;

  XFile? _selectedImage;
  String _imageBase64 = '';

  // ─── WARNA NEOBRUTALISM ──────────────────────────────────────
  final Color bgDark = const Color(0xFFFFFDF5);
  final Color primaryPurple = const Color(0xFF000000);
  final Color accentPurple = const Color(0xFFFFDE59);
  final Color primaryWhite = const Color(0xFF000000);
  final Color textGrey = const Color(0xFF333333);
  
  final Color _kBlack = const Color(0xFF000000);
  final Color _kWhite = const Color(0xFFFFFFFF);
  final Color _kCyan = const Color(0xFF4D96FF);
  final Color _kPink = const Color(0xFFFF6B6B);
  final Color _kGreen = const Color(0xFF6BCB77);
  final Color _kOrange = const Color(0xFFFF9F45);
  final Color _kCard = const Color(0xFFFFFFFF);

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _fetchUsers();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('http://szmarket.id:2244/listUsers?key=$sessionKey'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList.sublist(start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('http://szmarket.id:2244/deleteUser?key=$sessionKey&username=$username'));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse('http://szmarket.id:2244/submitPending');
      final res = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': sessionKey,
          'username': u,
          'password': p,
          'day': d,
          'role': newUserRole,
          'imageBase64': _imageBase64,
        }),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        _alert("Sukses", "Permintaan akun dikirim! Tunggu approval Owner di Telegram.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        _imageBase64 = '';
        _selectedImage = null;
        newUserRole = 'member';
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengirim permintaan.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();
    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse('http://szmarket.id:2244/editUser?key=$sessionKey&username=$u&addDays=$d');
      final res = await http.get(url);
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    CustomPopup.display(
      context,
      title: title,
      message: message,
      icon: title.toLowerCase().contains("sukses") ? Icons.check_circle_outline : Icons.info_outline,
    );
  }

  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: TextStyle(color: primaryWhite),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: textGrey, fontSize: 13),
          prefixIcon: Icon(icon, color: _kBlack, size: 20),
          filled: true,
          fillColor: _kWhite,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: _kBlack, width: 2),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: _kBlack, width: 2),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: _kBlack, width: 2.5),
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
      ),
    );
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final image = await picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      final bytes = await File(image.path).readAsBytes();
      setState(() {
        _selectedImage = image;
        _imageBase64 = base64Encode(bytes);
      });
    }
  }

  void _showStorageQRPopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.5),
      builder: (ctx) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: _kWhite,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: _kBlack, width: 3),
              boxShadow: [
                BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(6, 6)),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: _kCyan,
                    shape: BoxShape.circle,
                    border: Border.all(color: _kBlack, width: 2),
                  ),
                  child: Icon(Icons.qr_code, color: _kBlack, size: 30),
                ),
                const SizedBox(height: 16),
                Text("STOR DISINI 5K", style: TextStyle(color: primaryWhite, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                const SizedBox(height: 16),
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: _kBlack, width: 2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Image.network(
                    'https://files.catbox.moe/h1gmom.png',
                    height: 200,
                    width: 200,
                    fit: BoxFit.contain,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  "Bayar Di @renzxso Agar Akun Di Acc",
                  style: TextStyle(color: textGrey, fontSize: 13),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  height: 45,
                  child: ElevatedButton(
                    onPressed: () => Navigator.pop(context),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _kCyan,
                      foregroundColor: _kBlack,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                        side: BorderSide(color: _kBlack, width: 2),
                      ),
                      elevation: 4,
                      shadowColor: _kBlack,
                    ),
                    child: Text("TUTUP", style: TextStyle(color: _kBlack, fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showCreateAccountPopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.4),
      builder: (ctx) => StatefulBuilder(
        builder: (context, setModalState) {
          return BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
            child: Dialog(
              backgroundColor: Colors.transparent,
              elevation: 0,
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: _kWhite,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: _kBlack, width: 3),
                  boxShadow: [
                    BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(6, 6)),
                  ],
                ),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: accentPurple,
                          shape: BoxShape.circle,
                          border: Border.all(color: _kBlack, width: 2),
                        ),
                        child: Icon(FontAwesomeIcons.userPlus, color: _kBlack, size: 30),
                      ),
                      const SizedBox(height: 16),
                      Text("CREATE ACCOUNT", style: TextStyle(color: primaryWhite, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                      const SizedBox(height: 24),
                      
                      Container(
                        width: double.infinity,
                        margin: const EdgeInsets.only(bottom: 16),
                        child: ElevatedButton.icon(
                          onPressed: () async {
                            await _pickImage();
                            setModalState(() {});
                          },
                          icon: Icon(Icons.photo, size: 20),
                          label: Text(_selectedImage == null ? "PILIH FOTO (Opsional)" : "FOTO TERPILIH ✅"),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _selectedImage == null ? _kOrange : _kGreen,
                            foregroundColor: _kBlack,
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                              side: BorderSide(color: _kBlack, width: 2),
                            ),
                            elevation: 4,
                            shadowColor: _kBlack,
                          ),
                        ),
                      ),
                      if (_selectedImage != null)
                        Container(
                          height: 100,
                          width: 100,
                          decoration: BoxDecoration(
                            border: Border.all(color: _kBlack, width: 2),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Image.file(
                            File(_selectedImage!.path),
                            fit: BoxFit.cover,
                          ),
                        ),
                      
                      _buildInput(label: "Username", controller: createUsernameController, icon: FontAwesomeIcons.user),
                      _buildInput(label: "Password", controller: createPasswordController, icon: FontAwesomeIcons.lock),
                      _buildInput(label: "Durasi (Hari)", controller: createDayController, icon: FontAwesomeIcons.calendarDay, type: TextInputType.number),
                      
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                        margin: const EdgeInsets.only(bottom: 24),
                        decoration: BoxDecoration(
                          color: _kWhite,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: _kBlack, width: 2),
                        ),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: newUserRole,
                            dropdownColor: _kWhite,
                            style: TextStyle(color: primaryWhite, fontSize: 14, fontWeight: FontWeight.bold),
                            icon: Icon(Icons.keyboard_arrow_down, color: _kBlack),
                            items: roleOptions.map((role) {
                              return DropdownMenuItem(value: role, child: Text(role.toUpperCase()));
                            }).toList(),
                            onChanged: (val) => setModalState(() => newUserRole = val ?? 'member'),
                          ),
                        ),
                      ),
                      
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.pop(context);
                            _createAccount();
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: accentPurple,
                            foregroundColor: _kBlack,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                              side: BorderSide(color: _kBlack, width: 2),
                            ),
                            elevation: 4,
                            shadowColor: _kBlack,
                          ),
                          child: Text("KIRIM REQUEST", style: TextStyle(color: _kBlack, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        }
      ),
    );
  }

  void _showExtendDurationPopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.4),
      builder: (ctx) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: _kWhite,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: _kBlack, width: 3),
              boxShadow: [
                BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(6, 6)),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: _kCyan,
                    shape: BoxShape.circle,
                    border: Border.all(color: _kBlack, width: 2),
                  ),
                  child: Icon(FontAwesomeIcons.clock, color: _kBlack, size: 30),
                ),
                const SizedBox(height: 16),
                Text("ADD DURATION", style: TextStyle(color: primaryWhite, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                const SizedBox(height: 24),
                _buildInput(label: "Username Target", controller: editUsernameController, icon: FontAwesomeIcons.userEdit),
                _buildInput(label: "Tambah Hari", controller: editDayController, icon: FontAwesomeIcons.calendarPlus, type: TextInputType.number),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                      _editUser();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _kCyan,
                      foregroundColor: _kBlack,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                        side: BorderSide(color: _kBlack, width: 2),
                      ),
                      elevation: 4,
                      shadowColor: _kBlack,
                    ),
                    child: Text("ADD DAYS", style: TextStyle(color: _kBlack, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showDeleteAccountPopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.4),
      builder: (ctx) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: _kWhite,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: _kBlack, width: 3),
              boxShadow: [
                BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(6, 6)),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: _kPink,
                    shape: BoxShape.circle,
                    border: Border.all(color: _kBlack, width: 2),
                  ),
                  child: Icon(FontAwesomeIcons.userSlash, color: _kBlack, size: 30),
                ),
                const SizedBox(height: 16),
                Text("DELETE ACCOUNT", style: TextStyle(color: primaryWhite, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                const SizedBox(height: 24),
                _buildInput(label: "Username Target", controller: deleteController, icon: FontAwesomeIcons.user),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                      _deleteUser();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _kPink,
                      foregroundColor: _kBlack,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                        side: BorderSide(color: _kBlack, width: 2),
                      ),
                      elevation: 4,
                      shadowColor: _kBlack,
                    ),
                    child: Text("DELETE", style: TextStyle(color: _kBlack, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTopButton({required String title, required IconData icon, required Color color, required VoidCallback onTap}) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          height: 100,
          decoration: BoxDecoration(
            color: _kWhite,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _kBlack, width: 2),
            boxShadow: [
              BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(4, 4)),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: color, size: 28),
              const SizedBox(height: 8),
              Text(
                title,
                textAlign: TextAlign.center,
                style: TextStyle(color: _kBlack, fontSize: 11, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      decoration: BoxDecoration(
        color: _kWhite,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _kBlack, width: 2),
        boxShadow: [
          BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(3, 3)),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: accentPurple,
              shape: BoxShape.circle,
              border: Border.all(color: _kBlack, width: 2),
            ),
            child: Icon(Icons.person, color: _kBlack, size: 24),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(user['username'], style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 4),
                Text("ROLE: ${user['role'].toString().toUpperCase()} | EXP: ${user['expiredDate']}", style: TextStyle(color: textGrey, fontSize: 12, fontFamily: 'ShareTechMono')),
              ],
            ),
          ),
          IconButton(
            icon: Icon(Icons.delete_outline, color: _kPink),
            onPressed: () {
              deleteController.text = user['username'];
              _showDeleteAccountPopup();
            },
          ),
        ],
      ),
    );
  }

  Widget _buildPagination() {
    if (totalPages <= 1) return const SizedBox.shrink();
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      alignment: WrapAlignment.center,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        final isSelected = currentPage == page;
        return InkWell(
          onTap: () => setState(() => currentPage = page),
          borderRadius: BorderRadius.circular(8),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: isSelected ? accentPurple : _kWhite,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _kBlack, width: 2),
              boxShadow: isSelected
                  ? [BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(3, 3))]
                  : [],
            ),
            child: Text("$page", style: TextStyle(color: _kBlack, fontWeight: FontWeight.bold)),
          ),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: SafeArea(
        child: isLoading && fullUserList.isEmpty
            ? Center(child: CircularProgressIndicator(color: _kBlack))
            : SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: accentPurple,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: _kBlack, width: 2),
                          ),
                          child: Icon(Icons.admin_panel_settings, color: _kBlack, size: 26),
                        ),
                        const SizedBox(width: 12),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "ADMIN PANEL",
                              style: TextStyle(color: primaryWhite, fontSize: 22, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
                            ),
                            Text(
                              "Management Dashboard",
                              style: TextStyle(color: textGrey, fontSize: 13, fontFamily: 'ShareTechMono'),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),

                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton.icon(
                        onPressed: _showStorageQRPopup,
                        icon: Icon(Icons.qr_code, size: 24, color: _kBlack),
                        label: Text("STOR DISINI 5K", style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.2, color: _kBlack)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _kCyan,
                          foregroundColor: _kBlack,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                            side: BorderSide(color: _kBlack, width: 2),
                          ),
                          elevation: 4,
                          shadowColor: _kBlack,
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),

                    Row(
                      children: [
                        _buildTopButton(title: "BUAT\nAKUN", icon: FontAwesomeIcons.userPlus, color: _kGreen, onTap: _showCreateAccountPopup),
                        const SizedBox(width: 12),
                        _buildTopButton(title: "ADD\nDURASI", icon: FontAwesomeIcons.clock, color: _kCyan, onTap: _showExtendDurationPopup),
                        const SizedBox(width: 12),
                        _buildTopButton(title: "HAPUS\nAKUN", icon: FontAwesomeIcons.userSlash, color: _kPink, onTap: _showDeleteAccountPopup),
                      ],
                    ),
                    const SizedBox(height: 30),

                    Text(
                      "USER DIRECTORY",
                      style: TextStyle(color: primaryWhite, fontSize: 16, fontWeight: FontWeight.bold, fontFamily: 'Orbitron', letterSpacing: 1.0),
                    ),
                    const SizedBox(height: 16),
                    
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                      decoration: BoxDecoration(
                        color: _kWhite,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: _kBlack, width: 2),
                        boxShadow: [
                          BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(3, 3)),
                        ],
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: selectedRole,
                          dropdownColor: _kWhite,
                          isExpanded: true,
                          style: TextStyle(color: primaryWhite, fontSize: 15, fontWeight: FontWeight.bold),
                          icon: Icon(Icons.keyboard_arrow_down, color: _kBlack),
                          items: roleOptions.map((role) {
                            return DropdownMenuItem(value: role, child: Text(role.toUpperCase()));
                          }).toList(),
                          onChanged: (val) {
                            if (val != null) {
                              setState(() {
                                selectedRole = val;
                                _filterAndPaginate();
                              });
                            }
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),

                    if (isLoading && fullUserList.isNotEmpty)
                      Center(child: Padding(padding: const EdgeInsets.all(20), child: CircularProgressIndicator(color: _kBlack))),
                    
                    if (filteredList.isEmpty && !isLoading)
                      Center(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 40),
                          child: Text("Belum ada user di kategori ini.", style: TextStyle(color: textGrey)),
                        ),
                      ),

                    ..._getCurrentPageData().map((u) => _buildUserItem(u)).toList(),
                    
                    const SizedBox(height: 20),
                    Center(child: _buildPagination()),
                    const SizedBox(height: 40),
                  ],
                ),
              ),
      ),
    );
  }
}