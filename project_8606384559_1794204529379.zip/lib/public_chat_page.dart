// public_chat_page.dart - NEOBRUTALISM VERSION
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import 'package:record/record.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'theme_provider.dart';
import 'config.dart';

class PublicChatPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const PublicChatPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<PublicChatPage> createState() => _PublicChatPageState();
}

class _PublicChatPageState extends State<PublicChatPage> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  List<ChatMessage> _messages = [];
  bool _isLoading = true;
  bool _isSending = false;
  int _onlineCount = 0;
  Timer? _pollingTimer;
  String? _lastMessageId;
  String get _baseUrl => ApiConfig.baseUrl;

  // Audio Recording
  bool _isRecording = false;
  AudioRecorder? _audioRecorder;
  String? _audioPath;
  Timer? _recordTimer;
  int _recordDuration = 0;

  // ─── TEMA NEOBRUTALISM ───────────────────────────────────────
  static const Color _kBlack = Color(0xFF000000);
  static const Color _kWhite = Color(0xFFFFFFFF);
  static const Color _kCyan = Color(0xFF4D96FF);
  static const Color _kPink = Color(0xFFFF6B6B);
  static const Color _kGreen = Color(0xFF6BCB77);
  static const Color _kOrange = Color(0xFFFF9F45);
  static const Color _kYellow = Color(0xFFFFDE59);
  static const Color _kBg = Color(0xFFFFFDF5);

  // Sticker list
  final List<String> _stickers = [
    'assets/stickers/1.jpg',
    'assets/stickers/2.jpg',
    'assets/stickers/3.jpg',
    'assets/stickers/4.jpg',
    'assets/stickers/5.jpg',
    'assets/stickers/6.jpg',
    'assets/stickers/7.jpg',
    'assets/stickers/8.jpg',
    'assets/stickers/9.jpg',
    'assets/stickers/10.jpg',
  ];

  // Overlay State
  OverlayEntry? _stickerOverlay;
  OverlayEntry? _attachmentOverlay;

  @override
  void initState() {
    super.initState();
    _loadMessages();
    _startPolling();
    _fetchOnlineUsers();
    _startOnlinePolling();
    _checkPermissions();
    _audioRecorder = AudioRecorder();
  }

  @override
  void dispose() {
    _pollingTimer?.cancel();
    _onlineTimer?.cancel();
    _recordTimer?.cancel();
    _messageController.dispose();
    _scrollController.dispose();
    _audioRecorder?.dispose();
    _stickerOverlay?.remove();
    _attachmentOverlay?.remove();
    super.dispose();
  }

  Future<void> _checkPermissions() async {
    final status = await Permission.microphone.request();
    if (!status.isGranted) {
      _showSnackBar('Izin mikrofon diperlukan untuk voice note', isError: true);
    }
  }

  void _startPolling() {
    _pollingTimer = Timer.periodic(const Duration(seconds: 3), (_) {
      _checkNewMessages();
    });
  }

  Timer? _onlineTimer;

  void _startOnlinePolling() {
    _onlineTimer = Timer.periodic(const Duration(seconds: 10), (_) {
      _fetchOnlineUsers();
    });
  }

  Future<void> _checkNewMessages() async {
    if (_lastMessageId == null) return;

    try {
      final response = await http.get(
        Uri.parse(
            '$_baseUrl/getPublicChat?key=${widget.sessionKey}&lastId=$_lastMessageId'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          final newMessages = (data['messages'] as List)
              .map((item) => ChatMessage.fromJson(item))
              .toList();

          if (newMessages.isNotEmpty) {
            setState(() {
              _messages.insertAll(0, newMessages);
              _lastMessageId = _messages.first.id;
            });
          }
        }
      }
    } catch (e) {
      print('Error checking new messages: $e');
    }
  }

  Future<void> _loadMessages() async {
    setState(() => _isLoading = true);

    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/getPublicChat?key=${widget.sessionKey}'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _messages = (data['messages'] as List)
                .map((item) => ChatMessage.fromJson(item))
                .toList();
            if (_messages.isNotEmpty) {
              _lastMessageId = _messages.first.id;
            }
          });
        }
      }
    } catch (e) {
      print('Error loading messages: $e');
    } finally {
      setState(() => _isLoading = false);
      _scrollToBottom();
    }
  }

  Future<void> _fetchOnlineUsers() async {
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/getOnlineUsers?key=${widget.sessionKey}'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _onlineCount = data['count'] ?? 0;
          });
        }
      }
    } catch (e) {
      print('Error fetching online users: $e');
    }
  }

  Future<void> _sendMessage({String? type, String? content}) async {
    final message = _messageController.text.trim();
    if (message.isEmpty && type == null) return;

    setState(() => _isSending = true);

    try {
      final payload = {
        'key': widget.sessionKey,
        'message': type == 'text' ? message : '',
      };

      if (type != null) {
        payload['type'] = type;
        if (content != null) payload['content'] = content;
      }

      final response = await http.post(
        Uri.parse('$_baseUrl/sendPublicChat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(payload),
      );

      final data = jsonDecode(response.body);
      if (data['valid'] == true) {
        _messageController.clear();
        final newMessage = ChatMessage.fromJson(data['message']);
        setState(() {
          _messages.insert(0, newMessage);
          _lastMessageId = newMessage.id;
        });
        _scrollToBottom();
      } else {
        _showSnackBar(data['message'] ?? 'Gagal mengirim pesan', isError: true);
      }
    } catch (e) {
      print('Error sending message: $e');
      _showSnackBar('Gagal mengirim pesan', isError: true);
    } finally {
      setState(() => _isSending = false);
    }
  }

  Future<void> _sendImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);

    if (picked != null) {
      final bytes = await File(picked.path).readAsBytes();
      final base64Image = base64Encode(bytes);

      try {
        final response = await http.post(
          Uri.parse('$_baseUrl/sendPublicChat'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'key': widget.sessionKey,
            'type': 'image',
            'content': base64Image,
            'filename': picked.name,
          }),
        );

        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          final newMessage = ChatMessage.fromJson(data['message']);
          setState(() {
            _messages.insert(0, newMessage);
            _lastMessageId = newMessage.id;
          });
          _scrollToBottom();
        } else {
          _showSnackBar(data['message'] ?? 'Gagal mengirim gambar', isError: true);
        }
      } catch (e) {
        _showSnackBar('Gagal mengirim gambar', isError: true);
      }
    }
  }

  Future<void> _sendSticker(String stickerPath) async {
    try {
      final ByteData data = await rootBundle.load(stickerPath);
      final bytes = data.buffer.asUint8List();
      final base64Sticker = base64Encode(bytes);

      final response = await http.post(
        Uri.parse('$_baseUrl/sendPublicChat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'type': 'sticker',
          'content': base64Sticker,
          'filename': stickerPath.split('/').last,
        }),
      );

      final dataJson = jsonDecode(response.body);
      if (dataJson['valid'] == true) {
        final newMessage = ChatMessage.fromJson(dataJson['message']);
        setState(() {
          _messages.insert(0, newMessage);
          _lastMessageId = newMessage.id;
        });
        _scrollToBottom();
        _closeStickerOverlay();
      } else {
        _showSnackBar(dataJson['message'] ?? 'Gagal mengirim sticker', isError: true);
      }
    } catch (e) {
      print('Error sending sticker: $e');
      _showSnackBar('Gagal mengirim sticker', isError: true);
    }
  }

  Future<void> _startRecording() async {
    final status = await Permission.microphone.request();
    if (!status.isGranted) {
      _showSnackBar('Izin mikrofon diperlukan', isError: true);
      return;
    }

    try {
      final directory = await getApplicationDocumentsDirectory();
      final path = '${directory.path}/voice_${DateTime.now().millisecondsSinceEpoch}.m4a';
      
      await _audioRecorder!.start(
        const RecordConfig(),
        path: path,
      );
      
      setState(() {
        _isRecording = true;
        _recordDuration = 0;
        _audioPath = path;
      });

      _recordTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
        if (mounted) {
          setState(() {
            _recordDuration++;
          });
        }
      });
    } catch (e) {
      print('Recording error: $e');
      _showSnackBar('Gagal memulai rekaman', isError: true);
    }
  }

  Future<void> _stopRecording() async {
    _recordTimer?.cancel();
    
    if (_audioRecorder != null && _isRecording) {
      try {
        final path = await _audioRecorder!.stop();
        
        setState(() {
          _isRecording = false;
          _audioPath = path;
        });

        if (path != null && await File(path).exists()) {
          final bytes = await File(path).readAsBytes();
          final base64Audio = base64Encode(bytes);

          try {
            final response = await http.post(
              Uri.parse('$_baseUrl/sendPublicChat'),
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode({
                'key': widget.sessionKey,
                'type': 'voice',
                'content': base64Audio,
                'duration': _recordDuration,
                'filename': 'voice_${DateTime.now().millisecondsSinceEpoch}.m4a',
              }),
            );

            final data = jsonDecode(response.body);
            if (data['valid'] == true) {
              final newMessage = ChatMessage.fromJson(data['message']);
              setState(() {
                _messages.insert(0, newMessage);
                _lastMessageId = newMessage.id;
              });
              _scrollToBottom();
            } else {
              _showSnackBar(data['message'] ?? 'Gagal mengirim voice note', isError: true);
            }
          } catch (e) {
            print('Send voice error: $e');
            _showSnackBar('Gagal mengirim voice note', isError: true);
          }
        }

        setState(() => _audioPath = null);
      } catch (e) {
        print('Stop recording error: $e');
        _showSnackBar('Gagal menghentikan rekaman', isError: true);
      }
    }
  }

  Future<void> _deleteMessage(String messageId, String messageUsername) async {
    final canDelete = widget.role == 'owner' || widget.username == messageUsername;

    if (!canDelete) {
      _showSnackBar('Tidak bisa menghapus pesan orang lain', isError: true);
      return;
    }

    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: TweenAnimationBuilder(
          duration: const Duration(milliseconds: 300),
          tween: Tween<double>(begin: 0, end: 1),
          builder: (context, double scale, child) {
            return Transform.scale(scale: scale, child: child);
          },
          child: Container(
            margin: const EdgeInsets.all(20),
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: _kWhite,
              borderRadius: BorderRadius.circular(32),
              border: Border.all(color: _kBlack, width: 3),
              boxShadow: [
                BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(6, 6)),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: _kPink,
                    shape: BoxShape.circle,
                    border: Border.all(color: _kBlack, width: 2),
                  ),
                  child: const Icon(Icons.warning_amber_rounded,
                      color: _kBlack, size: 32),
                ),
                const SizedBox(height: 20),
                const Text(
                  "Hapus Pesan",
                  style: TextStyle(
                    color: _kBlack,
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  "Yakin ingin menghapus pesan ini?",
                  style: TextStyle(color: Colors.black54, fontSize: 14),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () => Navigator.pop(context, false),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            color: _kWhite,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: _kBlack, width: 2),
                          ),
                          child: Center(
                            child: Text(
                              "BATAL",
                              style: TextStyle(color: _kBlack, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: GestureDetector(
                        onTap: () => Navigator.pop(context, true),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            color: _kPink,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: _kBlack, width: 2),
                            boxShadow: [
                              BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(3, 3)),
                            ],
                          ),
                          child: const Center(
                            child: Text(
                              "HAPUS",
                              style: TextStyle(color: _kBlack, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );

    if (confirm != true) return;

    try {
      final response = await http.delete(
        Uri.parse('$_baseUrl/deletePublicChat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'messageId': messageId,
        }),
      );

      final data = jsonDecode(response.body);
      if (data['valid'] == true) {
        setState(() {
          _messages.removeWhere((m) => m.id == messageId);
        });
        _showSnackBar('Pesan berhasil dihapus', isError: false);
      } else {
        _showSnackBar(data['message'] ?? 'Gagal menghapus pesan', isError: true);
      }
    } catch (e) {
      print('Error deleting message: $e');
      _showSnackBar('Gagal menghapus pesan', isError: true);
    }
  }

  void _showSnackBar(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isError ? Icons.error_outline : Icons.check_circle_outline,
              color: _kBlack,
              size: 20,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                msg,
                style: const TextStyle(color: _kBlack, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        backgroundColor: isError ? _kPink : _kGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: _kBlack, width: 2),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          0,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Color _getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case 'owner':
        return _kPink;
      case 'admin':
        return _kOrange;
      case 'moderator':
        return _kCyan;
      case 'partner':
        return _kCyan;
      case 'seller':
      case 'reseller':
        return _kGreen;
      default:
        return const Color(0xFF333333);
    }
  }

  // ===== OVERLAY METHODS =====
  void _showStickerOverlay() {
    _closeAttachmentOverlay();
    if (_stickerOverlay != null) {
      _closeStickerOverlay();
      return;
    }

    final overlay = Overlay.of(context);

    _stickerOverlay = OverlayEntry(
      builder: (context) => Positioned(
        bottom: 80,
        left: 0,
        right: 0,
        child: Material(
          color: Colors.transparent,
          child: Container(
            height: 300,
            margin: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: _kWhite,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: _kBlack, width: 3),
              boxShadow: [
                BoxShadow(
                  color: _kBlack,
                  blurRadius: 0,
                  offset: const Offset(6, 6),
                ),
              ],
            ),
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    border: Border(bottom: BorderSide(color: _kBlack, width: 2)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 4,
                            height: 18,
                            decoration: BoxDecoration(
                              color: _kYellow,
                              borderRadius: BorderRadius.circular(2),
                              border: Border.all(color: _kBlack, width: 1.5),
                            ),
                          ),
                          const SizedBox(width: 8),
                          const Text(
                            "STICKERS",
                            style: TextStyle(
                              color: _kBlack,
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                        ],
                      ),
                      IconButton(
                        icon: const Icon(Icons.close_rounded, color: _kBlack),
                        onPressed: _closeStickerOverlay,
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: GridView.builder(
                    padding: const EdgeInsets.all(12),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 4,
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 8,
                    ),
                    itemCount: _stickers.length,
                    itemBuilder: (context, index) {
                      return GestureDetector(
                        onTap: () => _sendSticker(_stickers[index]),
                        child: Container(
                          decoration: BoxDecoration(
                            color: _kWhite,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: _kBlack, width: 2),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Image.asset(
                              _stickers[index],
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Center(
                                child: Icon(Icons.sticky_note_2_rounded, color: _kBlack, size: 32),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );

    overlay.insert(_stickerOverlay!);
  }

  void _closeStickerOverlay() {
    _stickerOverlay?.remove();
    _stickerOverlay = null;
  }

  void _showAttachmentOverlay() {
    _closeStickerOverlay();
    if (_attachmentOverlay != null) {
      _closeAttachmentOverlay();
      return;
    }

    final overlay = Overlay.of(context);

    _attachmentOverlay = OverlayEntry(
      builder: (context) => Positioned(
        bottom: 80,
        left: 0,
        right: 0,
        child: Material(
          color: Colors.transparent,
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 12),
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
            decoration: BoxDecoration(
              color: _kWhite,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: _kBlack, width: 3),
              boxShadow: [
                BoxShadow(
                  color: _kBlack,
                  blurRadius: 0,
                  offset: const Offset(6, 6),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildAttachmentButton(
                      icon: Icons.photo_rounded,
                      label: "Gambar",
                      color: _kCyan,
                      onTap: () {
                        _closeAttachmentOverlay();
                        _sendImage();
                      },
                    ),
                    _buildAttachmentButton(
                      icon: Icons.mic_rounded,
                      label: _isRecording ? "Stop" : "Voice",
                      color: _isRecording ? _kPink : _kOrange,
                      onTap: () {
                        if (_isRecording) {
                          _stopRecording();
                        } else {
                          _startRecording();
                        }
                        _closeAttachmentOverlay();
                      },
                    ),
                    _buildAttachmentButton(
                      icon: Icons.sticky_note_2_rounded,
                      label: "Sticker",
                      color: _kYellow,
                      onTap: () {
                        _closeAttachmentOverlay();
                        _showStickerOverlay();
                      },
                    ),
                  ],
                ),
                if (_isRecording) ...[
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: _kPink,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _kBlack, width: 2),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.circle, color: _kBlack, size: 12),
                        const SizedBox(width: 8),
                        Text(
                          'Merekam... ${_formatDuration(_recordDuration)}',
                          style: const TextStyle(color: _kBlack, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );

    overlay.insert(_attachmentOverlay!);
  }

  void _closeAttachmentOverlay() {
    _attachmentOverlay?.remove();
    _attachmentOverlay = null;
  }

  Widget _buildAttachmentButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              border: Border.all(color: _kBlack, width: 2),
              boxShadow: [
                BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(3, 3)),
              ],
            ),
            child: Icon(icon, color: _kBlack, size: 26),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            style: TextStyle(
              color: _kBlack,
              fontSize: 11,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  String _formatDuration(int seconds) {
    final minutes = seconds ~/ 60;
    final secs = seconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Provider.of<ThemeProvider>(context);

    return Scaffold(
      backgroundColor: _kBg,
      appBar: AppBar(
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: _kYellow,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: _kBlack, width: 2),
            boxShadow: [
              BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(3, 3)),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.public_rounded, color: _kBlack, size: 18),
              const SizedBox(width: 8),
              const Text(
                "PUBLIC CHAT",
                style: TextStyle(
                  color: _kBlack,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
        ),
        backgroundColor: _kBg,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: _kYellow,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _kBlack, width: 2),
              boxShadow: [
                BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(2, 2)),
              ],
            ),
            child: const Icon(Icons.arrow_back_ios_new, color: _kBlack, size: 18),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 12),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: _kGreen,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _kBlack, width: 2),
              boxShadow: [
                BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(2, 2)),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: _kBlack,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  '$_onlineCount Online',
                  style: TextStyle(
                    color: _kBlack,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      body: Container(
        color: _kBg,
        child: Column(
          children: [
            Expanded(
              child: _isLoading
                  ? Center(
                      child: CircularProgressIndicator(color: _kBlack, strokeWidth: 3),
                    )
                  : _messages.isEmpty
                      ? Center(
                          child: TweenAnimationBuilder(
                            duration: const Duration(milliseconds: 600),
                            tween: Tween<double>(begin: 0, end: 1),
                            builder: (context, double value, child) {
                              return Opacity(
                                opacity: value,
                                child: Transform.translate(
                                  offset: Offset(0, 20 * (1 - value)),
                                  child: child,
                                ),
                              );
                            },
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(32),
                                  decoration: BoxDecoration(
                                    color: _kYellow,
                                    shape: BoxShape.circle,
                                    border: Border.all(color: _kBlack, width: 3),
                                    boxShadow: [
                                      BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(5, 5)),
                                    ],
                                  ),
                                  child: const Icon(Icons.chat_bubble_outline,
                                      size: 64, color: _kBlack),
                                ),
                                const SizedBox(height: 20),
                                const Text(
                                  'Belum ada pesan',
                                  style: TextStyle(color: _kBlack, fontSize: 14, fontWeight: FontWeight.bold),
                                ),
                                const SizedBox(height: 8),
                                const Text(
                                  'Jadilah yang pertama mengirim pesan',
                                  style: TextStyle(color: Colors.black54, fontSize: 12),
                                ),
                              ],
                            ),
                          ),
                        )
                      : ListView.builder(
                          controller: _scrollController,
                          reverse: true,
                          padding: const EdgeInsets.all(12),
                          itemCount: _messages.length,
                          itemBuilder: (context, index) {
                            final msg = _messages[index];
                            final isMe = msg.username == widget.username;
                            return GestureDetector(
                              onLongPress: () => _deleteMessage(msg.id, msg.username),
                              child: TweenAnimationBuilder(
                                duration: Duration(milliseconds: 200 + (index * 20)),
                                tween: Tween<double>(begin: 0, end: 1),
                                builder: (context, double value, child) {
                                  return Opacity(
                                    opacity: value,
                                    child: Transform.translate(
                                      offset: Offset(0, 20 * (1 - value)),
                                      child: child,
                                    ),
                                  );
                                },
                                child: _buildMessageBubble(msg, isMe),
                              ),
                            );
                          },
                        ),
            ),

            // Input bar
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: _kWhite,
                border: Border(
                  top: BorderSide(color: _kBlack, width: 2),
                ),
                boxShadow: [
                  BoxShadow(color: _kBlack.withOpacity(0.15), blurRadius: 0, offset: const Offset(0, -3)),
                ],
              ),
              child: Row(
                children: [
                  // Attachment button
                  GestureDetector(
                    onTap: _showAttachmentOverlay,
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: _kYellow,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: _kBlack, width: 2),
                        boxShadow: [
                          BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(2, 2)),
                        ],
                      ),
                      child: const Icon(Icons.attach_file_rounded,
                          color: _kBlack, size: 22),
                    ),
                  ),
                  const SizedBox(width: 8),

                  // Text input
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: _kWhite,
                        borderRadius: BorderRadius.circular(28),
                        border: Border.all(color: _kBlack, width: 2),
                      ),
                      child: TextField(
                        controller: _messageController,
                        style: const TextStyle(color: _kBlack),
                        maxLines: null,
                        decoration: InputDecoration(
                          hintText: 'Tulis pesan...',
                          hintStyle: TextStyle(color: Colors.black38),
                          border: InputBorder.none,
                          contentPadding:
                              const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                        ),
                        onSubmitted: (_) => _sendMessage(type: 'text'),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),

                  // Send button
                  GestureDetector(
                    onTap: _isSending ? null : () => _sendMessage(type: 'text'),
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: _kYellow,
                        shape: BoxShape.circle,
                        border: Border.all(color: _kBlack, width: 2),
                        boxShadow: [
                          BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(3, 3)),
                        ],
                      ),
                      child: _isSending
                          ? const SizedBox(
                              width: 22,
                              height: 22,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: _kBlack,
                              ),
                            )
                          : const Icon(Icons.send_rounded,
                              color: _kBlack, size: 20),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMessageBubble(ChatMessage msg, bool isMe) {
    final isImage = msg.type == 'image';
    final isSticker = msg.type == 'sticker';
    final isVoice = msg.type == 'voice';

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: Row(
        mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!isMe) ...[
            Container(
              width: 42,
              height: 42,
              margin: const EdgeInsets.only(right: 10),
              decoration: BoxDecoration(
                color: _kYellow,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _kBlack, width: 2),
                boxShadow: [
                  BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(2, 2)),
                ],
              ),
              child: Center(
                child: Text(
                  msg.username.isNotEmpty ? msg.username[0].toUpperCase() : '?',
                  style: const TextStyle(
                    color: _kBlack,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
          Flexible(
            child: Container(
              constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width * 0.75,
              ),
              padding: isSticker ? EdgeInsets.zero : const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: isSticker
                  ? null
                  : BoxDecoration(
                      color: isMe ? _kYellow : _kWhite,
                      borderRadius: BorderRadius.circular(20).copyWith(
                        bottomRight: isMe ? const Radius.circular(6) : const Radius.circular(20),
                        bottomLeft: isMe ? const Radius.circular(20) : const Radius.circular(6),
                      ),
                      border: Border.all(color: _kBlack, width: 2),
                      boxShadow: [
                        BoxShadow(
                          color: _kBlack,
                          blurRadius: 0,
                          offset: const Offset(3, 3),
                        ),
                      ],
                    ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (!isMe && !isSticker)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: Row(
                        children: [
                          Text(
                            msg.username,
                            style: TextStyle(
                              color: _getRoleColor(msg.role),
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          if (msg.role == 'owner') ...[
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: _kPink,
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: _kBlack, width: 1.5),
                              ),
                              child: const Text(
                                "OWNER",
                                style: TextStyle(
                                  color: _kBlack,
                                  fontSize: 8,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  
                  // Content based on type
                  if (isImage)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.memory(
                        base64Decode(msg.content!),
                        fit: BoxFit.cover,
                        width: 200,
                        height: 200,
                      ),
                    )
                  else if (isSticker)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.memory(
                        base64Decode(msg.content!),
                        fit: BoxFit.contain,
                        width: 120,
                        height: 120,
                      ),
                    )
                  else if (isVoice)
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.mic_rounded,
                          color: _kBlack,
                          size: 20,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'Voice Note (${_formatDuration(msg.duration ?? 0)})',
                          style: TextStyle(
                            color: _kBlack,
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    )
                  else
                    Text(
                      msg.message,
                      style: TextStyle(
                        color: _kBlack,
                        fontSize: 13,
                        fontWeight: isMe ? FontWeight.bold : FontWeight.normal,
                      ),
                      softWrap: true,
                    ),

                  if (!isSticker) ...[
                    const SizedBox(height: 4),
                    Text(
                      msg.formattedTime,
                      style: TextStyle(
                        color: _kBlack.withOpacity(0.6),
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// Model ChatMessage
class ChatMessage {
  final String id;
  final String username;
  final String role;
  final String message;
  final String timestamp;
  final String formattedTime;
  final String? type;
  final String? content;
  final int? duration;

  ChatMessage({
    required this.id,
    required this.username,
    required this.role,
    required this.message,
    required this.timestamp,
    required this.formattedTime,
    this.type,
    this.content,
    this.duration,
  });

  factory ChatMessage.fromJson(Map<String, dynamic> json) {
    return ChatMessage(
      id: json['id'] ?? '',
      username: json['username'] ?? '',
      role: json['role'] ?? 'member',
      message: json['message'] ?? '',
      timestamp: json['timestamp'] ?? DateTime.now().toIso8601String(),
      formattedTime: json['formattedTime'] ?? '',
      type: json['type'],
      content: json['content'],
      duration: json['duration'],
    );
  }
}