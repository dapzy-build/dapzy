import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter/services.dart';
import 'change_password_page.dart';

class ProfilePage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final String? uid;

  const ProfilePage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    this.uid,
  });

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> with TickerProviderStateMixin {
  File? _profileImage;
  final ImagePicker _picker = ImagePicker();

  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  // ─── TEMA NEOBRUTALISM ───────────────────────────────────────
  final Color bgDark = const Color(0xFFFFFDF5);
  final Color primaryPurple = const Color(0xFFFFDE59);
  final Color accentPurple = const Color(0xFFFFDE59);
  final Color primaryWhite = const Color(0xFF000000);

  final Color cardGlass = const Color(0xFFFFFFFF);
  final Color borderGlass = const Color(0xFF000000);

  final Color _kBlack = const Color(0xFF000000);
  final Color _kWhite = const Color(0xFFFFFFFF);
  final Color _kCyan = const Color(0xFF4D96FF);
  final Color _kPink = const Color(0xFFFF6B6B);
  final Color _kGreen = const Color(0xFF6BCB77);
  final Color _kOrange = const Color(0xFFFF9F45);
  final Color _kYellow = const Color(0xFFFFDE59);

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.15, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
    _loadProfileImage();
  }

  @override
  void dispose() {
    _glowController.dispose();
    super.dispose();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_${widget.username}');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  String _censorText(String text, {bool isPassword = false}) {
    if (text.isEmpty) return "N/A";
    if (isPassword) return "••••••••";
    if (text.length <= 2) return "${text.substring(0, 1)}••";
    return "${text.substring(0, 2)}${'•' * (text.length - 2)}";
  }

  Future<void> _showImageSourceDialog() {
    return showModalBottomSheet(
      context: context,
      backgroundColor: cardGlass,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        decoration: BoxDecoration(
          border: Border(
            top: BorderSide(color: _kBlack, width: 2),
          ),
        ),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 8),
              Container(
                width: 40,
                height: 3,
                decoration: BoxDecoration(
                  color: _kBlack,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 16),
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _kYellow,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _kBlack, width: 2),
                  ),
                  child: Icon(Icons.camera_alt, color: _kBlack, size: 18),
                ),
                title: Text(
                  "Kamera",
                  style: TextStyle(
                    color: primaryWhite,
                    fontFamily: 'ShareTechMono',
                    fontSize: 14,
                    letterSpacing: 1,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.camera);
                },
              ),
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _kCyan,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _kBlack, width: 2),
                  ),
                  child: Icon(Icons.photo_library, color: _kBlack, size: 18),
                ),
                title: Text(
                  "Galeri",
                  style: TextStyle(
                    color: primaryWhite,
                    fontFamily: 'ShareTechMono',
                    fontSize: 14,
                    letterSpacing: 1,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.gallery);
                },
              ),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
        source: source,
        imageQuality: 70,
      );
      if (pickedFile != null) {
        final File imageFile = File(pickedFile.path);
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('profile_image_${widget.username}', imageFile.path);
        setState(() {
          _profileImage = imageFile;
        });
      }
    } catch (e) {
      debugPrint("Error picking image: $e");
    }
  }

  Widget _buildRoleBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      decoration: BoxDecoration(
        color: _kYellow,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: _kBlack, width: 2),
        boxShadow: [
          BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(2, 2)),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              color: _kBlack,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 8),
          Text(
            widget.role.toUpperCase(),
            style: TextStyle(
              color: _kBlack,
              fontSize: 11,
              fontWeight: FontWeight.w800,
              fontFamily: 'Orbitron',
              letterSpacing: 2,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoCard({
    required IconData icon,
    required String label,
    required String value,
    bool fullWidth = false,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: fullWidth ? 18 : 14,
        vertical: 16,
      ),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _kBlack, width: 2),
        boxShadow: [
          BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(3, 3)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: _kYellow,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _kBlack, width: 2),
                ),
                child: Icon(icon, color: _kBlack, size: 15),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  label,
                  style: TextStyle(
                    color: primaryWhite.withOpacity(0.7),
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            value,
            style: TextStyle(
              color: primaryWhite,
              fontSize: 13,
              fontWeight: FontWeight.w700,
              fontFamily: 'ShareTechMono',
              letterSpacing: 0.5,
            ),
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
          ),
        ],
      ),
    );
  }

  Widget _buildChangePasswordButton() {
    return AnimatedBuilder(
      animation: _glowAnimation,
      builder: (context, _) {
        return Container(
          width: double.infinity,
          height: 54,
          decoration: BoxDecoration(
            color: _kYellow,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: _kBlack,
              width: 2,
            ),
            boxShadow: [
              BoxShadow(
                color: _kBlack,
                blurRadius: 0,
                offset: const Offset(4, 4),
              ),
            ],
          ),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ChangePasswordPage(
                      username: widget.username,
                      sessionKey: widget.sessionKey,
                    ),
                  ),
                );
              },
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.lock_reset_rounded, color: _kBlack, size: 20),
                  const SizedBox(width: 12),
                  Text(
                    "CHANGE PASSWORD",
                    style: TextStyle(
                      color: _kBlack,
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      fontFamily: 'Orbitron',
                      letterSpacing: 2,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildUidCard() {
    final String uid = widget.uid ?? 'Tidak ada UID';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _kBlack, width: 2),
        boxShadow: [
          BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(3, 3)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: _kYellow,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _kBlack, width: 2),
                ),
                child: Icon(Icons.badge_rounded, color: _kBlack, size: 15),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  "UID / ID",
                  style: TextStyle(
                    color: primaryWhite.withOpacity(0.7),
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              GestureDetector(
                onTap: () {
                  Clipboard.setData(ClipboardData(text: uid));
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('✅ UID berhasil disalin!', style: TextStyle(color: _kBlack, fontWeight: FontWeight.bold)),
                      backgroundColor: _kGreen,
                      behavior: SnackBarBehavior.floating,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                        side: BorderSide(color: _kBlack, width: 2),
                      ),
                      duration: const Duration(seconds: 2),
                    ),
                  );
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: _kYellow,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _kBlack, width: 2),
                    boxShadow: [
                      BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(2, 2)),
                    ],
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.copy_rounded, color: _kBlack, size: 14),
                      const SizedBox(width: 4),
                      Text(
                        "SALIN",
                        style: TextStyle(
                          color: _kBlack,
                          fontSize: 9,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            uid,
            style: TextStyle(
              color: primaryWhite,
              fontSize: 13,
              fontWeight: FontWeight.w700,
              fontFamily: 'ShareTechMono',
              letterSpacing: 0.5,
            ),
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        backgroundColor: bgDark,
        elevation: 0,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: _kYellow,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _kBlack, width: 2),
              boxShadow: [
                BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(2, 2)),
              ],
            ),
            child: Icon(Icons.arrow_back_ios_new, color: _kBlack, size: 16),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "MY PROFILE",
              style: TextStyle(
                color: primaryWhite,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.w900,
                fontSize: 14,
                letterSpacing: 2,
              ),
            ),
          ],
        ),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(2),
          child: Container(
            height: 2,
            color: _kBlack,
          ),
        ),
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Column(
          children: [
            const SizedBox(height: 12),

            Center(
              child: GestureDetector(
                onTap: _showImageSourceDialog,
                child: Stack(
                  children: [
                    AnimatedBuilder(
                      animation: _glowAnimation,
                      builder: (context, _) {
                        return Container(
                          width: 110,
                          height: 110,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _kYellow,
                            border: Border.all(
                              color: _kBlack,
                              width: 3,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: _kBlack,
                                blurRadius: 0,
                                offset: const Offset(5, 5),
                              ),
                            ],
                          ),
                          child: ClipOval(
                            child: _profileImage != null
                                ? Image.file(
                                    _profileImage!,
                                    fit: BoxFit.cover,
                                  )
                                : Center(
                                    child: Icon(
                                      FontAwesomeIcons.userAstronaut,
                                      size: 40,
                                      color: _kBlack.withOpacity(0.4),
                                    ),
                                  ),
                          ),
                        );
                      },
                    ),
                    Positioned(
                      bottom: 2,
                      right: 2,
                      child: Container(
                        padding: const EdgeInsets.all(7),
                        decoration: BoxDecoration(
                          color: _kCyan,
                          shape: BoxShape.circle,
                          border: Border.all(color: _kBlack, width: 3),
                          boxShadow: [
                            BoxShadow(
                              color: _kBlack,
                              blurRadius: 0,
                              offset: const Offset(2, 2),
                            ),
                          ],
                        ),
                        child: Icon(Icons.camera_alt, size: 14, color: _kBlack),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 20),

            Text(
              widget.username,
              style: TextStyle(
                color: primaryWhite,
                fontSize: 22,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                letterSpacing: 2,
              ),
            ),

            const SizedBox(height: 10),

            _buildRoleBadge(),

            const SizedBox(height: 32),

            _buildSectionTitle("ACCOUNT DATA"),

            const SizedBox(height: 14),

            Row(
              children: [
                Expanded(child: _buildInfoCard(icon: Icons.person_outline, label: "USERNAME", value: _censorText(widget.username))),
                const SizedBox(width: 12),
                Expanded(child: _buildInfoCard(icon: Icons.lock_outline, label: "PASSWORD", value: _censorText(widget.password, isPassword: true))),
              ],
            ),

            const SizedBox(height: 12),

            Row(
              children: [
                Expanded(child: _buildInfoCard(icon: Icons.verified_user_outlined, label: "ROLE", value: widget.role.toUpperCase())),
                const SizedBox(width: 12),
                Expanded(child: _buildInfoCard(icon: Icons.calendar_today_outlined, label: "EXPIRED", value: widget.expiredDate)),
              ],
            ),

            const SizedBox(height: 12),

            _buildInfoCard(
              icon: Icons.vpn_key_rounded,
              label: "SESSION KEY",
              value: "${widget.sessionKey.substring(0, 8)}...",
              fullWidth: true,
            ),

            const SizedBox(height: 12),

            _buildUidCard(),

            const SizedBox(height: 40),

            _buildChangePasswordButton(),

            const SizedBox(height: 32),

            _buildFooter(),

            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 16,
          decoration: BoxDecoration(
            color: _kBlack,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 10),
        Text(
          title,
          style: TextStyle(
            color: primaryWhite.withOpacity(0.7),
            fontSize: 10,
            fontWeight: FontWeight.w900,
            letterSpacing: 3,
            fontFamily: 'Orbitron',
          ),
        ),
      ],
    );
  }

  Widget _buildFooter() {
    return Column(
      children: [
        Container(
          height: 2,
          width: double.infinity,
          color: _kBlack.withOpacity(0.3),
        ),
        const SizedBox(height: 20),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 25,
              height: 2,
              decoration: BoxDecoration(
                color: _kBlack.withOpacity(0.4),
                borderRadius: BorderRadius.circular(1),
              ),
            ),
            const SizedBox(width: 8),
            Icon(Icons.circle, color: _kBlack.withOpacity(0.4), size: 4),
            const SizedBox(width: 8),
            Container(
              width: 25,
              height: 2,
              decoration: BoxDecoration(
                color: _kBlack.withOpacity(0.4),
                borderRadius: BorderRadius.circular(1),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Text(
          "POWER EXECUTION PROFILE",
          style: TextStyle(
            color: primaryWhite.withOpacity(0.5),
            fontSize: 9,
            fontWeight: FontWeight.w700,
            fontFamily: 'Orbitron',
            letterSpacing: 3,
          ),
        ),
      ],
    );
  }
}