import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'widgets/custom_popup.dart';

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  // ─── TEMA NEOBRUTALISM ───────────────────────────────────────
  static const Color bgDark = Color(0xFFFFFDF5);        // Cream
  static const Color primaryPurple = Color(0xFFFFDE59); // Kuning accent
  static const Color accentPurple = Color(0xFFFFDE59);  // Kuning accent

  static const Color cardGlass = Color(0xFFFFFFFF);     // Putih card
  static const Color borderGlass = Color(0xFF000000);   // Hitam border

  // Warna tambahan neobrutalism
  static const Color _kBlack = Color(0xFF000000);
  static const Color _kWhite = Color(0xFFFFFFFF);
  static const Color _kCyan = Color(0xFF4D96FF);
  static const Color _kPink = Color(0xFFFF6B6B);
  static const Color _kGreen = Color(0xFF6BCB77);
  static const Color _kOrange = Color(0xFFFF9F45);
  static const Color _kYellow = Color(0xFFFFDE59);

  Future<void> _launchUrl(BuildContext context, String url) async {
    try {
      final Uri uri = Uri.parse(url);
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
        throw Exception('Could not launch $url');
      }
    } catch (e) {
      if (context.mounted) {
        CustomPopup.display(
          context,
          title: "Gagal",
          message: "Tidak dapat membuka tautan ini.",
          icon: Icons.error_outline,
          iconColor: _kPink,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: _kYellow,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _kBlack, width: 2),
              boxShadow: [
                BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(2, 2)),
              ],
            ),
            child: const Icon(Icons.arrow_back_ios_new, color: _kBlack, size: 16),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          "Customer Service",
          style: TextStyle(
            color: _kBlack,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
      ),
      body: Container(
        color: bgDark,
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Header Icon
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: _kYellow,
                    shape: BoxShape.circle,
                    border: Border.all(color: _kBlack, width: 3),
                    boxShadow: [
                      BoxShadow(
                        color: _kBlack,
                        blurRadius: 0,
                        offset: const Offset(5, 5),
                      )
                    ],
                  ),
                  child: const Icon(
                    Icons.support_agent_rounded,
                    size: 60,
                    color: _kBlack,
                  ),
                ),
                const SizedBox(height: 24),
                Text(
                  "Need Help?",
                  style: TextStyle(
                    color: _kBlack,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  "Contact us through our social media platforms below.",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: _kBlack.withOpacity(0.7),
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 40),

                // Grid Buttons
                Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: _buildContactButton(
                            context: context,
                            label: "Dev 1",
                            icon: FontAwesomeIcons.telegram,
                            color: _kCyan,
                            url: "https://t.me/Panz1235",
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: _buildContactButton(
                            context: context,
                            label: "Dev 2",
                            icon: FontAwesomeIcons.telegram,
                            color: _kCyan,
                            url: "https://t.me/Panz1235",
                          ),
                        ),
                      ],
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildContactButton({
    required BuildContext context,
    required String label,
    required IconData icon,
    required Color color,
    required String url,
  }) {
    return InkWell(
      onTap: () => _launchUrl(context, url),
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
        decoration: BoxDecoration(
          color: cardGlass,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _kBlack, width: 2),
          boxShadow: [
            BoxShadow(
              color: _kBlack,
              blurRadius: 0,
              offset: const Offset(4, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color,
                shape: BoxShape.circle,
                border: Border.all(color: _kBlack, width: 2),
                boxShadow: [
                  BoxShadow(color: _kBlack, blurRadius: 0, offset: const Offset(2, 2)),
                ],
              ),
              child: FaIcon(
                icon,
                color: _kBlack,
                size: 28,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              label,
              style: TextStyle(
                color: _kBlack,
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}