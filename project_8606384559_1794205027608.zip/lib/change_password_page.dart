// profile_settings_page.dart - NEO-BRUTALISM EDITION
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

// ═══════════════════════════════════════════════════════════════════
//  NEO-BRUTALISM THEME
// ═══════════════════════════════════════════════════════════════════
class _C {
  static const bg         = Color(0xFFFFFFFF);
  static const white      = Color(0xFFFFFFFF);
  static const yellow     = Color(0xFFFFE600);
  static const yellowSoft = Color(0xFFFFF9CC);
  static const black      = Color(0xFF000000);
  static const text       = Color(0xFF000000);
  static const textDim    = Color(0xFF333333);
  static const textMute   = Color(0xFF777777);
  static const danger     = Color(0xFFFF1744);
  static const warn       = Color(0xFFFFAB40);
  static const ok         = Color(0xFF00C853);
  static const orange     = Color(0xFFFF9800);
  static const blue       = Color(0xFF2196F3);
}

class _S {
  static List<BoxShadow> get sm => const [
    BoxShadow(color: _C.black, offset: Offset(2, 2), blurRadius: 0),
  ];
  static List<BoxShadow> get md => const [
    BoxShadow(color: _C.black, offset: Offset(3, 3), blurRadius: 0),
  ];
  static List<BoxShadow> get lg => const [
    BoxShadow(color: _C.black, offset: Offset(5, 5), blurRadius: 0),
  ];
}

const String _kBaseUrl = 'http://alfa-store-officials.alfamarket2.my.id:4700/api/user';

// ═══════════════════════════════════════════════════════════════════
//  PAGE
// ═══════════════════════════════════════════════════════════════════
class ProfileSettingsPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const ProfileSettingsPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<ProfileSettingsPage> createState() => _ProfileSettingsPageState();
}

class _ProfileSettingsPageState extends State<ProfileSettingsPage>
    with TickerProviderStateMixin {
  late final AnimationController _entryCtrl;

  // identity
  final _displayCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _bioCtrl = TextEditingController();

  // security
  final _oldPassCtrl = TextEditingController();
  final _newPassCtrl = TextEditingController();
  final _confirmPassCtrl = TextEditingController();

  bool _showOld = false, _showNew = false, _showConfirm = false;
  int _strength = 0; // 0..5

  // avatar
  String? _remoteAvatarUrl;
  File? _pickedAvatar;

  bool _loadingProfile = true;
  bool _savingProfile = false;
  bool _changingPass = false;

  @override
  void initState() {
    super.initState();
    _entryCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..forward();
    _newPassCtrl.addListener(() {
      setState(() => _strength = _scorePassword(_newPassCtrl.text));
    });
    _loadProfile();
  }

  @override
  void dispose() {
    _entryCtrl.dispose();
    _displayCtrl.dispose();
    _emailCtrl.dispose();
    _phoneCtrl.dispose();
    _bioCtrl.dispose();
    _oldPassCtrl.dispose();
    _newPassCtrl.dispose();
    _confirmPassCtrl.dispose();
    super.dispose();
  }

  // ─── API ──────────────────────────────────────────────────
  Future<void> _loadProfile() async {
    setState(() => _loadingProfile = true);
    try {
      final res = await http.get(
        Uri.parse('$_kBaseUrl/profile?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['success'] == true && data['profile'] != null) {
        final p = data['profile'] as Map<String, dynamic>;
        _displayCtrl.text = (p['displayName'] ?? '').toString();
        _emailCtrl.text = (p['email'] ?? '').toString();
        _phoneCtrl.text = (p['phone'] ?? '').toString();
        _bioCtrl.text = (p['bio'] ?? '').toString();
        _remoteAvatarUrl = p['avatarUrl'] as String?;
      }
    } catch (_) {}
    if (mounted) setState(() => _loadingProfile = false);
  }

  Future<void> _pickAvatar() async {
    try {
      final picker = ImagePicker();
      final x = await picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 85,
        maxWidth: 1024,
      );
      if (x != null) setState(() => _pickedAvatar = File(x.path));
    } catch (e) {
      _toast('Could not open gallery', err: true);
    }
  }

  Future<void> _saveProfile() async {
    if (_emailCtrl.text.trim().isNotEmpty &&
        !RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')
            .hasMatch(_emailCtrl.text.trim())) {
      _toast('Email format invalid', err: true);
      return;
    }
    setState(() => _savingProfile = true);
    try {
      final req = http.MultipartRequest(
          'POST', Uri.parse('$_kBaseUrl/profile'))
        ..fields['key'] = widget.sessionKey
        ..fields['username'] = widget.username
        ..fields['displayName'] = _displayCtrl.text.trim()
        ..fields['email'] = _emailCtrl.text.trim()
        ..fields['phone'] = _phoneCtrl.text.trim()
        ..fields['bio'] = _bioCtrl.text.trim();

      if (_pickedAvatar != null) {
        req.files.add(await http.MultipartFile.fromPath(
            'avatar', _pickedAvatar!.path));
      }

      final streamed =
          await req.send().timeout(const Duration(seconds: 30));
      final body = await streamed.stream.bytesToString();
      final data = jsonDecode(body) as Map<String, dynamic>;

      if (data['success'] == true) {
        if (data['profile']?['avatarUrl'] != null) {
          setState(() {
            _remoteAvatarUrl = data['profile']['avatarUrl'] as String;
            _pickedAvatar = null;
          });
        }
        _toast('Profile saved');
      } else {
        _toast((data['message'] ?? 'Save failed').toString(), err: true);
      }
    } catch (e) {
      _toast('Network error', err: true);
    } finally {
      if (mounted) setState(() => _savingProfile = false);
    }
  }

  Future<void> _changePassword() async {
    final oldP = _oldPassCtrl.text.trim();
    final newP = _newPassCtrl.text.trim();
    final cnf = _confirmPassCtrl.text.trim();

    if (oldP.isEmpty || newP.isEmpty || cnf.isEmpty) {
      _toast('All password fields are required', err: true);
      return;
    }
    if (newP != cnf) {
      _toast("New password doesn't match confirmation", err: true);
      return;
    }
    if (newP == oldP) {
      _toast('New password must differ from current', err: true);
      return;
    }
    if (_strength < 3) {
      final ok = await _confirmWeakPassword();
      if (!ok) return;
    }

    setState(() => _changingPass = true);
    try {
      final res = await http.post(
        Uri.parse('$_kBaseUrl/changepass'),
        body: {
          'username': widget.username,
          'oldPass': oldP,
          'newPass': newP,
          'key': widget.sessionKey,
        },
      ).timeout(const Duration(seconds: 20));
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['success'] == true) {
        _oldPassCtrl.clear();
        _newPassCtrl.clear();
        _confirmPassCtrl.clear();
        _toast('Password changed');
      } else {
        _toast((data['message'] ?? 'Change failed').toString(), err: true);
      }
    } catch (e) {
      _toast('Network error', err: true);
    } finally {
      if (mounted) setState(() => _changingPass = false);
    }
  }

  Future<bool> _confirmWeakPassword() async {
    final r = await showModalBottomSheet<bool>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => const _WeakPasswordSheet(),
    );
    return r == true;
  }

  // ─── HELPERS ──────────────────────────────────────────────
  int _scorePassword(String p) {
    if (p.isEmpty) return 0;
    int s = 0;
    if (p.length >= 8) s++;
    if (p.length >= 12) s++;
    if (RegExp(r'[A-Z]').hasMatch(p)) s++;
    if (RegExp(r'[0-9]').hasMatch(p)) s++;
    if (RegExp(r'[^A-Za-z0-9]').hasMatch(p)) s++;
    return s.clamp(0, 5);
  }

  String _strengthLabel() => switch (_strength) {
        0 => '—',
        1 => 'VERY WEAK',
        2 => 'WEAK',
        3 => 'FAIR',
        4 => 'STRONG',
        _ => 'EXCELLENT',
      };

  Color _strengthColor() => switch (_strength) {
        0 || 1 => _C.danger,
        2 => _C.orange,
        3 => _C.warn,
        4 => _C.ok,
        _ => _C.black,
      };

  void _toast(String msg, {bool err = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: _C.black,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: _C.black, width: 2),
        ),
        content: Row(
          children: [
            Icon(
              err ? Icons.error_outline_rounded : Icons.check_circle_outline_rounded,
              color: err ? _C.danger : _C.ok,
              size: 18,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                msg,
                style: const TextStyle(
                  color: _C.yellow,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── BUILD ────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: _appBar(),
      body: Stack(
        children: [
          // Dot pattern
          Positioned.fill(
            child: CustomPaint(painter: _DotPatternPainter()),
          ),
          SafeArea(
            child: _loadingProfile
                ? _loadingView()
                : ListView(
                    padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
                    children: [
                      _slide(0, _avatarHero()),
                      const SizedBox(height: 22),
                      _slide(1, _identityCard()),
                      const SizedBox(height: 16),
                      _slide(2, _saveProfileBtn()),
                      const SizedBox(height: 28),
                      _slide(3, _securityCard()),
                      const SizedBox(height: 16),
                      _slide(4, _changePassBtn()),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  Widget _loadingView() {
    return Center(
      child: Container(
        width: 70,
        height: 70,
        decoration: BoxDecoration(
          color: _C.yellow,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _C.black, width: 3),
          boxShadow: _S.md,
        ),
        child: const Center(
          child: SizedBox(
            width: 28,
            height: 28,
            child: CircularProgressIndicator(
              strokeWidth: 3,
              color: _C.black,
            ),
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget _appBar() {
    return AppBar(
      backgroundColor: _C.bg,
      elevation: 0,
      toolbarHeight: 62,
      leadingWidth: 50,
      leading: Padding(
        padding: const EdgeInsets.only(left: 12),
        child: Center(
          child: _PressBtn(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: _C.yellow,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _C.black, width: 2.5),
                boxShadow: _S.sm,
              ),
              child: const Icon(Icons.arrow_back_ios_new_rounded,
                  color: _C.black, size: 16),
            ),
          ),
        ),
      ),
      title: const Text(
        'PROFILE • SETTINGS',
        style: TextStyle(
          color: _C.black,
          fontSize: 13,
          letterSpacing: 2.5,
          fontWeight: FontWeight.w900,
        ),
      ),
      centerTitle: true,
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(3),
        child: Container(height: 3, color: _C.black),
      ),
    );
  }

  Widget _slide(int idx, Widget child) {
    return AnimatedBuilder(
      animation: _entryCtrl,
      builder: (_, __) {
        final stagger = (idx * 0.10).clamp(0.0, 0.6);
        final raw =
            ((_entryCtrl.value - stagger) / (1 - stagger)).clamp(0.0, 1.0);
        final t = Curves.easeOutCubic.transform(raw);
        return Opacity(
          opacity: t,
          child: Transform.translate(
              offset: Offset(0, (1 - t) * 22), child: child),
        );
      },
    );
  }

  // ─── AVATAR HERO ──────────────────────────────────────────
  Widget _avatarHero() {
    final hasLocal = _pickedAvatar != null;
    final hasRemote =
        _remoteAvatarUrl != null && _remoteAvatarUrl!.isNotEmpty;

    return Column(
      children: [
        _PressBtn(
          onTap: _pickAvatar,
          child: Container(
            padding: const EdgeInsets.all(5),
            decoration: BoxDecoration(
              color: _C.yellow,
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: _C.black, width: 4),
              boxShadow: _S.lg,
            ),
            child: Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(
                color: _C.white,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: _C.black, width: 2.5),
              ),
              clipBehavior: Clip.antiAlias,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  if (hasLocal)
                    Image.file(_pickedAvatar!, fit: BoxFit.cover)
                  else if (hasRemote)
                    Image.network(
                      _remoteAvatarUrl!,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => _avatarPlaceholder(),
                    )
                  else
                    _avatarPlaceholder(),
                  Positioned(
                    right: 0,
                    bottom: 0,
                    child: Container(
                      width: 34,
                      height: 34,
                      decoration: BoxDecoration(
                        color: _C.black,
                        shape: BoxShape.circle,
                        border: Border.all(color: _C.yellow, width: 2.5),
                      ),
                      child: const Icon(Icons.camera_alt_rounded,
                          color: _C.yellow, size: 16),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
        Text(
          _displayCtrl.text.trim().isEmpty
              ? widget.username
              : _displayCtrl.text.trim(),
          style: const TextStyle(
            color: _C.black,
            fontSize: 18,
            fontWeight: FontWeight.w900,
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 4),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
          decoration: BoxDecoration(
            color: _C.white,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: _C.black, width: 2),
          ),
          child: Text(
            '@${widget.username}',
            style: const TextStyle(
              color: _C.black,
              fontSize: 11,
              fontFamily: 'monospace',
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
        if (_pickedAvatar != null) ...[
          const SizedBox(height: 10),
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: _C.warn,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _C.black, width: 2),
              boxShadow: _S.sm,
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.fiber_manual_record,
                    color: _C.white, size: 8),
                SizedBox(width: 6),
                Text(
                  'Unsaved photo — tap Save Profile',
                  style: TextStyle(
                    color: _C.white,
                    fontSize: 10.5,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }

  Widget _avatarPlaceholder() {
    return Container(
      color: _C.yellowSoft,
      child: const Icon(Icons.person_rounded, color: _C.black, size: 60),
    );
  }

  // ─── IDENTITY CARD ────────────────────────────────────────
  Widget _identityCard() {
    return _brutalCard(
      icon: Icons.badge_outlined,
      title: 'IDENTITY',
      child: Column(
        children: [
          _field(
            label: 'Display Name',
            hint: 'Your name as shown to others',
            icon: Icons.person_outline,
            controller: _displayCtrl,
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 14),
          _field(
            label: 'Email',
            hint: 'name@domain.com',
            icon: Icons.alternate_email,
            controller: _emailCtrl,
            keyboardType: TextInputType.emailAddress,
          ),
          const SizedBox(height: 14),
          _field(
            label: 'Phone',
            hint: 'Optional',
            icon: Icons.phone_outlined,
            controller: _phoneCtrl,
            keyboardType: TextInputType.phone,
          ),
          const SizedBox(height: 14),
          _field(
            label: 'Bio',
            hint: 'A short line about you',
            icon: Icons.short_text,
            controller: _bioCtrl,
            maxLines: 3,
          ),
        ],
      ),
    );
  }

  Widget _saveProfileBtn() {
    return _BigButton(
      label: _savingProfile ? 'SAVING…' : 'SAVE PROFILE',
      icon: _savingProfile ? null : Icons.save_outlined,
      busy: _savingProfile,
      onTap: _savingProfile ? null : _saveProfile,
    );
  }

  // ─── SECURITY CARD ────────────────────────────────────────
  Widget _securityCard() {
    return _brutalCard(
      icon: Icons.lock_outline,
      title: 'SECURITY',
      child: Column(
        children: [
          _field(
            label: 'Current Password',
            hint: 'Enter your current password',
            icon: Icons.lock_clock_outlined,
            controller: _oldPassCtrl,
            obscure: !_showOld,
            suffix: _eyeBtn(
              _showOld,
              () => setState(() => _showOld = !_showOld),
            ),
          ),
          const SizedBox(height: 14),
          _field(
            label: 'New Password',
            hint: 'At least 8 characters',
            icon: Icons.password_outlined,
            controller: _newPassCtrl,
            obscure: !_showNew,
            suffix: _eyeBtn(
              _showNew,
              () => setState(() => _showNew = !_showNew),
            ),
          ),
          if (_newPassCtrl.text.isNotEmpty) ...[
            const SizedBox(height: 12),
            _strengthMeter(),
          ],
          const SizedBox(height: 14),
          _field(
            label: 'Confirm Password',
            hint: 'Re-enter new password',
            icon: Icons.check_circle_outline,
            controller: _confirmPassCtrl,
            obscure: !_showConfirm,
            suffix: _eyeBtn(
              _showConfirm,
              () => setState(() => _showConfirm = !_showConfirm),
            ),
          ),
          if (_newPassCtrl.text.isNotEmpty &&
              _confirmPassCtrl.text.isNotEmpty &&
              _newPassCtrl.text != _confirmPassCtrl.text) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: _C.danger.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _C.danger, width: 2),
              ),
              child: Row(
                children: const [
                  Icon(Icons.error_outline,
                      color: _C.danger, size: 14),
                  SizedBox(width: 6),
                  Text(
                    "Passwords don't match",
                    style: TextStyle(
                      color: _C.danger,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _eyeBtn(bool visible, VoidCallback onTap) {
    return IconButton(
      icon: Icon(
        visible ? Icons.visibility_off_outlined : Icons.visibility_outlined,
        color: _C.black,
        size: 20,
      ),
      onPressed: () {
        HapticFeedback.lightImpact();
        onTap();
      },
    );
  }

  Widget _strengthMeter() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: List.generate(5, (i) {
            final filled = i < _strength;
            return Expanded(
              child: Container(
                margin: EdgeInsets.only(right: i == 4 ? 0 : 4),
                height: 6,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(3),
                  color:
                      filled ? _strengthColor() : _C.white,
                  border: Border.all(color: _C.black, width: 1.5),
                ),
              ),
            );
          }),
        ),
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'STRENGTH',
              style: TextStyle(
                color: _C.textMute,
                fontSize: 10,
                letterSpacing: 1.5,
                fontWeight: FontWeight.w900,
              ),
            ),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: _strengthColor(),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: _C.black, width: 2),
              ),
              child: Text(
                _strengthLabel(),
                style: TextStyle(
                  color: _strengthColor() == _C.black
                      ? _C.yellow
                      : _C.white,
                  fontSize: 9,
                  letterSpacing: 1.2,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _changePassBtn() {
    return _BigButton(
      label: _changingPass ? 'UPDATING…' : 'CHANGE PASSWORD',
      icon: _changingPass ? null : Icons.shield_outlined,
      busy: _changingPass,
      onTap: _changingPass ? null : _changePassword,
      bgColor: _C.black,
      textColor: _C.yellow,
      iconColor: _C.yellow,
    );
  }

  // ─── BRUTAL CARD ──────────────────────────────────────────
  Widget _brutalCard({
    required IconData icon,
    required String title,
    required Widget child,
  }) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: _C.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _C.black, width: 3),
        boxShadow: _S.md,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _C.yellow,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _C.black, width: 2.5),
                  boxShadow: _S.sm,
                ),
                child: Icon(icon, color: _C.black, size: 16),
              ),
              const SizedBox(width: 10),
              Text(
                title,
                style: const TextStyle(
                  color: _C.black,
                  fontSize: 12,
                  letterSpacing: 2,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          child,
        ],
      ),
    );
  }

  Widget _field({
    required String label,
    required String hint,
    required IconData icon,
    required TextEditingController controller,
    bool obscure = false,
    int maxLines = 1,
    TextInputType? keyboardType,
    Widget? suffix,
    void Function(String)? onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 6),
          child: Text(
            label.toUpperCase(),
            style: const TextStyle(
              color: _C.black,
              fontSize: 10,
              letterSpacing: 1.5,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
        TextField(
          controller: controller,
          obscureText: obscure,
          maxLines: obscure ? 1 : maxLines,
          keyboardType: keyboardType,
          onChanged: onChanged,
          style: const TextStyle(
            color: _C.black,
            fontSize: 14,
            fontWeight: FontWeight.w700,
          ),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: const TextStyle(
              color: _C.textMute,
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
            prefixIcon: Icon(icon, color: _C.black, size: 18),
            suffixIcon: suffix,
            filled: true,
            fillColor: _C.yellowSoft,
            contentPadding: const EdgeInsets.symmetric(
                vertical: 14, horizontal: 12),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: _C.black, width: 2.5),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: _C.black, width: 2.5),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: _C.black, width: 3),
            ),
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  PRESS BUTTON WRAPPER
// ═══════════════════════════════════════════════════════════════════
class _PressBtn extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;
  const _PressBtn({required this.child, required this.onTap});

  @override
  State<_PressBtn> createState() => _PressBtnState();
}

class _PressBtnState extends State<_PressBtn> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: () {
        HapticFeedback.lightImpact();
        widget.onTap();
      },
      child: AnimatedScale(
        duration: const Duration(milliseconds: 90),
        scale: _pressed ? 0.96 : 1.0,
        child: widget.child,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  BIG BUTTON
// ═══════════════════════════════════════════════════════════════════
class _BigButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final bool busy;
  final VoidCallback? onTap;
  final Color bgColor;
  final Color textColor;
  final Color iconColor;

  const _BigButton({
    required this.label,
    required this.icon,
    required this.busy,
    required this.onTap,
    this.bgColor = _C.yellow,
    this.textColor = _C.black,
    this.iconColor = _C.black,
  });

  @override
  Widget build(BuildContext context) {
    final enabled = onTap != null;
    return _PressBtn(
      onTap: onTap ?? () {},
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        height: 54,
        decoration: BoxDecoration(
          color: enabled ? bgColor : _C.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _C.black, width: 3),
          boxShadow: enabled ? _S.md : null,
        ),
        child: Center(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (busy)
                SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                    strokeWidth: 3,
                    color: textColor,
                  ),
                )
              else if (icon != null)
                Icon(icon, color: iconColor, size: 18),
              const SizedBox(width: 10),
              Text(
                label,
                style: TextStyle(
                  color: enabled ? textColor : _C.textMute,
                  fontSize: 13,
                  letterSpacing: 1.8,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  WEAK PASSWORD SHEET
// ═══════════════════════════════════════════════════════════════════
class _WeakPasswordSheet extends StatelessWidget {
  const _WeakPasswordSheet();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: const BoxDecoration(
        color: _C.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        border: Border(
          top: BorderSide(color: _C.black, width: 3),
          left: BorderSide(color: _C.black, width: 3),
          right: BorderSide(color: _C.black, width: 3),
        ),
      ),
      child: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 5,
              decoration: BoxDecoration(
                color: _C.black,
                borderRadius: BorderRadius.circular(3),
              ),
            ),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: _C.warn,
                shape: BoxShape.circle,
                border: Border.all(color: _C.black, width: 3),
                boxShadow: _S.md,
              ),
              child: const Icon(Icons.warning_amber_rounded,
                  color: _C.white, size: 32),
            ),
            const SizedBox(height: 14),
            const Text(
              'WEAK PASSWORD',
              style: TextStyle(
                color: _C.black,
                fontSize: 15,
                letterSpacing: 2,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 8),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 8),
              child: Text(
                'Your new password is easy to guess. Add length, mixed case, numbers, and symbols for better security.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: _C.textDim,
                  fontSize: 12.5,
                  height: 1.5,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(height: 22),
            Row(
              children: [
                Expanded(
                  child: _PressBtn(
                    onTap: () => Navigator.pop(context, false),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        color: _C.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: _C.black, width: 2.5),
                      ),
                      child: const Center(
                        child: Text(
                          'GO BACK',
                          style: TextStyle(
                            color: _C.black,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.5,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _PressBtn(
                    onTap: () => Navigator.pop(context, true),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        color: _C.yellow,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: _C.black, width: 2.5),
                        boxShadow: _S.sm,
                      ),
                      child: const Center(
                        child: Text(
                          'USE ANYWAY',
                          style: TextStyle(
                            color: _C.black,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.5,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  DOT PATTERN BACKGROUND
// ═══════════════════════════════════════════════════════════════════
class _DotPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = _C.yellow.withOpacity(0.35)
      ..style = PaintingStyle.fill;

    const spacing = 24.0;
    const dotRadius = 1.5;

    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), dotRadius, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}