// chat_page.dart - NEO-BRUTALISM EDITION (INPUT BAR FIXED)
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

// ==================== KONSTANTA SERVER ====================
const String BASE_URL = 'http://alfa-store-officials.alfamarket2.my.id:4700';
const String WS_URL = 'ws://alfa-store-officials.alfamarket2.my.id:4700';

// ==================== TEMA NEO-BRUTALISM ====================
class ChatTheme {
  static const bg           = Color(0xFFFFFFFF);
  static const surface      = Color(0xFFFFFFFF);
  static const surface2     = Color(0xFFFFF9CC);
  static const surface3     = Color(0xFFFFE600);
  static const yellow       = Color(0xFFFFE600);
  static const yellowDark   = Color(0xFFF5D400);
  static const black        = Color(0xFF000000);
  static const white        = Color(0xFFFFFFFF);
  static const textPrimary  = Color(0xFF000000);
  static const textSecondary = Color(0xFF333333);
  static const textMuted    = Color(0xFF777777);
  static const success      = Color(0xFF00C853);
  static const error        = Color(0xFFFF1744);
}

class _HardShadow {
  static List<BoxShadow> get sm => const [
    BoxShadow(color: ChatTheme.black, offset: Offset(2, 2), blurRadius: 0),
  ];
  static List<BoxShadow> get md => const [
    BoxShadow(color: ChatTheme.black, offset: Offset(3, 3), blurRadius: 0),
  ];
  static List<BoxShadow> get lg => const [
    BoxShadow(color: ChatTheme.black, offset: Offset(5, 5), blurRadius: 0),
  ];
}

// ==================== HALAMAN CHAT UTAMA ====================
class ChatPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const ChatPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  WebSocketChannel? _channel;

  // Global chat
  List<dynamic> _globalMessages = [];
  bool _globalLoading = true;
  final TextEditingController _globalInputCtrl = TextEditingController();
  final ScrollController _globalScrollCtrl = ScrollController();
  Map<String, dynamic>? _globalReplyTo;

  // Private chat
  List<dynamic> _privateChats = [];
  List<dynamic> _privateMessages = [];
  String? _selectedUser;
  bool _privateLoading = true;
  final TextEditingController _privateInputCtrl = TextEditingController();
  final ScrollController _privateScrollCtrl = ScrollController();
  Map<String, dynamic>? _privateReplyTo;

  // Profile
  Map<String, dynamic> _myProfile = {};

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _initialize();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _channel?.sink.close();
    _globalInputCtrl.dispose();
    _globalScrollCtrl.dispose();
    _privateInputCtrl.dispose();
    _privateScrollCtrl.dispose();
    super.dispose();
  }

  // ==================== INISIALISASI ====================
  void _initialize() {
    _loadProfile();
    _connectWebSocket();
    _loadGlobalMessages();
    _loadPrivateChats();
  }

  Future<void> _loadProfile() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionKey = prefs.getString('session_key') ?? widget.sessionKey;
      final res = await http
          .get(Uri.parse('$BASE_URL/chat/profile?key=$sessionKey'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() => _myProfile = data['profile']);
        }
      }
    } catch (e) {}
  }

  void _connectWebSocket() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionKey = prefs.getString('session_key') ?? widget.sessionKey;
      _channel = WebSocketChannel.connect(Uri.parse(WS_URL));
      _channel!.stream.listen(_handleWebSocketMessage, onError: (e) {});
      _channel!.sink.add(jsonEncode({'type': 'auth', 'key': sessionKey}));
    } catch (e) {}
  }

  void _handleWebSocketMessage(dynamic data) {
    try {
      final msg = jsonDecode(data);
      if (msg['type'] == 'global_message') {
        _addGlobalMessage(msg['message']);
      } else if (msg['type'] == 'private_message') {
        _addPrivateMessage(msg['message']);
      } else if (msg['type'] == 'refresh_chat_list') {
        _loadPrivateChats();
      }
    } catch (e) {}
  }

  // ==================== GLOBAL CHAT ====================
  Future<void> _loadGlobalMessages() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionKey = prefs.getString('session_key') ?? widget.sessionKey;
      final res = await http.get(Uri.parse(
          '$BASE_URL/chat/global/messages?key=$sessionKey&limit=100'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            _globalMessages = data['messages'];
            _globalLoading = false;
          });
          WidgetsBinding.instance.addPostFrameCallback((_) {
            _scrollToBottom(_globalScrollCtrl);
          });
        }
      }
    } catch (e) {
      if (mounted) setState(() => _globalLoading = false);
    }
  }

  void _addGlobalMessage(dynamic msg) {
    setState(() => _globalMessages.add(msg));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToBottom(_globalScrollCtrl);
    });
  }

  void _scrollToBottom(ScrollController controller) {
    if (controller.hasClients) {
      controller.animateTo(
        controller.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  Future<void> _sendGlobalMessage() async {
    String text = _globalInputCtrl.text.trim();
    if (text.isEmpty && _globalReplyTo == null) return;

    String finalText = text;
    if (_globalReplyTo != null) {
      finalText = '@${_globalReplyTo!['sender']} ${text}';
    }

    setState(() => _globalInputCtrl.text = '');

    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionKey = prefs.getString('session_key') ?? widget.sessionKey;
      final body = jsonEncode({
        'message': finalText,
        'type': 'text',
        'replyTo': _globalReplyTo?['id']
      });

      final res = await http.post(
        Uri.parse('$BASE_URL/chat/global/send?key=$sessionKey'),
        headers: {'Content-Type': 'application/json'},
        body: body,
      );

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() => _globalReplyTo = null);
          _loadGlobalMessages();
        }
      }
    } catch (e) {}
  }

  // ==================== PRIVATE CHAT ====================
  Future<void> _loadPrivateChats() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionKey = prefs.getString('session_key') ?? widget.sessionKey;
      final res = await http.get(
          Uri.parse('$BASE_URL/chat/private/users?key=$sessionKey'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            _privateChats = data['users'];
            _privateLoading = false;
          });
        }
      }
    } catch (e) {
      if (mounted) setState(() => _privateLoading = false);
    }
  }

  Future<void> _loadPrivateMessages(String withUser) async {
    setState(() => _privateLoading = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionKey = prefs.getString('session_key') ?? widget.sessionKey;
      final res = await http.get(Uri.parse(
          '$BASE_URL/chat/private/messages/$withUser?key=$sessionKey&limit=100'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            _privateMessages = data['messages'];
            _privateLoading = false;
          });
          WidgetsBinding.instance.addPostFrameCallback((_) {
            _scrollToBottom(_privateScrollCtrl);
          });
          await http.post(Uri.parse(
              '$BASE_URL/chat/private/mark-read/$withUser?key=$sessionKey'));
        }
      }
    } catch (e) {
      setState(() => _privateLoading = false);
    }
  }

  void _addPrivateMessage(dynamic msg) {
    final isCurrentChat =
        _selectedUser == msg['sender'] || _selectedUser == msg['receiver'];
    if (isCurrentChat) {
      setState(() => _privateMessages.add(msg));
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _scrollToBottom(_privateScrollCtrl);
      });
    }
    _loadPrivateChats();
  }

  Future<void> _sendPrivateMessage() async {
    String text = _privateInputCtrl.text.trim();
    if (text.isEmpty || _selectedUser == null) return;

    String finalText = text;
    if (_privateReplyTo != null) {
      finalText = '@${_privateReplyTo!['sender']} ${text}';
    }

    setState(() => _privateInputCtrl.text = '');

    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionKey = prefs.getString('session_key') ?? widget.sessionKey;
      final body = jsonEncode({
        'message': finalText,
        'type': 'text',
        'replyTo': _privateReplyTo?['id']
      });

      final res = await http.post(
        Uri.parse('$BASE_URL/chat/private/send/${_selectedUser}?key=$sessionKey'),
        headers: {'Content-Type': 'application/json'},
        body: body,
      );

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() => _privateReplyTo = null);
          _loadPrivateMessages(_selectedUser!);
        } else {
          _showToast(data['error'] ?? 'Gagal mengirim pesan', isError: true);
        }
      }
    } catch (e) {
      _showToast('Error: $e', isError: true);
    }
  }

  void _showToast(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: const TextStyle(
            color: ChatTheme.yellow,
            fontWeight: FontWeight.w800,
          ),
        ),
        backgroundColor: isError ? ChatTheme.error : ChatTheme.black,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: isError ? ChatTheme.error : ChatTheme.black, width: 2),
        ),
      ),
    );
  }

  Future<void> _searchAndStartChat() async {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _SearchUserSheet(
        sessionKey: widget.sessionKey,
        currentUsername: widget.username,
        onSelectUser: (user) {
          Navigator.pop(ctx);
          setState(() {
            _selectedUser = user['username'];
            _privateReplyTo = null;
          });
          _loadPrivateMessages(user['username']);
          _tabController.animateTo(1);
        },
      ),
    );
  }

  String _formatTime(String? timestamp) {
    if (timestamp == null) return '';
    try {
      final time = DateTime.parse(timestamp);
      final now = DateTime.now();
      final diff = now.difference(time);
      if (diff.inSeconds < 60) return 'Just now';
      if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
      if (diff.inHours < 24) return '${diff.inHours}h ago';
      return '${diff.inDays}d ago';
    } catch (_) {
      return '';
    }
  }

  // ==================== BUILD ====================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ChatTheme.bg,
      appBar: _buildAppBar(),
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            _buildTabBar(),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildGlobalChat(),
                  _buildPrivateChat(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── TAB BAR ────────────────────────────────────────────────
  Widget _buildTabBar() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      height: 48,
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: ChatTheme.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: ChatTheme.black, width: 2.5),
        boxShadow: _HardShadow.sm,
      ),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          color: ChatTheme.yellow,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: ChatTheme.black, width: 2),
        ),
        labelColor: ChatTheme.black,
        unselectedLabelColor: ChatTheme.textMuted,
        dividerColor: Colors.transparent,
        labelStyle:
            const TextStyle(fontSize: 12, fontWeight: FontWeight.w900, letterSpacing: 1),
        unselectedLabelStyle:
            const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 1),
        indicatorSize: TabBarIndicatorSize.tab,
        indicatorPadding: EdgeInsets.zero,
        tabs: const [
          Tab(icon: Icon(Icons.public_rounded, size: 16), text: 'GLOBAL'),
          Tab(icon: Icon(Icons.lock_rounded, size: 16), text: 'PRIVATE'),
        ],
      ),
    );
  }

  // ─── APP BAR ────────────────────────────────────────────────
  AppBar _buildAppBar() {
    return AppBar(
      backgroundColor: ChatTheme.bg,
      elevation: 0,
      toolbarHeight: 62,
      leadingWidth: 50,
      leading: Padding(
        padding: const EdgeInsets.only(left: 12),
        child: Center(
          child: _IconBtn(
            icon: Icons.arrow_back_rounded,
            onTap: () => Navigator.pop(context),
          ),
        ),
      ),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'CHAT',
            style: TextStyle(
              color: ChatTheme.black,
              fontSize: 11,
              letterSpacing: 2,
              fontWeight: FontWeight.w900,
            ),
          ),
          Text(
            '@${widget.username}',
            style: const TextStyle(
              color: ChatTheme.textMuted,
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: 12),
          child: _IconBtn(
            icon: Icons.refresh_rounded,
            onTap: () {
              HapticFeedback.lightImpact();
              _loadGlobalMessages();
              _loadPrivateChats();
              if (_selectedUser != null) _loadPrivateMessages(_selectedUser!);
            },
          ),
        ),
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(3),
        child: Container(height: 3, color: ChatTheme.black),
      ),
    );
  }

  // ==================== GLOBAL CHAT TAB ====================
  Widget _buildGlobalChat() {
    return Column(
      children: [
        if (_globalReplyTo != null) _buildReplyPreviewBar(isGlobal: true),
        Expanded(
          child: _globalLoading
              ? const Center(
                  child: CircularProgressIndicator(
                      color: ChatTheme.black, strokeWidth: 3))
              : _globalMessages.isEmpty
                  ? _buildEmptyState(
                      'Belum ada pesan',
                      'Jadilah yang pertama mengirim pesan!',
                      Icons.chat_bubble_outline_rounded)
                  : ListView.builder(
                      controller: _globalScrollCtrl,
                      padding: const EdgeInsets.fromLTRB(0, 8, 0, 20),
                      itemCount: _globalMessages.length,
                      itemBuilder: (ctx, i) =>
                          _buildGlobalMessageBubble(_globalMessages[i]),
                    ),
        ),
        _buildInputBar(
          controller: _globalInputCtrl,
          onSend: _sendGlobalMessage,
          hint: 'Type a message...',
          isGlobal: true,
        ),
      ],
    );
  }

  Widget _buildGlobalMessageBubble(dynamic msg) {
    final isMe = msg['sender'] == widget.username;
    final profile = msg['senderProfile'] ?? {};
    final name = profile['name'] ?? msg['sender'];
    final replyTo = msg['replyTo'];

    return GestureDetector(
      onLongPress: () {
        HapticFeedback.mediumImpact();
        setState(() {
          _globalReplyTo = {
            'id': msg['id'],
            'sender': msg['sender'],
            'message': msg['message'],
          };
        });
      },
      child: Container(
        margin: EdgeInsets.only(
          left: isMe ? 60 : 12,
          right: isMe ? 12 : 60,
          top: 6,
          bottom: 6,
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (!isMe) ...[
              GestureDetector(
                onTap: () {
                  if (msg['sender'] != widget.username) {
                    setState(() {
                      _selectedUser = msg['sender'];
                      _privateReplyTo = null;
                    });
                    _loadPrivateMessages(msg['sender']);
                    _tabController.animateTo(1);
                  }
                },
                child: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: ChatTheme.yellow,
                    shape: BoxShape.circle,
                    border: Border.all(color: ChatTheme.black, width: 2.5),
                    boxShadow: _HardShadow.sm,
                  ),
                  child: Center(
                    child: Text(
                      name[0].toUpperCase(),
                      style: const TextStyle(
                        color: ChatTheme.black,
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
            ],
            Expanded(
              child: Column(
                crossAxisAlignment:
                    isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                children: [
                  if (!isMe)
                    Padding(
                      padding: const EdgeInsets.only(left: 4, bottom: 4),
                      child: Text(
                        name,
                        style: const TextStyle(
                          color: ChatTheme.textSecondary,
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  if (replyTo != null) _buildReplyBubble(replyTo, isMe),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: isMe ? ChatTheme.yellow : ChatTheme.white,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                          color: ChatTheme.black, width: 2.5),
                      boxShadow: _HardShadow.sm,
                    ),
                    child: Text(
                      msg['message'] ?? '',
                      style: const TextStyle(
                        color: ChatTheme.black,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 8, right: 8, top: 4),
                    child: Text(
                      _formatTime(msg['timestamp']),
                      style: const TextStyle(
                        color: ChatTheme.textMuted,
                        fontSize: 9,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== PRIVATE CHAT TAB ====================
  Widget _buildPrivateChat() {
    return _selectedUser == null
        ? _buildChatList()
        : Column(
            children: [
              _buildChatHeader(),
              if (_privateReplyTo != null)
                _buildReplyPreviewBar(isGlobal: false),
              Expanded(
                child: _privateLoading
                    ? const Center(
                        child: CircularProgressIndicator(
                            color: ChatTheme.black, strokeWidth: 3))
                    : _privateMessages.isEmpty
                        ? _buildEmptyState(
                            'Belum ada pesan',
                            'Kirim pesan pertama untuk memulai!',
                            Icons.forum_outlined)
                        : ListView.builder(
                            controller: _privateScrollCtrl,
                            padding: const EdgeInsets.fromLTRB(0, 8, 0, 20),
                            itemCount: _privateMessages.length,
                            itemBuilder: (ctx, i) =>
                                _buildPrivateMessageBubble(
                                    _privateMessages[i]),
                          ),
              ),
              _buildInputBar(
                controller: _privateInputCtrl,
                onSend: _sendPrivateMessage,
                hint: 'Encrypted message...',
                isGlobal: false,
              ),
            ],
          );
  }

  Widget _buildChatList() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: GestureDetector(
            onTap: _searchAndStartChat,
            child: Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 12),
              decoration: BoxDecoration(
                color: ChatTheme.yellow,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: ChatTheme.black, width: 2.5),
                boxShadow: _HardShadow.sm,
              ),
              child: Row(
                children: const [
                  Icon(Icons.search_rounded,
                      color: ChatTheme.black, size: 20),
                  SizedBox(width: 12),
                  Text(
                    'Cari user baru...',
                    style: TextStyle(
                      color: ChatTheme.black,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        Expanded(
          child: _privateChats.isEmpty
              ? _buildEmptyState(
                  'Belum ada chat',
                  'Cari user untuk memulai percakapan private!',
                  Icons.person_search_rounded)
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(12, 0, 12, 20),
                  itemCount: _privateChats.length,
                  itemBuilder: (ctx, i) =>
                      _buildChatListItem(_privateChats[i]),
                ),
        ),
      ],
    );
  }

  Widget _buildChatListItem(dynamic chat) {
    final profile = chat['profile'] ?? {};
    final lastMsg = chat['lastMessage'];
    final isUnread = lastMsg != null &&
        lastMsg['sender'] != widget.username &&
        lastMsg['read'] != true;

    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        setState(() {
          _selectedUser = chat['username'];
          _privateReplyTo = null;
        });
        _loadPrivateMessages(chat['username']);
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isUnread ? ChatTheme.yellow : ChatTheme.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: ChatTheme.black, width: 2.5),
          boxShadow: _HardShadow.sm,
        ),
        child: Row(
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: ChatTheme.yellow,
                shape: BoxShape.circle,
                border: Border.all(color: ChatTheme.black, width: 2.5),
              ),
              child: Center(
                child: Text(
                  chat['username'][0].toUpperCase(),
                  style: const TextStyle(
                    color: ChatTheme.black,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          profile['name'] ?? chat['username'],
                          style: const TextStyle(
                            color: ChatTheme.black,
                            fontWeight: FontWeight.w900,
                            fontSize: 14,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (isUnread)
                        Container(
                          margin: const EdgeInsets.only(left: 8),
                          width: 9,
                          height: 9,
                          decoration: BoxDecoration(
                            color: ChatTheme.error,
                            shape: BoxShape.circle,
                            border: Border.all(
                                color: ChatTheme.black, width: 1.5),
                          ),
                        ),
                    ],
                  ),
                  if (lastMsg != null)
                    Text(
                      '${lastMsg['sender'] == widget.username ? "You: " : ""}${lastMsg['message'] ?? ''}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: ChatTheme.textSecondary,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                ],
              ),
            ),
            if (lastMsg != null)
              Text(
                _formatTime(lastMsg['timestamp']),
                style: const TextStyle(
                  color: ChatTheme.textMuted,
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildChatHeader() {
    final profile = _privateChats.firstWhere(
      (c) => c['username'] == _selectedUser,
      orElse: () => ({'profile': {}}),
    )['profile'] ?? {};

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: const BoxDecoration(
        color: ChatTheme.bg,
        border: Border(
          bottom: BorderSide(color: ChatTheme.black, width: 2),
        ),
      ),
      child: Row(
        children: [
          _IconBtn(
            icon: Icons.arrow_back_rounded,
            onTap: () => setState(() {
              _selectedUser = null;
              _privateReplyTo = null;
            }),
          ),
          const SizedBox(width: 10),
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: ChatTheme.yellow,
              shape: BoxShape.circle,
              border: Border.all(color: ChatTheme.black, width: 2.5),
            ),
            child: Center(
              child: Text(
                _selectedUser![0].toUpperCase(),
                style: const TextStyle(
                  color: ChatTheme.black,
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  profile['name'] ?? _selectedUser!,
                  style: const TextStyle(
                    color: ChatTheme.black,
                    fontWeight: FontWeight.w900,
                    fontSize: 14,
                  ),
                ),
                if (profile['bio'] != null && profile['bio'].isNotEmpty)
                  Text(
                    profile['bio'],
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: ChatTheme.textMuted,
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
              ],
            ),
          ),
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: ChatTheme.yellow,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: ChatTheme.black, width: 2),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: const [
                Icon(Icons.lock_rounded,
                    color: ChatTheme.black, size: 11),
                SizedBox(width: 4),
                Text(
                  'PRIVATE',
                  style: TextStyle(
                    color: ChatTheme.black,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPrivateMessageBubble(dynamic msg) {
    final isMe = msg['fromMe'] == true;
    final replyTo = msg['replyTo'];

    return GestureDetector(
      onLongPress: () {
        HapticFeedback.mediumImpact();
        setState(() {
          _privateReplyTo = {
            'id': msg['id'],
            'sender': msg['sender'],
            'message': msg['message'],
          };
        });
      },
      child: Container(
        margin: EdgeInsets.only(
          left: isMe ? 60 : 12,
          right: isMe ? 12 : 60,
          top: 6,
          bottom: 6,
        ),
        child: Column(
          crossAxisAlignment:
              isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            if (replyTo != null) _buildReplyBubble(replyTo, isMe),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: isMe ? ChatTheme.yellow : ChatTheme.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: ChatTheme.black, width: 2.5),
                boxShadow: _HardShadow.sm,
              ),
              child: Text(
                msg['message'] ?? '',
                style: const TextStyle(
                  color: ChatTheme.black,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 8, right: 8, top: 4),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 5, vertical: 2),
                    decoration: BoxDecoration(
                      color: ChatTheme.black,
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: const [
                        Icon(Icons.lock_outline_rounded,
                            color: ChatTheme.yellow, size: 8),
                        SizedBox(width: 2),
                        Text(
                          'E2EE',
                          style: TextStyle(
                            color: ChatTheme.yellow,
                            fontSize: 7,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 5),
                  Text(
                    _formatTime(msg['timestamp']),
                    style: const TextStyle(
                      color: ChatTheme.textMuted,
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  if (isMe && msg['read'] == true)
                    const Padding(
                      padding: EdgeInsets.only(left: 4),
                      child: Icon(Icons.done_all_rounded,
                          color: ChatTheme.black, size: 11),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── Reply Bubble ───────────────────────────────────────────
  Widget _buildReplyBubble(dynamic replyTo, bool isMe) {
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: ChatTheme.surface2,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: ChatTheme.black, width: 2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Replying to @${replyTo['sender']}',
            style: const TextStyle(
              color: ChatTheme.black,
              fontSize: 10,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            replyTo['message'] ?? '',
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: ChatTheme.textSecondary,
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  // ==================== REPLY PREVIEW ====================
  Widget _buildReplyPreviewBar({required bool isGlobal}) {
    final replyData = isGlobal ? _globalReplyTo : _privateReplyTo;
    if (replyData == null) return const SizedBox();

    return Container(
      margin: const EdgeInsets.fromLTRB(12, 4, 12, 4),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: ChatTheme.yellow,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: ChatTheme.black, width: 2.5),
        boxShadow: _HardShadow.sm,
      ),
      child: Row(
        children: [
          const Icon(Icons.reply_rounded,
              color: ChatTheme.black, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Replying to @${replyData['sender']}',
                  style: const TextStyle(
                    color: ChatTheme.black,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                Text(
                  replyData['message'] ?? '',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: ChatTheme.textSecondary,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              HapticFeedback.lightImpact();
              setState(() {
                if (isGlobal) {
                  _globalReplyTo = null;
                } else {
                  _privateReplyTo = null;
                }
              });
            },
            child: Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: ChatTheme.black,
                borderRadius: BorderRadius.circular(6),
              ),
              child: const Icon(Icons.close_rounded,
                  color: ChatTheme.yellow, size: 14),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== INPUT BAR (FLOATING, DI ATAS DOCK) ====================
  Widget _buildInputBar({
    required TextEditingController controller,
    required VoidCallback onSend,
    required String hint,
    required bool isGlobal,
  }) {
    return Padding(
      padding: EdgeInsets.only(
        left: 12,
        right: 12,
        top: 8,
        bottom: MediaQuery.of(context).viewPadding.bottom + 90,
      ),
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: ChatTheme.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: ChatTheme.black, width: 2.5),
          boxShadow: _HardShadow.sm,
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Text field
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                decoration: BoxDecoration(
                  color: ChatTheme.surface2,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: ChatTheme.black, width: 2),
                ),
                child: TextField(
                  controller: controller,
                  style: const TextStyle(
                    color: ChatTheme.black,
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  ),
                  decoration: InputDecoration(
                    hintText: hint,
                    hintStyle: const TextStyle(
                      color: ChatTheme.textMuted,
                      fontWeight: FontWeight.w600,
                      fontSize: 13,
                    ),
                    border: InputBorder.none,
                    isDense: true,
                    contentPadding:
                        const EdgeInsets.symmetric(vertical: 14),
                  ),
                  onSubmitted: (_) => onSend(),
                ),
              ),
            ),
            const SizedBox(width: 8),
            // Send button
            GestureDetector(
              onTap: () {
                HapticFeedback.mediumImpact();
                onSend();
              },
              child: Container(
                padding: const EdgeInsets.all(11),
                decoration: BoxDecoration(
                  color: ChatTheme.yellow,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: ChatTheme.black, width: 2.5),
                ),
                child: const Icon(Icons.send_rounded,
                    color: ChatTheme.black, size: 20),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── Empty State ────────────────────────────────────────────
  Widget _buildEmptyState(String title, String message, IconData icon) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: ChatTheme.yellow,
              shape: BoxShape.circle,
              border: Border.all(color: ChatTheme.black, width: 3),
              boxShadow: _HardShadow.md,
            ),
            child: Icon(icon, color: ChatTheme.black, size: 40),
          ),
          const SizedBox(height: 18),
          Text(
            title,
            style: const TextStyle(
              color: ChatTheme.black,
              fontSize: 16,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 6),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: ChatTheme.textMuted,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  ICON BUTTON
// ═══════════════════════════════════════════════════════════════════
class _IconBtn extends StatefulWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _IconBtn({required this.icon, required this.onTap});

  @override
  State<_IconBtn> createState() => _IconBtnState();
}

class _IconBtnState extends State<_IconBtn> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: () {
        HapticFeedback.lightImpact();
        widget.onTap();
      },
      child: AnimatedScale(
        duration: const Duration(milliseconds: 90),
        scale: _pressed ? 0.9 : 1.0,
        child: Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            color: ChatTheme.yellow,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: ChatTheme.black, width: 2.5),
            boxShadow: _HardShadow.sm,
          ),
          child: Icon(widget.icon, color: ChatTheme.black, size: 18),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  SHEET PENCARIAN USER
// ═══════════════════════════════════════════════════════════════════
class _SearchUserSheet extends StatefulWidget {
  final String sessionKey;
  final String currentUsername;
  final Function(Map<String, dynamic>) onSelectUser;

  const _SearchUserSheet({
    required this.sessionKey,
    required this.currentUsername,
    required this.onSelectUser,
  });

  @override
  State<_SearchUserSheet> createState() => _SearchUserSheetState();
}

class _SearchUserSheetState extends State<_SearchUserSheet> {
  final TextEditingController _searchCtrl = TextEditingController();
  List<dynamic> _results = [];
  bool _loading = false;
  Timer? _debounce;

  @override
  void dispose() {
    _debounce?.cancel();
    _searchCtrl.dispose();
    super.dispose();
  }

  void _search(String query) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 500), () async {
      if (query.length < 2) {
        setState(() => _results = []);
        return;
      }
      setState(() => _loading = true);
      try {
        final prefs = await SharedPreferences.getInstance();
        final sessionKey = prefs.getString('session_key') ?? widget.sessionKey;
        final res = await http.get(Uri.parse(
            '$BASE_URL/chat/search-users?key=$sessionKey&q=$query'));
        if (res.statusCode == 200) {
          final data = jsonDecode(res.body);
          if (data['valid'] == true) {
            setState(() => _results = data['users'] ?? []);
          }
        }
      } catch (e) {}
      setState(() => _loading = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.75,
      decoration: const BoxDecoration(
        color: ChatTheme.bg,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        border: Border(
          top: BorderSide(color: ChatTheme.black, width: 3),
          left: BorderSide(color: ChatTheme.black, width: 3),
          right: BorderSide(color: ChatTheme.black, width: 3),
        ),
      ),
      child: Column(
        children: [
          Container(
            margin: const EdgeInsets.only(top: 12),
            width: 40,
            height: 5,
            decoration: BoxDecoration(
              color: ChatTheme.black,
              borderRadius: BorderRadius.circular(3),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: ChatTheme.yellow,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: ChatTheme.black, width: 2.5),
                    boxShadow: _HardShadow.sm,
                  ),
                  child: const Icon(Icons.search_rounded,
                      color: ChatTheme.black, size: 22),
                ),
                const SizedBox(width: 14),
                const Expanded(
                  child: Text(
                    'CARI USER',
                    style: TextStyle(
                      color: ChatTheme.black,
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.5,
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: ChatTheme.black,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.close_rounded,
                        color: ChatTheme.yellow, size: 20),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextField(
              controller: _searchCtrl,
              onChanged: _search,
              style: const TextStyle(
                color: ChatTheme.black,
                fontWeight: FontWeight.w700,
              ),
              decoration: InputDecoration(
                hintText: 'Masukkan username...',
                hintStyle: const TextStyle(
                  color: ChatTheme.textMuted,
                  fontWeight: FontWeight.w600,
                ),
                prefixIcon: const Icon(Icons.person_search_rounded,
                    color: ChatTheme.black),
                filled: true,
                fillColor: ChatTheme.white,
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide:
                      const BorderSide(color: ChatTheme.black, width: 2.5),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide:
                      const BorderSide(color: ChatTheme.black, width: 3),
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: _loading
                ? const Center(
                    child: CircularProgressIndicator(
                        color: ChatTheme.black, strokeWidth: 3))
                : _results.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                color: ChatTheme.yellow,
                                shape: BoxShape.circle,
                                border: Border.all(
                                    color: ChatTheme.black, width: 3),
                              ),
                              child: const Icon(Icons.person_off_rounded,
                                  color: ChatTheme.black, size: 40),
                            ),
                            const SizedBox(height: 14),
                            const Text(
                              'Tidak ada user ditemukan',
                              style: TextStyle(
                                color: ChatTheme.black,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
                        itemCount: _results.length,
                        itemBuilder: (ctx, i) {
                          final user = _results[i];
                          final profile = user['profile'] ?? {};
                          return GestureDetector(
                            onTap: () {
                              HapticFeedback.lightImpact();
                              widget.onSelectUser(user);
                            },
                            child: Container(
                              margin: const EdgeInsets.only(bottom: 10),
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: ChatTheme.white,
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(
                                    color: ChatTheme.black, width: 2.5),
                                boxShadow: _HardShadow.sm,
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    width: 46,
                                    height: 46,
                                    decoration: BoxDecoration(
                                      color: ChatTheme.yellow,
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                          color: ChatTheme.black,
                                          width: 2.5),
                                    ),
                                    child: Center(
                                      child: Text(
                                        user['username'][0].toUpperCase(),
                                        style: const TextStyle(
                                          color: ChatTheme.black,
                                          fontSize: 18,
                                          fontWeight: FontWeight.w900,
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          profile['name'] ??
                                              user['username'],
                                          style: const TextStyle(
                                            color: ChatTheme.black,
                                            fontWeight: FontWeight.w900,
                                            fontSize: 14,
                                          ),
                                        ),
                                        if (profile['bio'] != null &&
                                            profile['bio'].isNotEmpty)
                                          Text(
                                            profile['bio'],
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(
                                              color: ChatTheme.textMuted,
                                              fontSize: 11,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: ChatTheme.yellow,
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(
                                          color: ChatTheme.black, width: 2),
                                    ),
                                    child: Text(
                                      user['role']?.toUpperCase() ?? 'MEMBER',
                                      style: const TextStyle(
                                        color: ChatTheme.black,
                                        fontSize: 9,
                                        fontWeight: FontWeight.w900,
                                        letterSpacing: 0.5,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}