// dashboard_page.dart - FINAL EDITION
// Story/Status server-sync + Custom Avatar + Modern Layout
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:system_info2/system_info2.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

import 'owner_page.dart';
import 'login_page.dart';
import 'device_dashboard.dart';
import 'chat.dart';
import 'profile_page.dart';

// ═══════════════════════════════════════════════════════════════════
//  NEO-BRUTALISM THEME
// ═══════════════════════════════════════════════════════════════════
class AppColors {
  static const bg           = Color(0xFFFFFFFF);
  static const surface      = Color(0xFFFFFFFF);
  static const yellow       = Color(0xFFFFE600);
  static const yellowSoft   = Color(0xFFFFF9CC);
  static const cyan         = Color(0xFF00E5FF);
  static const black        = Color(0xFF000000);
  static const white        = Color(0xFFFFFFFF);
  static const textPrimary  = Color(0xFF000000);
  static const textMuted    = Color(0xFF555555);
  static const success      = Color(0xFF00C853);
  static const error        = Color(0xFFFF1744);
  static const blue         = Color(0xFF2196F3);
  static const orange       = Color(0xFFFF9800);
}

class _S {
  static List<BoxShadow> get sm => const [
    BoxShadow(color: AppColors.black, offset: Offset(2, 2), blurRadius: 0),
  ];
  static List<BoxShadow> get md => const [
    BoxShadow(color: AppColors.black, offset: Offset(4, 4), blurRadius: 0),
  ];
  static List<BoxShadow> get lg => const [
    BoxShadow(color: AppColors.black, offset: Offset(6, 6), blurRadius: 0),
  ];
}

const String _kBase = 'http://alfa-store-officials.alfamarket2.my.id:4700';

// ═══════════════════════════════════════════════════════════════════
//  BRUTAL CARD
// ═══════════════════════════════════════════════════════════════════
class _BrutalCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final double radius;
  final Color? bgColor;
  final Color borderColor;
  final double borderWidth;
  final bool shadow;
  final VoidCallback? onTap;

  const _BrutalCard({
    required this.child,
    this.padding,
    this.radius = 20,
    this.bgColor,
    this.borderColor = AppColors.black,
    this.borderWidth = 3,
    this.shadow = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    Widget box = Container(
      padding: padding ?? const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: bgColor ?? AppColors.surface,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: borderColor, width: borderWidth),
        boxShadow: shadow ? _S.md : null,
      ),
      child: child,
    );

    if (onTap != null) return _PressWrapper(onTap: onTap!, child: box);
    return box;
  }
}

class _PressWrapper extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;
  const _PressWrapper({required this.child, required this.onTap});
  @override
  State<_PressWrapper> createState() => _PressWrapperState();
}

class _PressWrapperState extends State<_PressWrapper> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: () {
        HapticFeedback.lightImpact();
        widget.onTap();
      },
      child: AnimatedScale(
        duration: const Duration(milliseconds: 90),
        scale: _pressed ? 0.97 : 1.0,
        child: widget.child,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  VIDEO BANNER
// ═══════════════════════════════════════════════════════════════════
class _VideoBanner extends StatefulWidget {
  final String videoPath;
  const _VideoBanner({required this.videoPath});

  @override
  State<_VideoBanner> createState() => _VideoBannerState();
}

class _VideoBannerState extends State<_VideoBanner> {
  late VideoPlayerController _controller;
  bool _isInitialized = false;
  bool _hasError = false;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.asset(widget.videoPath)
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() => _isInitialized = true);
        _controller.setLooping(true);
        _controller.play();
      }).catchError((error) {
        debugPrint('Error loading video: $error');
        if (!mounted) return;
        setState(() {
          _isInitialized = true;
          _hasError = true;
        });
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.black, width: 3),
        boxShadow: _S.md,
        color: AppColors.black,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(17),
        child: AspectRatio(
          aspectRatio: 16 / 9,
          child: Stack(
            children: [
              Positioned.fill(
                child: _hasError
                    ? Container(
                        color: AppColors.yellow,
                        child: const Center(
                          child: Icon(Icons.videocam_off_rounded,
                              color: AppColors.black, size: 40),
                        ),
                      )
                    : (_isInitialized && _controller.value.isInitialized
                        ? VideoPlayer(_controller)
                        : Container(
                            color: AppColors.black,
                            child: const Center(
                              child: CircularProgressIndicator(
                                  color: AppColors.yellow, strokeWidth: 3),
                            ),
                          )),
              ),
              Positioned(
                top: 10,
                left: 10,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppColors.error,
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: AppColors.black, width: 2),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      _BlinkDot(),
                      SizedBox(width: 5),
                      Text(
                        'LIVE',
                        style: TextStyle(
                          color: AppColors.white,
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BlinkDot extends StatefulWidget {
  const _BlinkDot();
  @override
  State<_BlinkDot> createState() => _BlinkDotState();
}

class _BlinkDotState extends State<_BlinkDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600))
      ..repeat(reverse: true);
  }
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _c,
      child: Container(
        width: 6,
        height: 6,
        decoration: const BoxDecoration(
          color: AppColors.white,
          shape: BoxShape.circle,
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  DASHBOARD PAGE
// ═══════════════════════════════════════════════════════════════════
class DashboardPage extends StatefulWidget {
  final String username, password, role, expiredDate, sessionKey;
  final List<Map<String, dynamic>> listBug, listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

Route _createRoute(Widget page) {
  return PageRouteBuilder(
    transitionDuration: const Duration(milliseconds: 350),
    pageBuilder: (context, animation, secondaryAnimation) => page,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      const curve = Curves.easeOutCubic;
      var tween = Tween(begin: const Offset(0.03, 0.0), end: Offset.zero)
          .chain(CurveTween(curve: curve));
      var offsetAnimation = animation.drive(tween);
      var fadeTween =
          Tween(begin: 0.0, end: 1.0).chain(CurveTween(curve: curve));
      return FadeTransition(
        opacity: animation.drive(fadeTween),
        child: SlideTransition(position: offsetAnimation, child: child),
      );
    },
  );
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  WebSocketChannel? channel;
  final Battery _battery = Battery();

  late String sessionKey, username, role, expiredDate, password;
  String androidId = "unknown";
  int _bottomNavIndex = 0;
  Widget _selectedPage = const SizedBox();
  int _onlineDevices = 0;
  int _offlineDevices = 0;
  String _pairId = '';
  bool _isLoadingPairId = false;

  // ─── System Stats ──────────────────────────────────────
  int _ramPercent = 0;
  int _batteryPercent = 0;
  bool _systemStatsLoading = true;

  // ─── Story/Status ──────────────────────────────────────
  List<Map<String, dynamic>> _stories = [];
  String? _myAvatarPath;
  String? _myAvatarBase64;

  Timer? _statsTimer;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;

    _fadeCtrl = AnimationController(
        duration: const Duration(milliseconds: 450), vsync: this);
    _fadeAnim =
        CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOutCubic);
    _fadeCtrl.forward();

    _selectedPage = _buildDashboardHome();
    _initAndroidIdAndConnect();
    _loadDeviceStats();
    _loadPairId();
    _loadSystemStats();
    _loadMyAvatar();
    _loadStories();

    _statsTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted) {
        _loadSystemStats();
        _loadStories();
      }
    });
  }

  @override
  void dispose() {
    _statsTimer?.cancel();
    channel?.sink.close(status.goingAway);
    _fadeCtrl.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════
  //  STORY / STATUS (SERVER SYNC)
  // ═══════════════════════════════════════════════════════
  Future<void> _loadStories() async {
    try {
      final res = await http.get(
        Uri.parse('$_kBase/story/list?key=$sessionKey'),
      ).timeout(const Duration(seconds: 10));

      if (res.statusCode == 200) {
        final body = jsonDecode(res.body);
        if (body['valid'] == true) {
          final List<dynamic> list = body['stories'] ?? [];
          final now = DateTime.now();

          final loaded = <Map<String, dynamic>>[];
          for (final s in list) {
            try {
              final expires = DateTime.parse(s['expiresAt'] ?? '');
              if (expires.isAfter(now)) {
                loaded.add({
                  'id': s['id'],
                  'username': s['username'],
                  'text': s['text'],
                  'avatarBase64': s['avatarBase64'],
                  'createdAt': s['createdAt'],
                  'expiresAt': s['expiresAt'],
                  'isMine': s['username'] == username,
                });
              }
            } catch (_) {}
          }

          // Urutkan: story sendiri dulu, terus yang lain
          loaded.sort((a, b) {
            if (a['isMine'] == true && b['isMine'] != true) return -1;
            if (a['isMine'] != true && b['isMine'] == true) return 1;
            try {
              final aT = DateTime.parse(a['createdAt'].toString());
              final bT = DateTime.parse(b['createdAt'].toString());
              return bT.compareTo(aT);
            } catch (_) {
              return 0;
            }
          });

          if (mounted) setState(() => _stories = loaded);
        }
      }
    } catch (e) {
      debugPrint('Load stories error: $e');
    }
  }

  // ─── AVATAR ──────────────────────────────────────────────
  Future<void> _loadMyAvatar() async {
    try {
      final prefs = await SharedPreferences.getInstance();

      // Load dari lokal dulu (biar cepet)
      final localPath = prefs.getString('avatar_$username');
      final localBase64 = prefs.getString('avatar_b64_$username');
      if (mounted) {
        setState(() {
          _myAvatarPath = localPath;
          _myAvatarBase64 = localBase64;
        });
      }

      // Sync dari server
      final res = await http.get(
        Uri.parse('$_kBase/user/avatar?key=$sessionKey'),
      ).timeout(const Duration(seconds: 8));

      if (res.statusCode == 200) {
        final body = jsonDecode(res.body);
        if (body['valid'] == true && body['avatar'] != null) {
          final base64 = body['avatar'].toString();
          await prefs.setString('avatar_b64_$username', base64);
          if (mounted) setState(() => _myAvatarBase64 = base64);
        }
      }
    } catch (e) {
      debugPrint('Load avatar error: $e');
    }
  }

  Future<void> _pickAvatar() async {
    try {
      final picker = ImagePicker();
      final XFile? image = await picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 50,
        maxWidth: 300,
        maxHeight: 300,
      );
      if (image == null) return;

      final bytes = await File(image.path).readAsBytes();
      final base64Data = 'data:image/jpeg;base64,${base64Encode(bytes)}';

      if (base64Data.length > 500000) {
        _showToast('Foto terlalu besar, pilih yang lebih kecil',
            Icons.error_rounded);
        return;
      }

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('avatar_$username', image.path);
      await prefs.setString('avatar_b64_$username', base64Data);

      try {
        final res = await http.post(
          Uri.parse('$_kBase/user/avatar?key=$sessionKey'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'avatarBase64': base64Data}),
        ).timeout(const Duration(seconds: 15));

        if (res.statusCode == 200) {
          final body = jsonDecode(res.body);
          if (body['valid'] == true) {
            if (mounted) {
              setState(() {
                _myAvatarPath = image.path;
                _myAvatarBase64 = base64Data;
              });
            }
            _showToast('Foto profil diperbarui', Icons.check_circle_rounded);
            _loadStories(); // refresh biar avatar baru muncul di story
          } else {
            _showToast(body['error'] ?? 'Gagal upload', Icons.error_rounded);
          }
        } else {
          _showToast('Server error ${res.statusCode}', Icons.error_rounded);
        }
      } catch (e) {
        debugPrint('Upload avatar error: $e');
        _showToast('Gagal upload ke server', Icons.error_rounded);
      }
    } catch (e) {
      debugPrint('Pick avatar error: $e');
      _showToast('Gagal pilih foto', Icons.error_rounded);
    }
  }

  // ─── STORY CREATE ────────────────────────────────────────
  Future<void> _createStory() async {
    final textCtrl = TextEditingController();
    final result = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        padding: EdgeInsets.only(
          left: 20,
          right: 20,
          top: 20,
          bottom: MediaQuery.of(context).viewInsets.bottom + 20,
        ),
        decoration: const BoxDecoration(
          color: AppColors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          border: Border(
            top: BorderSide(color: AppColors.black, width: 3),
            left: BorderSide(color: AppColors.black, width: 3),
            right: BorderSide(color: AppColors.black, width: 3),
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 5,
                decoration: BoxDecoration(
                  color: AppColors.black,
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppColors.yellow,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppColors.black, width: 2.5),
                    boxShadow: _S.sm,
                  ),
                  child: const Icon(Icons.edit_rounded,
                      color: AppColors.black, size: 20),
                ),
                const SizedBox(width: 12),
                const Expanded(
                  child: Text(
                    'BUAT STATUS BARU',
                    style: TextStyle(
                      color: AppColors.black,
                      fontSize: 15,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.5,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            const Padding(
              padding: EdgeInsets.only(left: 46),
              child: Text(
                'Status akan terlihat oleh semua user • Expire 24 jam',
                style: TextStyle(
                  color: AppColors.textMuted,
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                color: AppColors.yellowSoft,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.black, width: 2.5),
              ),
              child: TextField(
                controller: textCtrl,
                maxLines: 4,
                maxLength: 200,
                autofocus: true,
                style: const TextStyle(
                  color: AppColors.black,
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                ),
                decoration: const InputDecoration(
                  hintText: 'Tulis status kamu...',
                  hintStyle: TextStyle(
                    color: AppColors.textMuted,
                    fontWeight: FontWeight.w600,
                  ),
                  border: InputBorder.none,
                  counterStyle: TextStyle(
                    color: AppColors.textMuted,
                    fontSize: 10,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        color: AppColors.white,
                        borderRadius: BorderRadius.circular(12),
                        border:
                            Border.all(color: AppColors.black, width: 2.5),
                      ),
                      child: const Center(
                        child: Text(
                          'BATAL',
                          style: TextStyle(
                            color: AppColors.black,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: GestureDetector(
                    onTap: () {
                      final text = textCtrl.text.trim();
                      if (text.isEmpty) return;
                      Navigator.pop(context, text);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        color: AppColors.yellow,
                        borderRadius: BorderRadius.circular(12),
                        border:
                            Border.all(color: AppColors.black, width: 2.5),
                        boxShadow: _S.sm,
                      ),
                      child: const Center(
                        child: Text(
                          'POSTING',
                          style: TextStyle(
                            color: AppColors.black,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );

    if (result != null && result.isNotEmpty && mounted) {
      try {
        final res = await http.post(
          Uri.parse('$_kBase/story/post?key=$sessionKey'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'text': result,
            'avatarBase64': _myAvatarBase64,
          }),
        ).timeout(const Duration(seconds: 15));

        if (res.statusCode == 200) {
          final body = jsonDecode(res.body);
          if (body['valid'] == true) {
            _showToast('Status berhasil diposting!',
                Icons.check_circle_rounded);
            await _loadStories();
          } else {
            _showToast(body['error'] ?? 'Gagal posting',
                Icons.error_rounded);
          }
        } else {
          _showToast('Server error ${res.statusCode}', Icons.error_rounded);
        }
      } catch (e) {
        debugPrint('Post story error: $e');
        _showToast('Gagal koneksi ke server', Icons.error_rounded);
      }
    }
  }

  // ═══════════════════════════════════════════════════════
  //  SYSTEM STATS
  // ═══════════════════════════════════════════════════════
  Future<void> _loadSystemStats() async {
    try {
      int batteryLevel = 0;
      try {
        batteryLevel = await _battery.batteryLevel;
      } catch (e) {
        debugPrint('Battery level error: $e');
      }

      int ramPercent = 0;
      try {
        final totalBytes = SysInfo.getTotalPhysicalMemory();
        final freeBytes = SysInfo.getFreePhysicalMemory();
        if (totalBytes > 0) {
          final used = totalBytes - freeBytes;
          ramPercent = ((used / totalBytes) * 100).round().clamp(0, 100);
        }
      } catch (e) {
        debugPrint('RAM error: $e');
      }

      if (mounted) {
        setState(() {
          _batteryPercent = batteryLevel;
          _ramPercent = ramPercent;
          _systemStatsLoading = false;
        });
      }
    } catch (e) {
      debugPrint('Error loading stats: $e');
      if (mounted) {
        setState(() {
          _batteryPercent = 0;
          _ramPercent = 0;
          _systemStatsLoading = false;
        });
      }
    }
  }

  // ─── PAIR ID ────────────────────────────────────────────
  Future<void> _loadPairId() async {
    if (_isLoadingPairId) return;
    setState(() => _isLoadingPairId = true);
    try {
      final response = await http
          .get(Uri.parse('$_kBase/rat/pairid?key=$sessionKey'))
          .timeout(const Duration(seconds: 8));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true && data['pairId'] != null) {
          if (mounted) setState(() => _pairId = data['pairId'].toString());
        }
      }
    } catch (e) {
      debugPrint('Error loading pairId: $e');
    } finally {
      if (mounted) setState(() => _isLoadingPairId = false);
    }
  }

  void _copyPairId() {
    if (_pairId.isEmpty) return;
    Clipboard.setData(ClipboardData(text: _pairId));
    _showToast('ID Pairing berhasil disalin!', Icons.copy_rounded);
  }

  void _showToast(String message, IconData icon) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: AppColors.black,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: AppColors.black, width: 2),
        ),
        content: Row(
          children: [
            Icon(icon, color: AppColors.yellow, size: 18),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                message,
                style: const TextStyle(
                  color: AppColors.yellow,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ],
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // ─── DEVICE STATS ───────────────────────────────────────
  Future<void> _loadDeviceStats() async {
    try {
      final response = await http
          .get(Uri.parse('$_kBase/rat/my-devices?key=$sessionKey'))
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final body = jsonDecode(response.body);
        if (body['valid'] == true) {
          List<dynamic> devices = body['devices'] ?? [];
          int online = 0, offline = 0;
          for (var d in devices) {
            try {
              final seen = DateTime.parse(d['lastSeen']?.toString() ?? '');
              if (DateTime.now().difference(seen).inSeconds < 30) {
                online++;
              } else {
                offline++;
              }
            } catch (_) {
              offline++;
            }
          }
          if (mounted) {
            setState(() {
              _onlineDevices = online;
              _offlineDevices = offline;
            });
          }
        }
      }
    } catch (e) {
      debugPrint('Error loading device stats: $e');
    }
  }

  // ─── WEBSOCKET ──────────────────────────────────────────
  Future<void> _initAndroidIdAndConnect() async {
    try {
      final deviceInfo = await DeviceInfoPlugin().androidInfo;
      androidId = deviceInfo.id;
    } catch (e) {
      debugPrint('Error getting android id: $e');
    }
    _connectWebSocket();
  }

  void _connectWebSocket() {
    try {
      channel?.sink.close(status.goingAway);
      final ch = WebSocketChannel.connect(
          Uri.parse('wss://ws:privatesrvrenn.sano.biz.id:10831'));
      channel = ch;
      ch.sink.add(jsonEncode({
        "type": "validate",
        "key": sessionKey,
        "androidId": androidId,
      }));
      ch.stream.listen(
        (event) {
          try {
            final data = jsonDecode(event);
            if (data['type'] == 'myInfo' && data['valid'] == false) {
              _showSessionExpired();
            } else if (data['type'] == 'story_posted') {
              _loadStories();
            } else if (data['type'] == 'story_deleted') {
              _loadStories();
            }
          } catch (e) {
            debugPrint('WS parse error: $e');
          }
        },
        onError: (e) => debugPrint('WS error: $e'),
        onDone: () => debugPrint('WS closed'),
      );
    } catch (e) {
      debugPrint('WS connect error: $e');
    }
  }

  void _showSessionExpired() async {
    await SharedPreferences.getInstance().then((p) => p.clear());
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: _BrutalCard(
          radius: 20,
          bgColor: AppColors.yellow,
          shadow: true,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.black, width: 2.5),
              ),
              child: const Icon(Icons.warning_amber_rounded,
                  color: AppColors.error, size: 30),
            ),
            const SizedBox(height: 14),
            const Text("Session Expired",
                style: TextStyle(
                    color: AppColors.black,
                    fontWeight: FontWeight.w900,
                    fontSize: 17)),
            const SizedBox(height: 6),
            const Text("Silakan login kembali",
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: AppColors.black,
                    fontWeight: FontWeight.w600,
                    fontSize: 12)),
            const SizedBox(height: 18),
            _BlackButton(
              text: "OK",
              onTap: () => Navigator.pushAndRemoveUntil(
                  context,
                  _createRoute(const LoginPage()),
                  (r) => false),
            ),
          ]),
        ),
      ),
    );
  }

  // ─── NAV ────────────────────────────────────────────────
  void _onNavTapped(int index) {
    if (_bottomNavIndex == index) return;
    HapticFeedback.lightImpact();
    setState(() {
      _bottomNavIndex = index;
      if (index == 0) {
        _selectedPage = _buildDashboardHome();
        _loadDeviceStats();
        _loadSystemStats();
        _loadStories();
      } else if (index == 1) {
        _selectedPage =
            ChatPage(username: username, sessionKey: sessionKey);
      } else if (index == 2) {
        _selectedPage = DeviceDashboardPage(
            username: username, role: role, sessionKey: sessionKey);
      }
    });
  }

  void _navigateToOwner() => Navigator.push(
      context,
      _createRoute(
          OwnerPage(sessionKey: sessionKey, username: username)));

  void _showAccountSheet() {
    if (_pairId.isEmpty && !_isLoadingPairId) _loadPairId();
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ProfilePage(
          username: username,
          password: password,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
          ratId: _pairId.isEmpty ? '—' : _pairId,
        ),
      ),
    );
  }

  void _showNotificationSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        padding: const EdgeInsets.all(20),
        decoration: const BoxDecoration(
          color: AppColors.bg,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          border: Border(top: BorderSide(color: AppColors.black, width: 3)),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
              width: 40,
              height: 5,
              decoration: BoxDecoration(
                  color: AppColors.black,
                  borderRadius: BorderRadius.circular(3))),
          const SizedBox(height: 20),
          _BrutalCard(
            bgColor: AppColors.yellow,
            shadow: true,
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppColors.black,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.mail_outline_rounded,
                      color: AppColors.yellow, size: 20),
                ),
                const SizedBox(width: 12),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Inbox Pesan',
                          style: TextStyle(
                              color: AppColors.black,
                              fontSize: 13,
                              fontWeight: FontWeight.w900)),
                      SizedBox(height: 4),
                      Text('Kalau Ada Error Bisa Hubungi @dapzyyyyyyahaha',
                          style: TextStyle(
                              color: AppColors.black,
                              fontSize: 11,
                              fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
        ]),
      ),
    );
  }

  void _showComingSoonToast() {
    _showToast('Feature Coming Soon', Icons.construction_rounded);
  }

  // ═══════════════════════════════════════════════════════
  //  DASHBOARD HOME
  // ═══════════════════════════════════════════════════════
  Widget _buildDashboardHome() {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 110),
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Video + Welcome
          _buildWelcomeCard(),
          const SizedBox(height: 22),

          // Story section
          _buildStorySection(),
          const SizedBox(height: 22),

          // Overview header
          _buildSectionHeader('OVERVIEW', 'Live System information'),
          const SizedBox(height: 14),

          // Profile card
          _buildProfileCard(),
          const SizedBox(height: 14),

          // Stats grid
          _buildStatsGrid(),
        ],
      ),
    );
  }

  // ─── WELCOME CARD ───────────────────────────────────────
  Widget _buildWelcomeCard() {
    return Column(
      children: [
        const _VideoBanner(videoPath: 'assets/videos/flux.mp4'),
        const SizedBox(height: 14),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppColors.yellow,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.black, width: 3),
            boxShadow: _S.md,
          ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'Welcome, $username',
                      style: const TextStyle(
                        color: AppColors.black,
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.3,
                        height: 1.1,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'Developer by @dapzyyyyyyahaha',
                      style: TextStyle(
                        color: AppColors.black,
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppColors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.black, width: 2.5),
                  boxShadow: _S.sm,
                ),
                child: const Icon(Icons.waving_hand_rounded,
                    color: AppColors.black, size: 24),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ─── STORY SECTION ──────────────────────────────────────
  Widget _buildStorySection() {
    final hasAnyStory = _stories.isNotEmpty;
    final otherStories = _stories.where((s) => s['isMine'] != true).toList();
    final myStory = _stories.firstWhere(
      (s) => s['isMine'] == true,
      orElse: () => {},
    );
    final hasMyStory = myStory.isNotEmpty;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Header
        Row(
          children: [
            Container(
              width: 6,
              height: 32,
              decoration: BoxDecoration(
                color: AppColors.blue,
                borderRadius: BorderRadius.circular(3),
              ),
            ),
            const SizedBox(width: 10),
            const Text(
              'STATUS',
              style: TextStyle(
                color: AppColors.black,
                fontSize: 16,
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(width: 8),
            if (hasAnyStory)
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: AppColors.blue,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  '${_stories.length}',
                  style: const TextStyle(
                    color: AppColors.white,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            const Spacer(),
            Text(
              hasAnyStory ? '24 JAM' : 'Belum ada',
              style: TextStyle(
                color: AppColors.textMuted.withOpacity(0.8),
                fontSize: 10,
                fontWeight: FontWeight.w700,
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),

        // Story row
        SizedBox(
          height: 100,
          child: ListView(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            children: [
              // Tombol "Cerita Anda"
              _buildAddStoryButton(hasMyStory: hasMyStory),
              const SizedBox(width: 10),

              // List story (user lain)
              ...otherStories.map((s) => Padding(
                    padding: const EdgeInsets.only(right: 10),
                    child: _buildStoryBubble(s),
                  )),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildAddStoryButton({required bool hasMyStory}) {
    return GestureDetector(
      onTap: hasMyStory
          ? () => _viewStory(
              _stories.firstWhere((s) => s['isMine'] == true))
          : _createStory,
      onLongPress: hasMyStory ? _createStory : null,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 70,
            height: 70,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: hasMyStory ? AppColors.black : AppColors.blue,
                width: 3,
              ),
              boxShadow: _S.sm,
            ),
            child: Padding(
              padding: const EdgeInsets.all(3),
              child: Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.white,
                  border: Border.all(color: AppColors.black, width: 2),
                ),
                child: Stack(
                  children: [
                    // Avatar user
                    ClipOval(
                      child: _myAvatarBase64 != null
                          ? _buildBase64Image(_myAvatarBase64!)
                          : (_myAvatarPath != null &&
                                  File(_myAvatarPath!).existsSync()
                              ? Image.file(File(_myAvatarPath!),
                                  fit: BoxFit.cover)
                              : Container(
                                  color: AppColors.yellow,
                                  child: Center(
                                    child: Text(
                                      username.isNotEmpty
                                          ? username[0].toUpperCase()
                                          : '?',
                                      style: const TextStyle(
                                        color: AppColors.black,
                                        fontSize: 24,
                                        fontWeight: FontWeight.w900,
                                      ),
                                    ),
                                  ),
                                )),
                    ),
                    // Tombol + di pojok
                    if (!hasMyStory)
                      Positioned(
                        right: 0,
                        bottom: 0,
                        child: Container(
                          width: 22,
                          height: 22,
                          decoration: BoxDecoration(
                            color: AppColors.blue,
                            shape: BoxShape.circle,
                            border:
                                Border.all(color: AppColors.black, width: 2),
                          ),
                          child: const Icon(Icons.add_rounded,
                              color: AppColors.white, size: 14),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: 70,
            child: Text(
              hasMyStory ? 'Status Anda' : 'Cerita Anda',
              style: const TextStyle(
                color: AppColors.black,
                fontSize: 10,
                fontWeight: FontWeight.w800,
              ),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStoryBubble(Map<String, dynamic> story) {
    return GestureDetector(
      onTap: () => _viewStory(story),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 70,
            height: 70,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.blue, width: 3),
              boxShadow: _S.sm,
            ),
            child: Padding(
              padding: const EdgeInsets.all(3),
              child: Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.white,
                  border: Border.all(color: AppColors.black, width: 2),
                ),
                child: ClipOval(
                  child: _buildStoryAvatar(story),
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: 70,
            child: Text(
              story['username'].toString(),
              style: const TextStyle(
                color: AppColors.black,
                fontSize: 10,
                fontWeight: FontWeight.w800,
              ),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStoryAvatar(Map<String, dynamic> story) {
    final avatarB64 = story['avatarBase64'];
    if (avatarB64 != null &&
        avatarB64.toString().startsWith('data:image')) {
      return _buildBase64Image(avatarB64.toString());
    }

    if (story['isMine'] == true && _myAvatarPath != null) {
      final file = File(_myAvatarPath!);
      if (file.existsSync()) {
        return Image.file(file, fit: BoxFit.cover);
      }
    }

    return Container(
      color: AppColors.yellow,
      child: Center(
        child: Text(
          story['username'].toString().isNotEmpty
              ? story['username'].toString()[0].toUpperCase()
              : '?',
          style: const TextStyle(
            color: AppColors.black,
            fontSize: 24,
            fontWeight: FontWeight.w900,
          ),
        ),
      ),
    );
  }

  Widget _buildBase64Image(String base64Str) {
    try {
      final cleanB64 = base64Str.contains(',')
          ? base64Str.split(',').last
          : base64Str;
      final bytes = base64Decode(cleanB64);
      return Image.memory(bytes, fit: BoxFit.cover);
    } catch (_) {
      return Container(color: AppColors.yellow);
    }
  }

  void _viewStory(Map<String, dynamic> story) {
    final isMine = story['isMine'] == true;
    DateTime createdAt;
    try {
      createdAt = DateTime.parse(story['createdAt'].toString());
    } catch (_) {
      createdAt = DateTime.now();
    }

    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(20),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: AppColors.yellow,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: AppColors.black, width: 4),
            boxShadow: _S.lg,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.black, width: 2.5),
                    ),
                    child: ClipOval(child: _buildStoryAvatar(story)),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      isMine ? 'Status Anda' : story['username'].toString(),
                      style: const TextStyle(
                        color: AppColors.black,
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: AppColors.black,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(Icons.close_rounded,
                          color: AppColors.yellow, size: 16),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: AppColors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.black, width: 3),
                ),
                child: Text(
                  story['text'].toString(),
                  style: const TextStyle(
                    color: AppColors.black,
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    height: 1.5,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 14),
              Text(
                _formatStoryTime(createdAt),
                style: const TextStyle(
                  color: AppColors.black,
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                ),
              ),
              if (isMine) ...[
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                          _createStory();
                        },
                        child: Container(
                          padding:
                              const EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                            color: AppColors.yellow,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                                color: AppColors.black, width: 2.5),
                          ),
                          child: const Row(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.edit_rounded,
                                  color: AppColors.black, size: 14),
                              SizedBox(width: 4),
                              Text(
                                'UBAH',
                                style: TextStyle(
                                  color: AppColors.black,
                                  fontWeight: FontWeight.w900,
                                  fontSize: 11,
                                  letterSpacing: 1,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: GestureDetector(
                        onTap: () async {
                          Navigator.pop(context);
                          await _deleteStory(story['id'].toString());
                        },
                        child: Container(
                          padding:
                              const EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                            color: AppColors.error,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                                color: AppColors.black, width: 2.5),
                          ),
                          child: const Row(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.delete_rounded,
                                  color: AppColors.white, size: 14),
                              SizedBox(width: 4),
                              Text(
                                'HAPUS',
                                style: TextStyle(
                                  color: AppColors.white,
                                  fontWeight: FontWeight.w900,
                                  fontSize: 11,
                                  letterSpacing: 1,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _deleteStory(String storyId) async {
    try {
      final res = await http.delete(
        Uri.parse('$_kBase/story/$storyId?key=$sessionKey'),
      ).timeout(const Duration(seconds: 10));

      if (res.statusCode == 200) {
        _showToast('Status dihapus', Icons.delete_rounded);
        await _loadStories();
      }
    } catch (e) {
      debugPrint('Delete story error: $e');
    }
  }

  String _formatStoryTime(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 1) return 'Baru saja';
    if (diff.inMinutes < 60) return '${diff.inMinutes} menit lalu';
    if (diff.inHours < 24) return '${diff.inHours} jam lalu';
    return '${diff.inDays} hari lalu';
  }

  // ─── SECTION HEADER ─────────────────────────────────────
  Widget _buildSectionHeader(String title, String subtitle) {
    return Row(
      children: [
        Container(
          width: 8,
          height: 44,
          decoration: BoxDecoration(
            color: AppColors.black,
            borderRadius: BorderRadius.circular(4),
          ),
        ),
        const SizedBox(width: 12),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              title,
              style: const TextStyle(
                color: AppColors.black,
                fontSize: 22,
                fontWeight: FontWeight.w900,
                letterSpacing: 1,
                height: 1.0,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              subtitle,
              style: TextStyle(
                color: AppColors.textMuted.withOpacity(0.7),
                fontSize: 11,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.3,
              ),
            ),
          ],
        ),
      ],
    );
  }

  // ─── PROFILE CARD ───────────────────────────────────────
  Widget _buildProfileCard() {
    final hasAvatar = _myAvatarPath != null &&
        _myAvatarPath!.isNotEmpty &&
        File(_myAvatarPath!).existsSync();

    return GestureDetector(
      onTap: _pickAvatar,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.yellow,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.black, width: 3),
          boxShadow: _S.md,
        ),
        child: Row(
          children: [
            Stack(
              children: [
                Container(
                  width: 62,
                  height: 62,
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.black, width: 3),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(11),
                    child: _myAvatarBase64 != null
                        ? _buildBase64Image(_myAvatarBase64!)
                        : (hasAvatar
                            ? Image.file(File(_myAvatarPath!),
                                fit: BoxFit.cover)
                            : Image.asset(
                                'assets/images/a.jpg',
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => const Icon(
                                  Icons.person_rounded,
                                  color: AppColors.black,
                                  size: 32,
                                ),
                              )),
                  ),
                ),
                Positioned(
                  right: -2,
                  bottom: -2,
                  child: Container(
                    padding: const EdgeInsets.all(3),
                    decoration: BoxDecoration(
                      color: AppColors.black,
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.yellow, width: 2),
                    ),
                    child: const Icon(Icons.edit_rounded,
                        color: AppColors.yellow, size: 10),
                  ),
                ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    username,
                    style: const TextStyle(
                      color: AppColors.black,
                      fontSize: 17,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.5,
                      height: 1.0,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 5),
                  Container(
                    height: 2.5,
                    width: 70,
                    decoration: BoxDecoration(
                      color: AppColors.black,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(height: 7),
                  Row(
                    children: [
                      _buildChip(
                          'ONLINE', AppColors.black, AppColors.yellow),
                      const SizedBox(width: 5),
                      _buildChip(
                        role.toUpperCase(),
                        _getRoleColor(role),
                        AppColors.white,
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(width: 6),
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 10, vertical: 8),
              decoration: BoxDecoration(
                color: AppColors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppColors.black, width: 2.5),
                boxShadow: _S.sm,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.calendar_today_rounded,
                      color: AppColors.black, size: 14),
                  const SizedBox(height: 3),
                  Text(
                    expiredDate.length > 10
                        ? expiredDate.substring(0, 10)
                        : expiredDate,
                    style: const TextStyle(
                      color: AppColors.black,
                      fontSize: 9,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChip(String label, Color bg, Color text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: AppColors.black, width: 2),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: text,
          fontSize: 8,
          fontWeight: FontWeight.w900,
          letterSpacing: 1,
        ),
      ),
    );
  }

  Color _getRoleColor(String role) {
    final lowerRole = role.toLowerCase();
    if (lowerRole == 'owner') return AppColors.error;
    if (lowerRole == 'reseller' || lowerRole == 'admin') {
      return AppColors.success;
    }
    return AppColors.blue;
  }

  // ─── STATS GRID ─────────────────────────────────────────
  Widget _buildStatsGrid() {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: _buildTile(
                title: 'DEVICE\nONLINE',
                value: '$_onlineDevices',
                subtitle: 'Terhubung',
                icon: Icons.check_circle_rounded,
                accentColor: AppColors.success,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _buildTile(
                title: 'DEVICE\nOFFLINE',
                value: '$_offlineDevices',
                subtitle: 'Terputus',
                icon: Icons.cancel_rounded,
                accentColor: AppColors.error,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _buildTile(
                title: 'RAM',
                value: _systemStatsLoading ? '—' : '$_ramPercent%',
                subtitle: 'Memory',
                icon: Icons.memory_rounded,
                accentColor: AppColors.blue,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: _buildTile(
                title: 'BATTERY',
                value: _systemStatsLoading ? '—' : '$_batteryPercent%',
                subtitle: 'Level',
                icon: Icons.battery_charging_full_rounded,
                accentColor: AppColors.success,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _buildTile(
                title: 'SUHU',
                value: 'N/A',
                subtitle: 'Not supported',
                icon: Icons.thermostat_rounded,
                accentColor: AppColors.orange,
              ),
            ),
            const SizedBox(width: 10),
            const Expanded(child: _ClockTile()),
          ],
        ),
      ],
    );
  }

  Widget _buildTile({
    required String title,
    required String value,
    String? subtitle,
    required IconData icon,
    required Color accentColor,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.black, width: 3),
        boxShadow: _S.sm,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    color: AppColors.black,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.2,
                    height: 1.1,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: accentColor,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppColors.black, width: 2),
                ),
                child: Icon(icon, color: AppColors.white, size: 14),
              ),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                value,
                style: const TextStyle(
                  color: AppColors.black,
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  height: 1.0,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              if (subtitle != null) ...[
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color: AppColors.textMuted,
                    fontSize: 9,
                    fontWeight: FontWeight.w700,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }

  // ─── BOTTOM NAV ─────────────────────────────────────────
  Widget _buildBottomNav() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        child: Container(
          height: 68,
          decoration: BoxDecoration(
            color: AppColors.bg,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: AppColors.black, width: 3),
            boxShadow: _S.md,
          ),
          child: Row(
            children: [
              _NavItem(
                icon: Icons.grid_view_rounded,
                label: 'Dashboard',
                isActive: _bottomNavIndex == 0,
                onTap: () => _onNavTapped(0),
              ),
              _NavItem(
                icon: Icons.chat_bubble_outline_rounded,
                activeIcon: Icons.chat_bubble_rounded,
                label: 'Chat',
                isActive: _bottomNavIndex == 1,
                onTap: () => _onNavTapped(1),
              ),
              _NavItem(
                icon: Icons.devices_outlined,
                activeIcon: Icons.devices_rounded,
                label: 'Device',
                isActive: _bottomNavIndex == 2,
                onTap: () => _onNavTapped(2),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── APP BAR ────────────────────────────────────────────
  AppBar _buildAppBar() {
    return AppBar(
      backgroundColor: AppColors.bg,
      elevation: 0,
      toolbarHeight: 62,
      leadingWidth: 50,
      titleSpacing: 0,
      centerTitle: false,
      leading: Padding(
        padding: const EdgeInsets.only(left: 12),
        child: Builder(
          builder: (ctx) => Center(
            child: GestureDetector(
              onTap: () => Scaffold.of(ctx).openDrawer(),
              child: Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: AppColors.yellow,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppColors.black, width: 2.5),
                  boxShadow: _S.sm,
                ),
                child: const Icon(Icons.menu_rounded,
                    color: AppColors.black, size: 18),
              ),
            ),
          ),
        ),
      ),
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: AppColors.yellow,
              borderRadius: BorderRadius.circular(9),
              border: Border.all(color: AppColors.black, width: 2.5),
              boxShadow: _S.sm,
            ),
            child: const Icon(Icons.bolt_rounded,
                color: AppColors.black, size: 19),
          ),
          const SizedBox(width: 8),
          const Text(
            'DRAXION RAT',
            style: TextStyle(
              fontFamily: 'Genetic',
              fontSize: 20,
              fontWeight: FontWeight.w900,
              color: AppColors.black,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: 12),
          child: Row(
            children: [
              _TopIconButton(
                icon: Icons.help_outline_rounded,
                onTap: _showComingSoonToast,
              ),
              const SizedBox(width: 6),
              _TopIconButton(
                icon: Icons.notifications_outlined,
                onTap: _showNotificationSheet,
              ),
              const SizedBox(width: 6),
              _ProfileAvatar(
                avatarPath: _myAvatarPath,
                avatarBase64: _myAvatarBase64,
                onTap: _showAccountSheet,
              ),
            ],
          ),
        ),
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(3),
        child: Container(height: 3, color: AppColors.black),
      ),
    );
  }

  // ─── DRAWER ─────────────────────────────────────────────
  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: AppColors.bg,
      width: MediaQuery.of(context).size.width * 0.8,
      child: Column(children: [
        Container(
          height: 200,
          decoration: const BoxDecoration(
            color: AppColors.yellow,
            border: Border(
                bottom: BorderSide(color: AppColors.black, width: 3)),
          ),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                GestureDetector(
                  onTap: _pickAvatar,
                  child: Stack(
                    children: [
                      Container(
                        width: 80,
                        height: 80,
                        decoration: BoxDecoration(
                          color: AppColors.white,
                          shape: BoxShape.circle,
                          border:
                              Border.all(color: AppColors.black, width: 3),
                          boxShadow: _S.md,
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(40),
                          child: _myAvatarBase64 != null
                              ? _buildBase64Image(_myAvatarBase64!)
                              : (_myAvatarPath != null &&
                                      File(_myAvatarPath!).existsSync()
                                  ? Image.file(File(_myAvatarPath!),
                                      fit: BoxFit.cover)
                                  : Image.asset(
                                      'assets/images/logo.png',
                                      fit: BoxFit.cover,
                                      errorBuilder: (_, __, ___) =>
                                          const Icon(
                                              Icons.person_outline,
                                              color: AppColors.black,
                                              size: 40),
                                    )),
                        ),
                      ),
                      Positioned(
                        right: 0,
                        bottom: 0,
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            color: AppColors.black,
                            shape: BoxShape.circle,
                            border: Border.all(
                                color: AppColors.yellow, width: 2),
                          ),
                          child: const Icon(Icons.edit_rounded,
                              color: AppColors.yellow, size: 12),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  username,
                  style: const TextStyle(
                      color: AppColors.black,
                      fontSize: 16,
                      fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 4),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                  decoration: BoxDecoration(
                    color: AppColors.black,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    role.toUpperCase(),
                    style: const TextStyle(
                        color: AppColors.yellow,
                        fontSize: 9,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1),
                  ),
                ),
              ],
            ),
          ),
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              if (role.toLowerCase() == 'owner')
                _DrawerItem(
                  icon: Icons.storefront_rounded,
                  title: 'Owner Panel',
                  onTap: () {
                    Navigator.pop(context);
                    _navigateToOwner();
                  },
                ),
              _DrawerItem(
                icon: Icons.person_rounded,
                title: 'Profile',
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ProfilePage(
                        username: username,
                        password: password,
                        role: role,
                        expiredDate: expiredDate,
                        sessionKey: sessionKey,
                        ratId: _pairId,
                      ),
                    ),
                  );
                },
              ),
              _DrawerItem(
                icon: Icons.image_rounded,
                title: 'Ganti Foto',
                onTap: () {
                  Navigator.pop(context);
                  _pickAvatar();
                },
              ),
              _DrawerItem(
                icon: Icons.link_rounded,
                title: 'Pairing ID',
                onTap: () {
                  Navigator.pop(context);
                  if (_pairId.isNotEmpty) {
                    _copyPairId();
                  } else {
                    _loadPairId();
                  }
                },
              ),
              if (_pairId.isNotEmpty) ...[
                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 4, vertical: 6),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 10),
                    decoration: BoxDecoration(
                      color: AppColors.yellow,
                      borderRadius: BorderRadius.circular(10),
                      border:
                          Border.all(color: AppColors.black, width: 2.5),
                      boxShadow: _S.sm,
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            _pairId,
                            style: const TextStyle(
                              color: AppColors.black,
                              fontSize: 13,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 2,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        const SizedBox(width: 6),
                        GestureDetector(
                          onTap: _copyPairId,
                          child: Container(
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: AppColors.black,
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: const Icon(Icons.copy_rounded,
                                color: AppColors.yellow, size: 14),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
              if (_isLoadingPairId)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 8),
                  child: Center(
                    child: SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                          strokeWidth: 2.5, color: AppColors.black),
                    ),
                  ),
                ),
              const SizedBox(height: 8),
              Container(height: 2, color: AppColors.black),
              const SizedBox(height: 8),
              _DrawerItem(
                icon: Icons.logout_rounded,
                title: 'Logout',
                onTap: () {
                  Navigator.pop(context);
                  _showLogoutDialog();
                },
              ),
              const SizedBox(height: 24),
              const Center(
                child: Text(
                  "© 2026 - DRAXION RAT",
                  style: TextStyle(
                      color: AppColors.textMuted,
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 3),
                ),
              ),
            ],
          ),
        ),
      ]),
    );
  }

  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: _BrutalCard(
          radius: 20,
          bgColor: AppColors.yellow,
          shadow: true,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                color: AppColors.white,
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.black, width: 3),
              ),
              child: const Icon(Icons.logout_rounded,
                  color: AppColors.black, size: 28),
            ),
            const SizedBox(height: 12),
            const Text("Konfirmasi Logout",
                style: TextStyle(
                    color: AppColors.black,
                    fontWeight: FontWeight.w900,
                    fontSize: 16)),
            const SizedBox(height: 6),
            const Text("Yakin ingin logout?",
                style: TextStyle(
                    color: AppColors.black,
                    fontWeight: FontWeight.w600,
                    fontSize: 12)),
            const SizedBox(height: 20),
            Row(mainAxisAlignment: MainAxisAlignment.end, children: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("Batal",
                    style: TextStyle(
                        color: AppColors.black,
                        fontWeight: FontWeight.w800)),
              ),
              const SizedBox(width: 8),
              _BlackButton(
                text: "Logout",
                onTap: () async {
                  Navigator.pop(context);
                  await SharedPreferences.getInstance()
                      .then((p) => p.clear());
                  if (mounted) {
                    Navigator.pushAndRemoveUntil(
                        context,
                        _createRoute(const LoginPage()),
                        (r) => false);
                  }
                },
              ),
            ]),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      drawer: _buildDrawer(),
      appBar: _buildAppBar(),
      extendBody: true,
      body: FadeTransition(opacity: _fadeAnim, child: _selectedPage),
      bottomNavigationBar: _buildBottomNav(),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  CLOCK TILE
// ═══════════════════════════════════════════════════════════════════
class _ClockTile extends StatefulWidget {
  const _ClockTile();

  @override
  State<_ClockTile> createState() => _ClockTileState();
}

class _ClockTileState extends State<_ClockTile> {
  late Timer _timer;
  DateTime _now = DateTime.now();

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  String _two(int n) => n.toString().padLeft(2, '0');

  @override
  Widget build(BuildContext context) {
    final hh = _two(_now.hour);
    final mm = _two(_now.minute);
    final ss = _two(_now.second);

    final days = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
    final months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN',
                    'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
    final dateStr =
        '${days[_now.weekday % 7]}, ${_now.day} ${months[_now.month - 1]}';

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.black, width: 3),
        boxShadow: _S.sm,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'JAM',
                style: TextStyle(
                  color: AppColors.black,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.2,
                  height: 1.1,
                ),
              ),
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: AppColors.orange,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppColors.black, width: 2),
                ),
                child: const Icon(Icons.access_time_rounded,
                    color: AppColors.white, size: 14),
              ),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: hh,
                      style: const TextStyle(
                        color: AppColors.black,
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        height: 1.0,
                      ),
                    ),
                    TextSpan(
                      text: ':$mm',
                      style: const TextStyle(
                        color: AppColors.black,
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        height: 1.0,
                      ),
                    ),
                    TextSpan(
                      text: ':$ss',
                      style: const TextStyle(
                        color: AppColors.textMuted,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 4),
              Text(
                dateStr,
                style: const TextStyle(
                  color: AppColors.textMuted,
                  fontSize: 9,
                  fontWeight: FontWeight.w700,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  TOP ICON BUTTON
// ═══════════════════════════════════════════════════════════════════
class _TopIconButton extends StatefulWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _TopIconButton({required this.icon, required this.onTap});

  @override
  State<_TopIconButton> createState() => _TopIconButtonState();
}

class _TopIconButtonState extends State<_TopIconButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: () {
        HapticFeedback.lightImpact();
        widget.onTap();
      },
      child: AnimatedScale(
        duration: const Duration(milliseconds: 90),
        scale: _pressed ? 0.9 : 1.0,
        child: Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: AppColors.yellow,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.black, width: 2.5),
            boxShadow: _S.sm,
          ),
          child: Icon(widget.icon, color: AppColors.black, size: 17),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  PROFILE AVATAR
// ═══════════════════════════════════════════════════════════════════
class _ProfileAvatar extends StatefulWidget {
  final String? avatarPath;
  final String? avatarBase64;
  final VoidCallback onTap;
  const _ProfileAvatar({
    this.avatarPath,
    this.avatarBase64,
    required this.onTap,
  });

  @override
  State<_ProfileAvatar> createState() => _ProfileAvatarState();
}

class _ProfileAvatarState extends State<_ProfileAvatar> {
  bool _pressed = false;

  Widget _buildContent() {
    if (widget.avatarBase64 != null &&
        widget.avatarBase64!.startsWith('data:image')) {
      try {
        final cleanB64 = widget.avatarBase64!.split(',').last;
        final bytes = base64Decode(cleanB64);
        return Image.memory(bytes, fit: BoxFit.cover);
      } catch (_) {}
    }
    if (widget.avatarPath != null &&
        widget.avatarPath!.isNotEmpty &&
        File(widget.avatarPath!).existsSync()) {
      return Image.file(File(widget.avatarPath!), fit: BoxFit.cover);
    }
    return const Icon(Icons.person_outline,
        color: AppColors.black, size: 17);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: () {
        HapticFeedback.lightImpact();
        widget.onTap();
      },
      child: AnimatedScale(
        duration: const Duration(milliseconds: 90),
        scale: _pressed ? 0.9 : 1.0,
        child: Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: AppColors.yellow,
            shape: BoxShape.circle,
            border: Border.all(color: AppColors.black, width: 2.5),
            boxShadow: _S.sm,
          ),
          child: ClipOval(child: _buildContent()),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  NAV ITEM
// ═══════════════════════════════════════════════════════════════════
class _NavItem extends StatefulWidget {
  final IconData icon;
  final IconData? activeIcon;
  final String label;
  final bool isActive;
  final VoidCallback onTap;

  const _NavItem({
    required this.icon,
    this.activeIcon,
    required this.label,
    required this.isActive,
    required this.onTap,
  });

  @override
  State<_NavItem> createState() => _NavItemState();
}

class _NavItemState extends State<_NavItem> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTapDown: (_) => setState(() => _pressed = true),
        onTapUp: (_) => setState(() => _pressed = false),
        onTapCancel: () => setState(() => _pressed = false),
        onTap: widget.onTap,
        child: AnimatedScale(
          duration: const Duration(milliseconds: 120),
          scale: _pressed ? 0.94 : 1.0,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 7),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOutCubic,
              decoration: widget.isActive
                  ? BoxDecoration(
                      color: AppColors.yellow,
                      borderRadius: BorderRadius.circular(12),
                      border:
                          Border.all(color: AppColors.black, width: 2.5),
                      boxShadow: _S.sm,
                    )
                  : BoxDecoration(
                      color: Colors.transparent,
                      borderRadius: BorderRadius.circular(12),
                    ),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 8),
                child: Row(
                  mainAxisAlignment: widget.isActive
                      ? MainAxisAlignment.start
                      : MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Icon(
                      widget.isActive
                          ? (widget.activeIcon ?? widget.icon)
                          : widget.icon,
                      color: AppColors.black,
                      size: 19,
                    ),
                    if (widget.isActive) ...[
                      const SizedBox(width: 7),
                      Flexible(
                        child: Text(
                          widget.label,
                          style: const TextStyle(
                            color: AppColors.black,
                            fontSize: 12,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.3,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  DRAWER ITEM
// ═══════════════════════════════════════════════════════════════════
class _DrawerItem extends StatefulWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;

  const _DrawerItem({
    required this.icon,
    required this.title,
    required this.onTap,
  });

  @override
  State<_DrawerItem> createState() => _DrawerItemState();
}

class _DrawerItemState extends State<_DrawerItem> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: () {
        HapticFeedback.lightImpact();
        widget.onTap();
      },
      child: AnimatedScale(
        duration: const Duration(milliseconds: 100),
        scale: _pressed ? 0.97 : 1.0,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 3),
          child: Container(
            padding: const EdgeInsets.symmetric(
                horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: AppColors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.transparent, width: 2.5),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(7),
                  decoration: BoxDecoration(
                    color: AppColors.yellow,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: AppColors.black, width: 2),
                  ),
                  child: Icon(widget.icon,
                      color: AppColors.black, size: 16),
                ),
                const SizedBox(width: 12),
                Text(
                  widget.title,
                  style: const TextStyle(
                    color: AppColors.black,
                    fontWeight: FontWeight.w800,
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  BLACK BUTTON
// ═══════════════════════════════════════════════════════════════════
class _BlackButton extends StatefulWidget {
  final String text;
  final VoidCallback onTap;
  const _BlackButton({required this.text, required this.onTap});

  @override
  State<_BlackButton> createState() => _BlackButtonState();
}

class _BlackButtonState extends State<_BlackButton> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: () {
        HapticFeedback.lightImpact();
        widget.onTap();
      },
      child: AnimatedScale(
        duration: const Duration(milliseconds: 90),
        scale: _pressed ? 0.95 : 1.0,
        child: Container(
          padding: const EdgeInsets.symmetric(
              horizontal: 24, vertical: 10),
          decoration: BoxDecoration(
            color: AppColors.black,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.black, width: 2),
            boxShadow: _S.sm,
          ),
          child: Text(
            widget.text,
            style: const TextStyle(
              color: AppColors.yellow,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.5,
            ),
          ),
        ),
      ),
    );
  }
}