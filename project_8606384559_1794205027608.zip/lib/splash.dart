// splash_screen.dart - FINAL EDITION v3
// Fullscreen video + Logo di lingkaran + Circular loading ring
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import 'dashboard_page.dart';

// ═══════════════════════════════════════════════════════════════════
//  NEO-BRUTALISM THEME
// ═══════════════════════════════════════════════════════════════════
class _C {
  static const bg         = Color(0xFFFFFFFF);
  static const white      = Color(0xFFFFFFFF);
  static const yellow     = Color(0xFFFFE600);
  static const yellowSoft = Color(0xFFFFF9CC);
  static const cyan       = Color(0xFF00E5FF);
  static const orange     = Color(0xFFFF9800);
  static const black      = Color(0xFF000000);
  static const textMuted  = Color(0xFF777777);
  static const success    = Color(0xFF00C853);
}

class _S {
  static List<BoxShadow> get sm => const [
    BoxShadow(color: _C.black, offset: Offset(2, 2), blurRadius: 0),
  ];
  static List<BoxShadow> get md => const [
    BoxShadow(color: _C.black, offset: Offset(4, 4), blurRadius: 0),
  ];
  static List<BoxShadow> get lg => const [
    BoxShadow(color: _C.black, offset: Offset(6, 6), blurRadius: 0),
  ];
}

// ═══════════════════════════════════════════════════════════════════
//  SPLASH SCREEN
// ═══════════════════════════════════════════════════════════════════
class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  // ─── Video ───
  late VideoPlayerController _videoController;
  bool _videoReady = false;

  // ─── Animations ───
  late AnimationController _logoCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _rotateCtrl;
  late AnimationController _rotateSlowCtrl;
  late AnimationController _progressCtrl;
  late AnimationController _exitCtrl;

  late Animation<double> _logoScale;
  late Animation<double> _logoFade;
  late Animation<double> _pulse;
  late Animation<double> _rotate;
  late Animation<double> _rotateSlow;
  late Animation<double> _progress;
  late Animation<double> _exitScale;
  late Animation<double> _exitFade;

  int _counter = 0;
  bool _navigated = false;

  @override
  void initState() {
    super.initState();

    // ─── Video fullscreen background ───
    _videoController = VideoPlayerController.asset("assets/videos/load.mp4")
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() => _videoReady = true);
        _videoController.setLooping(true);
        _videoController.setVolume(0.3);
        _videoController.play();
      }).catchError((e) {
        debugPrint('Video load error: $e');
        if (!mounted) return;
        setState(() => _videoReady = true);
      });

    // ─── Logo entrance ───
    _logoCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
    _logoScale = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _logoCtrl, curve: Curves.elasticOut),
    );
    _logoFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _logoCtrl,
        curve: const Interval(0.0, 0.4, curve: Curves.easeOut),
      ),
    );

    // ─── Pulse ───
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);
    _pulse = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );

    // ─── Fast orbit dot ───
    _rotateCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();
    _rotate = Tween<double>(begin: 0.0, end: 1.0).animate(_rotateCtrl);

    // ─── Slow orbit dot ───
    _rotateSlowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat();
    _rotateSlow = Tween<double>(begin: 0.0, end: 1.0).animate(_rotateSlowCtrl);

    // ─── Progress 0.0 → 1.0 ───
    _progressCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 25000),
    );
    _progress = CurvedAnimation(
      parent: _progressCtrl,
      curve: Curves.easeInOut,
    );

    // ─── Exit ───
    _exitCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    _exitScale = Tween<double>(begin: 1.0, end: 1.4).animate(
      CurvedAnimation(parent: _exitCtrl, curve: Curves.easeInCubic),
    );
    _exitFade = Tween<double>(begin: 1.0, end: 0.0).animate(
      CurvedAnimation(
        parent: _exitCtrl,
        curve: const Interval(0.3, 1.0, curve: Curves.easeIn),
      ),
    );

    // ─── Counter listener ───
    _progress.addListener(() {
      final newVal = (_progress.value * 100).toInt();
      if (newVal != _counter && mounted) {
        setState(() => _counter = newVal);
        if (newVal % 10 == 0 && newVal > 0) {
          HapticFeedback.selectionClick();
        }
      }
    });

    _startSequence();
  }

  Future<void> _startSequence() async {
    await Future.delayed(const Duration(milliseconds: 200));
    _logoCtrl.forward();

    await Future.delayed(const Duration(milliseconds: 600));
    _progressCtrl.forward();

    await _progressCtrl.forward().whenComplete(() async {
      if (!mounted) return;
      await Future.delayed(const Duration(milliseconds: 400));
      if (!mounted) return;
      _exitCtrl.forward();
      HapticFeedback.mediumImpact();
      await Future.delayed(const Duration(milliseconds: 650));
      _navigateToDashboard();
    });
  }

  void _navigateToDashboard() {
    if (_navigated) return;
    _navigated = true;

    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 800),
        pageBuilder: (context, animation, secondaryAnimation) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
        ),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          const curve = Curves.easeOutQuart;
          var fadeTween = Tween(begin: 0.0, end: 1.0)
              .chain(CurveTween(curve: curve));
          var scaleTween = Tween(begin: 1.15, end: 1.0)
              .chain(CurveTween(curve: curve));
          var slideTween = Tween<Offset>(
            begin: const Offset(0, 0.05),
            end: Offset.zero,
          ).chain(CurveTween(curve: curve));

          return FadeTransition(
            opacity: animation.drive(fadeTween),
            child: SlideTransition(
              position: animation.drive(slideTween),
              child: ScaleTransition(
                scale: animation.drive(scaleTween),
                child: child,
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  void dispose() {
    _videoController.dispose();
    _logoCtrl.dispose();
    _pulseCtrl.dispose();
    _rotateCtrl.dispose();
    _rotateSlowCtrl.dispose();
    _progressCtrl.dispose();
    _exitCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.black,
      body: Stack(
        children: [
          // ═══════════════════════════════════════════════
          //  1. FULLSCREEN VIDEO BACKGROUND
          // ═══════════════════════════════════════════════
          if (_videoReady && _videoController.value.isInitialized)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController.value.size.width,
                  height: _videoController.value.size.height,
                  child: VideoPlayer(_videoController),
                ),
              ),
            )
          else
            Container(
              color: _C.black,
              child: const Center(
                child: CircularProgressIndicator(
                  color: _C.yellow,
                  strokeWidth: 3,
                ),
              ),
            ),

          // ═══════════════════════════════════════════════
          //  2. DARK OVERLAY (biar teks kebaca)
          // ═══════════════════════════════════════════════
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment.center,
                  radius: 1.2,
                  colors: [
                    Colors.black.withOpacity(0.3),
                    Colors.black.withOpacity(0.7),
                  ],
                ),
              ),
            ),
          ),

          // ═══════════════════════════════════════════════
          //  3. TOP STATUS CHIP
          // ═══════════════════════════════════════════════
          Positioned(
            top: MediaQuery.of(context).padding.top + 16,
            left: 16,
            child: _buildStatusChip(),
          ),

          // ═══════════════════════════════════════════════
          //  4. SKIP BUTTON
          // ═══════════════════════════════════════════════
          Positioned(
            top: MediaQuery.of(context).padding.top + 16,
            right: 16,
            child: _SkipButton(onTap: _navigateToDashboard),
          ),

          // ═══════════════════════════════════════════════
          //  5. MAIN CONTENT
          // ═══════════════════════════════════════════════
          AnimatedBuilder(
            animation: Listenable.merge([_exitScale, _exitFade]),
            builder: (_, child) => Transform.scale(
              scale: _exitScale.value,
              child: Opacity(
                opacity: _exitFade.value,
                child: child,
              ),
            ),
            child: SafeArea(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Spacer(flex: 2),

                    // ═══ LOGO IN CIRCLE + RING LOADING ═══
                    _buildLogoWithRing(),

                    const SizedBox(height: 28),

                    // Brand name
                    _buildBrandName(),

                    const SizedBox(height: 12),

                    // Loading text
                    _buildLoadingText(),

                    const Spacer(flex: 1),

                    // Counter section
                    _buildCounterSection(),

                    const SizedBox(height: 40),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  //  STATUS CHIP
  // ═══════════════════════════════════════════════════════════════
  Widget _buildStatusChip() {
    return TweenAnimationBuilder<double>(
      duration: const Duration(milliseconds: 600),
      tween: Tween(begin: 0.0, end: 1.0),
      curve: Curves.easeOutCubic,
      builder: (_, v, child) => Opacity(
        opacity: v,
        child: Transform.translate(
          offset: Offset(-20 * (1 - v), 0),
          child: child,
        ),
      ),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: _C.black,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _C.yellow, width: 2),
          boxShadow: _S.sm,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedBuilder(
              animation: _pulse,
              builder: (_, __) => Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: _C.success.withOpacity(_pulse.value),
                  shape: BoxShape.circle,
                ),
              ),
            ),
            const SizedBox(width: 8),
            const Text(
              'LOADING SYSTEM',
              style: TextStyle(
                color: _C.yellow,
                fontSize: 9,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  //  LOGO IN CIRCLE + CIRCULAR LOADING RING
  // ═══════════════════════════════════════════════════════════════
  Widget _buildLogoWithRing() {
    const double ringSize = 240;    // ring luar
    const double logoSize = 170;    // logo dalam

    return AnimatedBuilder(
      animation: Listenable.merge([
        _logoScale,
        _logoFade,
        _pulse,
        _rotate,
        _rotateSlow,
        _progress,
      ]),
      builder: (_, __) {
        return SizedBox(
          width: ringSize + 80,
          height: ringSize + 80,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // ═══ PULSE RING 1 (kuning) ═══
              Container(
                width: ringSize + (_pulse.value * 30),
                height: ringSize + (_pulse.value * 30),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: _C.yellow.withOpacity(1.0 - _pulse.value),
                    width: 3,
                  ),
                ),
              ),

              // ═══ PULSE RING 2 (cyan) ═══
              Container(
                width: ringSize + (_pulse.value * 55),
                height: ringSize + (_pulse.value * 55),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: _C.cyan.withOpacity((1.0 - _pulse.value) * 0.5),
                    width: 2,
                  ),
                ),
              ),

              // ═══ WHITE RING BG + BLACK BORDER ═══
              Container(
                width: ringSize,
                height: ringSize,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _C.white,
                  border: Border.all(color: _C.black, width: 5),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.4),
                      blurRadius: 30,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
              ),

              // ═══ CIRCULAR LOADING RING (melingkar) ═══
              CustomPaint(
                size: const Size(ringSize, ringSize),
                painter: _CircularLoadingRingPainter(
                  progress: _progress.value,
                  strokeWidth: 10,
                ),
              ),

              // ═══ TRAIL DOTS (3 titik orange ngikutin) ═══
              ...List.generate(3, (i) {
                final trailDelay = (i + 1) * 0.04;
                final trailProgress =
                    (_progress.value - trailDelay).clamp(0.0, 1.0);
                return _buildTrailDot(
                  ringSize / 2,
                  trailProgress,
                  i,
                );
              }),

              // ═══ LOGO DI DALAM LINGKARAN ═══
              Container(
                width: logoSize,
                height: logoSize,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _C.white,
                  border: Border.all(color: _C.black, width: 4),
                ),
                child: ClipOval(
                  child: Transform.scale(
                    scale: _logoScale.value,
                    child: Opacity(
                      opacity: _logoFade.value,
                      child: Image.asset(
                        'assets/images/splash.jpg',
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color: _C.yellow,
                          child: const Icon(
                            Icons.bolt_rounded,
                            color: _C.black,
                            size: 60,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              // ═══ ORBIT DOT 1 (cepat, atas) ═══
              Transform.rotate(
                angle: _rotate.value * 2 * math.pi,
                child: SizedBox(
                  width: ringSize,
                  height: ringSize,
                  child: Align(
                    alignment: Alignment.topCenter,
                    child: _buildOrbitDot(_C.cyan, 16),
                  ),
                ),
              ),

              // ═══ ORBIT DOT 2 (lambat, bawah) ═══
              Transform.rotate(
                angle: -_rotateSlow.value * 2 * math.pi,
                child: SizedBox(
                  width: ringSize,
                  height: ringSize,
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: _buildOrbitDot(_C.yellow, 12),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildOrbitDot(Color color, double size) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
        border: Border.all(color: _C.black, width: 2.5),
        boxShadow: _S.sm,
      ),
    );
  }

  // Trail dot — dot kecil orange ngikutin progress
  Widget _buildTrailDot(double ringRadius, double progress, int index) {
    final dotRadius = ringRadius - 10;
    const startAngle = -math.pi / 2;
    final angle = startAngle + (2 * math.pi * progress);

    final dotX = ringRadius + dotRadius * math.cos(angle);
    final dotY = ringRadius + dotRadius * math.sin(angle);

    final opacity = 1.0 - (index * 0.3);
    final size = 8.0 - (index * 1.5);

    if (progress <= 0.01) return const SizedBox.shrink();

    return Positioned(
      left: dotX - size / 2,
      top: dotY - size / 2,
      child: Opacity(
        opacity: opacity.clamp(0.0, 1.0),
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            color: _C.orange,
            shape: BoxShape.circle,
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  //  BRAND NAME "DRAXION"
  // ═══════════════════════════════════════════════════════════════
  Widget _buildBrandName() {
    return AnimatedBuilder(
      animation: _logoFade,
      builder: (_, child) => Opacity(
        opacity: _logoFade.value,
        child: Transform.translate(
          offset: Offset(0, 20 * (1 - _logoFade.value)),
          child: child,
        ),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 30,
                height: 4,
                decoration: BoxDecoration(
                  color: _C.yellow,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 12),
              const Text(
                'DRAXION',
                style: TextStyle(
                  fontFamily: 'Genetic',
                  fontSize: 44,
                  fontWeight: FontWeight.w900,
                  color: _C.yellow,
                  letterSpacing: 6,
                  height: 1.0,
                  shadows: [
                    Shadow(
                      color: Colors.black,
                      blurRadius: 12,
                      offset: Offset(0, 4),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Container(
                width: 30,
                height: 4,
                decoration: BoxDecoration(
                  color: _C.yellow,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
            decoration: BoxDecoration(
              color: _C.yellow,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _C.black, width: 2),
              boxShadow: _S.sm,
            ),
            child: const Text(
              'APK SADAP JARAK JAUH',
              style: TextStyle(
                color: _C.black,
                fontSize: 9,
                fontWeight: FontWeight.w900,
                letterSpacing: 2.5,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  //  LOADING TEXT
  // ═══════════════════════════════════════════════════════════════
  Widget _buildLoadingText() {
    return AnimatedBuilder(
      animation: _progress,
      builder: (_, __) {
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          decoration: BoxDecoration(
            color: _C.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _C.black, width: 3),
            boxShadow: _S.sm,
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const _DotWaveDot(delay: 0),
              const SizedBox(width: 4),
              const _DotWaveDot(delay: 150),
              const SizedBox(width: 4),
              const _DotWaveDot(delay: 300),
              const SizedBox(width: 12),
              Text(
                _getLoadingMessage(),
                style: const TextStyle(
                  color: _C.black,
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  String _getLoadingMessage() {
    if (_counter < 25) return 'INITIALIZING...';
    if (_counter < 50) return 'LOADING ASSETS...';
    if (_counter < 75) return 'CONNECTING SERVER...';
    if (_counter < 95) return 'FINALIZING...';
    return 'READY!';
  }

  // ═══════════════════════════════════════════════════════════════
  //  COUNTER SECTION
  // ═══════════════════════════════════════════════════════════════
  Widget _buildCounterSection() {
    return AnimatedBuilder(
      animation: _progress,
      builder: (_, __) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 40),
          child: Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: _C.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _C.black, width: 3),
              boxShadow: _S.md,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    AnimatedBuilder(
                      animation: _pulse,
                      builder: (_, __) => Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                          color: _C.success
                              .withOpacity(0.4 + _pulse.value * 0.6),
                          shape: BoxShape.circle,
                          border: Border.all(color: _C.black, width: 1.5),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    const Text(
                      'LOADING',
                      style: TextStyle(
                        color: _C.black,
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2,
                      ),
                    ),
                    const Spacer(),
                    RichText(
                      text: TextSpan(
                        children: [
                          TextSpan(
                            text: '$_counter',
                            style: const TextStyle(
                              fontFamily: 'Genetic',
                              fontSize: 32,
                              fontWeight: FontWeight.w900,
                              color: _C.black,
                              height: 1.0,
                            ),
                          ),
                          const TextSpan(
                            text: ' / 100',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              color: _C.textMuted,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: List.generate(10, (i) {
                    final segmentProgress =
                        (_counter - (i * 10)).clamp(0, 10) / 10;
                    return Expanded(
                      child: Container(
                        margin: EdgeInsets.only(right: i == 9 ? 0 : 4),
                        height: 12,
                        decoration: BoxDecoration(
                          color: _C.yellowSoft,
                          borderRadius: BorderRadius.circular(3),
                          border: Border.all(color: _C.black, width: 2),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(1),
                          child: FractionallySizedBox(
                            alignment: Alignment.centerLeft,
                            widthFactor: segmentProgress,
                            child: Container(color: _C.yellow),
                          ),
                        ),
                      ),
                    );
                  }),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  CIRCULAR LOADING RING PAINTER (Progress melingkar)
// ═══════════════════════════════════════════════════════════════════
class _CircularLoadingRingPainter extends CustomPainter {
  final double progress;
  final double strokeWidth;

  _CircularLoadingRingPainter({
    required this.progress,
    required this.strokeWidth,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = (size.width - strokeWidth) / 2;

    // ─── Background track ring ───
    final bgPaint = Paint()
      ..color = _C.yellowSoft
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;
    canvas.drawCircle(center, radius, bgPaint);

    // ─── Progress arc (gradient) ───
    const startAngle = -math.pi / 2;
    final sweepAngle = 2 * math.pi * progress;

    final rect = Rect.fromCircle(center: center, radius: radius);
    final gradientPaint = Paint()
      ..shader = SweepGradient(
        startAngle: startAngle,
        endAngle: startAngle + 2 * math.pi,
        colors: [
          _C.yellow,
          _C.orange,
          _C.cyan,
          _C.yellow,
        ],
        stops: const [0.0, 0.4, 0.7, 1.0],
        transform: GradientRotation(startAngle),
      ).createShader(rect)
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;

    canvas.drawArc(
      rect,
      startAngle,
      sweepAngle,
      false,
      gradientPaint,
    );

    // ─── End cap (dot ujung progress) ───
    if (progress > 0.005) {
      final endAngle = startAngle + sweepAngle;
      final endPoint = Offset(
        center.dx + radius * math.cos(endAngle),
        center.dy + radius * math.sin(endAngle),
      );

      // Glow
      final glowPaint = Paint()
        ..color = _C.yellow.withOpacity(0.5)
        ..style = PaintingStyle.fill
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
      canvas.drawCircle(endPoint, strokeWidth * 1.2, glowPaint);

      // Black cap
      canvas.drawCircle(
        endPoint,
        strokeWidth * 0.9,
        Paint()..color = _C.black,
      );

      // Inner cyan dot
      canvas.drawCircle(
        endPoint,
        strokeWidth * 0.5,
        Paint()..color = _C.cyan,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _CircularLoadingRingPainter old) =>
      old.progress != progress;
}

// ═══════════════════════════════════════════════════════════════════
//  DOT WAVE DOT
// ═══════════════════════════════════════════════════════════════════
class _DotWaveDot extends StatefulWidget {
  final int delay;
  const _DotWaveDot({required this.delay});

  @override
  State<_DotWaveDot> createState() => _DotWaveDotState();
}

class _DotWaveDotState extends State<_DotWaveDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _anim = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut),
    );

    Future.delayed(Duration(milliseconds: widget.delay), () {
      if (mounted) _ctrl.repeat(reverse: true);
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _anim,
      builder: (_, __) => Opacity(
        opacity: _anim.value,
        child: Container(
          width: 6,
          height: 6,
          decoration: BoxDecoration(
            color: _C.yellow,
            shape: BoxShape.circle,
            border: Border.all(color: _C.black, width: 1.5),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  SKIP BUTTON
// ═══════════════════════════════════════════════════════════════════
class _SkipButton extends StatefulWidget {
  final VoidCallback onTap;
  const _SkipButton({required this.onTap});

  @override
  State<_SkipButton> createState() => _SkipButtonState();
}

class _SkipButtonState extends State<_SkipButton> {
  bool _isPressed = false;

  void _handleTap() {
    HapticFeedback.lightImpact();
    setState(() => _isPressed = true);
    Future.delayed(const Duration(milliseconds: 100), () {
      if (mounted) setState(() => _isPressed = false);
      widget.onTap();
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _handleTap,
      child: AnimatedScale(
        duration: const Duration(milliseconds: 100),
        scale: _isPressed ? 0.92 : 1.0,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          decoration: BoxDecoration(
            color: _C.yellow,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _C.black, width: 3),
            boxShadow: const [
              BoxShadow(
                color: _C.black,
                offset: Offset(4, 4),
                blurRadius: 0,
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'SKIP',
                style: TextStyle(
                  color: _C.black,
                  fontWeight: FontWeight.w900,
                  fontSize: 13,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(width: 6),
              Container(
                padding: const EdgeInsets.all(3),
                decoration: BoxDecoration(
                  color: _C.black,
                  borderRadius: BorderRadius.circular(5),
                ),
                child: const Icon(
                  Icons.skip_next_rounded,
                  color: _C.yellow,
                  size: 14,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}